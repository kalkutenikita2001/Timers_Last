<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Total Events</title>

    <!-- Bootstrap & Font Awesome -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" />

    <!-- Custom Styles -->
    <style>
        body {
            background-color: #f4f6f8 !important;
            margin: 0;
            font-family: 'Montserrat', serif !important;
            font-style: normal;
            overflow-x: hidden;
        }

        /* Sidebar */
        .sidebar {
            position: relative;
            left: 0;
            top: 0;
            bottom: 0;
            width: 250px;
            background-color: #333;
            color: white;
            padding-top: 20px;
        }

        .sidebar.minimized {
            width: 60px;
        }

        /* Navbar */
        .navbar {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            color: white;
            padding: 10px;
            transition: left 0.3s ease-in-out, width 0.3s ease-in-out;
        }

        .navbar.sidebar-minimized {
            left: 60px;
        }

        /* Content */
        .content-wrapper {
            margin-left: 250px;
            padding: 40px 20px 20px 20px;
            transition: margin-left 0.3s ease-in-out;
        }

        .content-wrapper.minimized {
            margin-left: 60px;
        }

        /* Card Header */
        .card-header {
            background: linear-gradient(135deg, #ff4040 0%, #470000 100%) !important;
            color: #fff !important;
        }

        /* Buttons Primary */
        .btn-primary {
            background: linear-gradient(135deg, #ff4040 0%, #470000 100%) !important;
            border: none !important;
        }

        .btn-primary:hover {
            opacity: 0.9;
        }

        /* Event Card Styles */
        .event-card {
            transition: transform 0.3s, box-shadow 0.3s;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 25px;
            height: 100%;
        }

        .event-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }

        .event-header {
            background: linear-gradient(135deg, #ff4040 0%, #470000 100%) !important;
            color: white;
            padding: 15px;
        }

        .event-icon {
            margin-right: 8px;
            width: 20px;
            text-align: center;
        }

        .event-detail {
            margin-bottom: 12px;
            display: flex;
            align-items: flex-start;
        }

        .event-title {
            font-size: 1.4rem;
            margin-bottom: 0;
            font-weight: 600;
        }

        .event-description {
            color: #555;
            line-height: 1.5;
        }

        .participate-btn {
            padding: 8px 15px;
            font-weight: 600;
            margin-left: 5px;
        }

        .page-title {
            font-weight: 700;
            color: #333;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #ff4040;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .filter-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }

        /* Modal Styles */
        .modal-content {
            border-radius: 12px;
            overflow: hidden;
        }

        .modal-header {
            background: linear-gradient(135deg, #ff4040 0%, #470000 100%) !important;
            color: white;
            border-bottom: none;
        }

        .modal-title {
            font-weight: 600;
        }

        .close {
            color: white;
            opacity: 0.8;
        }

        .close:hover {
            color: white;
            opacity: 1;
        }

        /* Add Event Button */
        .add-event-btn {
            padding: 10px 20px;
            font-weight: 600;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
            }

            .sidebar.active {
                left: 0;
            }

            .navbar {
                left: 0;
            }

            .content-wrapper {
                margin-left: 0;
                padding: 80px 20px 20px 20px;
            }

            .page-title {
                flex-direction: column;
                align-items: flex-start;
            }

            .add-event-btn {
                margin-top: 15px;
            }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <?php $this->load->view('superadmin/Include/Sidebar') ?>
    <!-- Navbar -->
    <?php $this->load->view('superadmin/Include/Navbar') ?>

    <!-- Main Content Wrapper -->
    <div class="content-wrapper" id="contentWrapper">
        <div class="content">
            <div class="container-fluid">
                <div class="container">
                    <div class="page-title">
                        <h1><i class="fas fa-calendar-alt mr-2"></i>All Events</h1>
                        <button type="button" class="btn btn-primary add-event-btn" data-toggle="modal" data-target="#addEventModal">
                            <i class="fas fa-plus-circle mr-2"></i>Add Event
                        </button>
                    </div>

                    <!-- Filter Section -->
                    <div class="filter-container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="searchEvents"><i class="fas fa-search"></i> Search Events</label>
                                    <input type="text" class="form-control" id="searchEvents" placeholder="Search by event name, description...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="filterDate"><i class="fas fa-filter"></i> Filter by Date</label>
                                    <select class="form-control" id="filterDate">
                                        <option value="all">All Dates</option>
                                        <option value="today">Today</option>
                                        <option value="week">This Week</option>
                                        <option value="month">This Month</option>
                                        <option value="upcoming">Upcoming</option>
                                        <option value="past">Past Events</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="sortEvents"><i class="fas fa-sort"></i> Sort By</label>
                                    <select class="form-control" id="sortEvents">
                                        <option value="newest">Newest First</option>
                                        <option value="oldest">Oldest First</option>
                                        <option value="price-low">Price: Low to High</option>
                                        <option value="price-high">Price: High to Low</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Events Grid -->
                    <div class="row events-container">
                        <!-- Event cards will be dynamically loaded -->
                    </div>

                    <!-- Pagination -->
                    <nav aria-label="Event pagination" class="mt-4">
                        <ul class="pagination justify-content-center" id="pagination">
                            <!-- Pagination will be dynamically loaded -->
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Event Modal -->
    <div class="modal fade" id="addEventModal" tabindex="-1" role="dialog" aria-labelledby="addEventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addEventModalLabel">
                        <i class="fas fa-plus-circle mr-2"></i>Add New Event
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="eventForm">
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="eventName"><i class="fas fa-tag"></i> Event Name *</label>
                                <input type="text" class="form-control" id="eventName" placeholder="Enter event name" required>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="eventDescription"><i class="fas fa-align-left"></i> Description *</label>
                                <textarea class="form-control" id="eventDescription" rows="3" placeholder="Enter event description" required></textarea>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="eventDate"><i class="fas fa-calendar-day"></i> Date *</label>
                                <input type="date" class="form-control" id="eventDate" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="eventTime"><i class="fas fa-clock"></i> Time *</label>
                                <input type="time" class="form-control" id="eventTime" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="eventFee"><i class="fas fa-money-bill-wave"></i> Participation Fee *</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">$</span>
                                    </div>
                                    <input type="number" class="form-control" id="eventFee" placeholder="0.00" min="0" step="0.01" required>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="maxParticipants"><i class="fas fa-users"></i> Maximum Participants *</label>
                                <input type="number" class="form-control" id="maxParticipants" placeholder="Enter maximum participants" min="1" required>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveEventBtn">
                        <i class="fas fa-save mr-2"></i>Save Event
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap + jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            let currentPage = 1;
            let currentSearch = '';
            let currentFilter = 'all';
            let currentSort = 'newest';

            // Load events
            function loadEvents(page = 1, search = '', filter = 'all', sort = 'newest') {
                $.ajax({
                    url: '<?php echo base_url('index.php/event/get_events'); ?>',
                    type: 'GET',
                    data: { page: page, search: search, filter: filter, sort: sort },
                    dataType: 'json',
                    success: function(response) {
                        $('.events-container').empty();
                        if (response.events.length > 0) {
                            response.events.forEach(event => {
                                let card = `
                                    <div class="col-lg-4 col-md-6">
                                        <div class="card event-card">
                                            <div class="event-header">
                                                <h3 class="event-title">${escapeHtml(event.name)}</h3>
                                            </div>
                                            <div class="card-body">
                                                <div class="event-description">${escapeHtml(event.description)}</div>
                                                <div class="event-detail">
                                                    <i class="fas fa-calendar-day event-icon"></i>
                                                    <span>Date: ${event.date}</span>
                                                </div>
                                                <div class="event-detail">
                                                    <i class="fas fa-clock event-icon"></i>
                                                    <span>Time: ${event.time}</span>
                                                </div>
                                                <div class="event-detail">
                                                    <i class="fas fa-money-bill-wave event-icon"></i>
                                                    <span>Fee: $${parseFloat(event.fee).toFixed(2)}</span>
                                                </div>
                                                <div class="event-detail">
                                                    <i class="fas fa-users event-icon"></i>
                                                    <span>Max Participants: ${event.max_participants}</span>
                                                </div>
                                            </div>
                                            <div class="card-footer text-right">
                                                <button class="btn btn-primary participate-btn send-form-btn" data-event-id="${event.id}">Send Form</button>
                                                <button class="btn btn-primary participate-btn view-participant-btn" data-event-id="${event.id}">View Participant</button>
                                            </div>
                                        </div>
                                    </div>`;
                                $('.events-container').append(card);
                            });
                        } else {
                            $('.events-container').append('<p>No events found.</p>');
                        }

                        // Update pagination
                        $('#pagination').empty();
                        let paginationHtml = `
                            <li class="page-item ${response.page === 1 ? 'disabled' : ''}">
                                <a class="page-link" href="#" data-page="${response.page - 1}" tabindex="-1">Previous</a>
                            </li>`;
                        for (let i = 1; i <= response.total_pages; i++) {
                            paginationHtml += `
                                <li class="page-item ${i === response.page ? 'active' : ''}">
                                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                                </li>`;
                        }
                        paginationHtml += `
                            <li class="page-item ${response.page === response.total_pages ? 'disabled' : ''}">
                                <a class="page-link" href="#" data-page="${response.page + 1}">Next</a>
                            </li>`;
                        $('#pagination').html(paginationHtml);
                    },
                    error: function(xhr) {
                        console.log('Error loading events:', xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load events. Please try again.',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            }

            // Search functionality (sent to backend)
            $('#searchEvents').on('keyup', function() {
                currentSearch = $(this).val();
                currentPage = 1;
                loadEvents(currentPage, currentSearch, currentFilter, currentSort);
            });

            // Filter and Sort change (sent to backend)
            $('#filterDate, #sortEvents').on('change', function() {
                currentFilter = $('#filterDate').val();
                currentSort = $('#sortEvents').val();
                currentPage = 1;
                loadEvents(currentPage, currentSearch, currentFilter, currentSort);
            });

            // Pagination click
            $(document).on('click', '.page-link', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                if (page && !$(this).parent().hasClass('disabled')) {
                    currentPage = page;
                    loadEvents(currentPage, currentSearch, currentFilter, currentSort);
                }
            });

            // Save event button handler
            $('#saveEventBtn').click(function() {
                const formData = {
                    name: $('#eventName').val(),
                    description: $('#eventDescription').val(),
                    date: $('#eventDate').val(),
                    time: $('#eventTime').val(),
                    fee: $('#eventFee').val(),
                    max_participants: $('#maxParticipants').val()
                };

                if (!formData.name || !formData.description || !formData.date || !formData.time || !formData.fee || !formData.max_participants) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Please fill in all required fields',
                        confirmButtonText: 'OK'
                    });
                    return;
                }

                $.ajax({
                    url: '<?php echo base_url('index.php/event/add_event'); ?>',
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success',
                                text: response.message,
                                confirmButtonText: 'OK'
                            }).then(() => {
                                $('#addEventModal').modal('hide');
                                loadEvents(currentPage, currentSearch, currentFilter, currentSort);
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message,
                                confirmButtonText: 'OK'
                            });
                        }
                    },
                    error: function(xhr) {
                        console.log('Error adding event:', xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to add event. Please try again.',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });

            // Reset form on modal close
            $('#addEventModal').on('hidden.bs.modal', function() {
                $('#eventForm')[0].reset();
            });

            // Send Form button
            $(document).on('click', '.send-form-btn', function() {
                const eventId = $(this).data('event-id');
                $.ajax({
                    url: '<?php echo base_url('index.php/event/send_form/'); ?>' + eventId,
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                            confirmButtonText: 'OK'
                        });
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to send form. Please try again.',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });

            // View Participant button
            $(document).on('click', '.view-participant-btn', function() {
                const eventId = $(this).data('event-id');
                $.ajax({
                    url: '<?php echo base_url('index.php/event/view_participants/'); ?>' + eventId,
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        Swal.fire({
                            icon: 'info',
                            title: 'Participants',
                            text: 'Participants: ' + (response.participants.length ? response.participants.join(', ') : 'No participants yet'),
                            confirmButtonText: 'OK'
                        });
                    },
                    error: function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Failed to load participants. Please try again.',
                            confirmButtonText: 'OK'
                        });
                    }
                });
            });

            // Initial load
            loadEvents();

            // HTML escaping function
            function escapeHtml(unsafe) {
                return unsafe
                    .replace(/&/g, "&amp;")
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")
                    .replace(/"/g, "&quot;")
                    .replace(/'/g, "&#039;");
            }
        });
    </script>
    </script>
   <!-- Sidebar Toggle Script -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const sidebarToggle = document.getElementById('sidebarToggle');
            const sidebar = document.getElementById('sidebar');
            const navbar = document.querySelector('.navbar');
            const contentWrapper = document.getElementById('contentWrapper');

            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', () => {
                    if (window.innerWidth <= 768) {
                        sidebar.classList.toggle('active');
                        navbar.classList.toggle('sidebar-hidden', !sidebar.classList.contains('active'));
                    } else {
                        const isMinimized = sidebar.classList.toggle('minimized');
                        navbar.classList.toggle('sidebar-minimized', isMinimized);
                        contentWrapper.classList.toggle('minimized', isMinimized);
                    }
                });
            }
        });
    </script>
</body>
</html>