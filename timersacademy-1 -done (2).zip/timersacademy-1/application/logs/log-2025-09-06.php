<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-06 08:30:41 --> Config Class Initialized
INFO - 2025-09-06 08:30:41 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:30:41 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:30:41 --> Utf8 Class Initialized
INFO - 2025-09-06 08:30:41 --> URI Class Initialized
INFO - 2025-09-06 08:30:41 --> Router Class Initialized
INFO - 2025-09-06 08:30:41 --> Output Class Initialized
INFO - 2025-09-06 08:30:41 --> Security Class Initialized
DEBUG - 2025-09-06 08:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:30:41 --> Input Class Initialized
INFO - 2025-09-06 08:30:41 --> Language Class Initialized
INFO - 2025-09-06 08:30:41 --> Loader Class Initialized
INFO - 2025-09-06 08:30:41 --> Helper loaded: url_helper
INFO - 2025-09-06 08:30:41 --> Database Driver Class Initialized
ERROR - 2025-09-06 08:30:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'badmintondb' C:\xampp\htdocs\timersacademy-1\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-06 08:30:41 --> Unable to connect to the database
INFO - 2025-09-06 08:30:41 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:33:45 --> Config Class Initialized
INFO - 2025-09-06 08:33:45 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:33:45 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:33:45 --> Utf8 Class Initialized
INFO - 2025-09-06 08:33:45 --> URI Class Initialized
INFO - 2025-09-06 08:33:45 --> Router Class Initialized
INFO - 2025-09-06 08:33:45 --> Output Class Initialized
INFO - 2025-09-06 08:33:45 --> Security Class Initialized
DEBUG - 2025-09-06 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:33:45 --> Input Class Initialized
INFO - 2025-09-06 08:33:45 --> Language Class Initialized
INFO - 2025-09-06 08:33:45 --> Loader Class Initialized
INFO - 2025-09-06 08:33:45 --> Helper loaded: url_helper
INFO - 2025-09-06 08:33:45 --> Database Driver Class Initialized
ERROR - 2025-09-06 08:33:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'badmintondb' C:\xampp\htdocs\timersacademy-1\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-06 08:33:45 --> Unable to connect to the database
INFO - 2025-09-06 08:33:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:33:46 --> Config Class Initialized
INFO - 2025-09-06 08:33:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:33:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:33:46 --> Utf8 Class Initialized
INFO - 2025-09-06 08:33:46 --> URI Class Initialized
INFO - 2025-09-06 08:33:46 --> Router Class Initialized
INFO - 2025-09-06 08:33:46 --> Output Class Initialized
INFO - 2025-09-06 08:33:46 --> Security Class Initialized
DEBUG - 2025-09-06 08:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:33:46 --> Input Class Initialized
INFO - 2025-09-06 08:33:46 --> Language Class Initialized
INFO - 2025-09-06 08:33:47 --> Loader Class Initialized
INFO - 2025-09-06 08:33:47 --> Helper loaded: url_helper
INFO - 2025-09-06 08:33:47 --> Database Driver Class Initialized
ERROR - 2025-09-06 08:33:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'badmintondb' C:\xampp\htdocs\timersacademy-1\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-06 08:33:47 --> Unable to connect to the database
INFO - 2025-09-06 08:33:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:33:47 --> Config Class Initialized
INFO - 2025-09-06 08:33:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:33:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:33:47 --> Utf8 Class Initialized
INFO - 2025-09-06 08:33:47 --> URI Class Initialized
INFO - 2025-09-06 08:33:47 --> Router Class Initialized
INFO - 2025-09-06 08:33:47 --> Output Class Initialized
INFO - 2025-09-06 08:33:47 --> Security Class Initialized
DEBUG - 2025-09-06 08:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:33:47 --> Input Class Initialized
INFO - 2025-09-06 08:33:47 --> Language Class Initialized
INFO - 2025-09-06 08:33:47 --> Loader Class Initialized
INFO - 2025-09-06 08:33:47 --> Helper loaded: url_helper
INFO - 2025-09-06 08:33:47 --> Database Driver Class Initialized
ERROR - 2025-09-06 08:33:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'badmintondb' C:\xampp\htdocs\timersacademy-1\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-06 08:33:47 --> Unable to connect to the database
INFO - 2025-09-06 08:33:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:34:16 --> Config Class Initialized
INFO - 2025-09-06 08:34:16 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:34:16 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:34:16 --> Utf8 Class Initialized
INFO - 2025-09-06 08:34:16 --> URI Class Initialized
INFO - 2025-09-06 08:34:16 --> Router Class Initialized
INFO - 2025-09-06 08:34:16 --> Output Class Initialized
INFO - 2025-09-06 08:34:16 --> Security Class Initialized
DEBUG - 2025-09-06 08:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:34:16 --> Input Class Initialized
INFO - 2025-09-06 08:34:16 --> Language Class Initialized
INFO - 2025-09-06 08:34:16 --> Loader Class Initialized
INFO - 2025-09-06 08:34:16 --> Helper loaded: url_helper
INFO - 2025-09-06 08:34:16 --> Database Driver Class Initialized
ERROR - 2025-09-06 08:34:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'badmintondb' C:\xampp\htdocs\timersacademy-1\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-06 08:34:16 --> Unable to connect to the database
INFO - 2025-09-06 08:34:16 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:34:17 --> Config Class Initialized
INFO - 2025-09-06 08:34:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:34:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:34:17 --> Utf8 Class Initialized
INFO - 2025-09-06 08:34:17 --> URI Class Initialized
INFO - 2025-09-06 08:34:17 --> Router Class Initialized
INFO - 2025-09-06 08:34:17 --> Output Class Initialized
INFO - 2025-09-06 08:34:17 --> Security Class Initialized
DEBUG - 2025-09-06 08:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:34:17 --> Input Class Initialized
INFO - 2025-09-06 08:34:17 --> Language Class Initialized
INFO - 2025-09-06 08:34:17 --> Loader Class Initialized
INFO - 2025-09-06 08:34:17 --> Helper loaded: url_helper
INFO - 2025-09-06 08:34:17 --> Database Driver Class Initialized
ERROR - 2025-09-06 08:34:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'badmintondb' C:\xampp\htdocs\timersacademy-1\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-06 08:34:17 --> Unable to connect to the database
INFO - 2025-09-06 08:34:17 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:34:18 --> Config Class Initialized
INFO - 2025-09-06 08:34:18 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:34:18 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:34:18 --> Utf8 Class Initialized
INFO - 2025-09-06 08:34:18 --> URI Class Initialized
INFO - 2025-09-06 08:34:18 --> Router Class Initialized
INFO - 2025-09-06 08:34:18 --> Output Class Initialized
INFO - 2025-09-06 08:34:18 --> Security Class Initialized
DEBUG - 2025-09-06 08:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:34:18 --> Input Class Initialized
INFO - 2025-09-06 08:34:18 --> Language Class Initialized
INFO - 2025-09-06 08:34:18 --> Loader Class Initialized
INFO - 2025-09-06 08:34:18 --> Helper loaded: url_helper
INFO - 2025-09-06 08:34:18 --> Database Driver Class Initialized
ERROR - 2025-09-06 08:34:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'badmintondb' C:\xampp\htdocs\timersacademy-1\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-06 08:34:18 --> Unable to connect to the database
INFO - 2025-09-06 08:34:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:34:55 --> Config Class Initialized
INFO - 2025-09-06 08:34:55 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:34:55 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:34:55 --> Utf8 Class Initialized
INFO - 2025-09-06 08:34:55 --> URI Class Initialized
INFO - 2025-09-06 08:34:55 --> Router Class Initialized
INFO - 2025-09-06 08:34:55 --> Output Class Initialized
INFO - 2025-09-06 08:34:55 --> Security Class Initialized
DEBUG - 2025-09-06 08:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:34:55 --> Input Class Initialized
INFO - 2025-09-06 08:34:55 --> Language Class Initialized
INFO - 2025-09-06 08:34:55 --> Loader Class Initialized
INFO - 2025-09-06 08:34:55 --> Helper loaded: url_helper
INFO - 2025-09-06 08:34:55 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:34:55 --> Helper loaded: form_helper
INFO - 2025-09-06 08:34:55 --> Form Validation Class Initialized
INFO - 2025-09-06 08:34:55 --> Controller Class Initialized
INFO - 2025-09-06 08:34:55 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:34:55 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
ERROR - 2025-09-06 08:34:55 --> Query error: Table 'mybadmintondb.centers' doesn't exist - Invalid query: SELECT *
FROM `centers`
INFO - 2025-09-06 08:34:55 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:34:56 --> Config Class Initialized
INFO - 2025-09-06 08:34:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:34:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:34:56 --> Utf8 Class Initialized
INFO - 2025-09-06 08:34:56 --> URI Class Initialized
INFO - 2025-09-06 08:34:56 --> Router Class Initialized
INFO - 2025-09-06 08:34:56 --> Output Class Initialized
INFO - 2025-09-06 08:34:56 --> Security Class Initialized
DEBUG - 2025-09-06 08:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:34:56 --> Input Class Initialized
INFO - 2025-09-06 08:34:56 --> Language Class Initialized
INFO - 2025-09-06 08:34:56 --> Loader Class Initialized
INFO - 2025-09-06 08:34:56 --> Helper loaded: url_helper
INFO - 2025-09-06 08:34:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:34:56 --> Helper loaded: form_helper
INFO - 2025-09-06 08:34:56 --> Form Validation Class Initialized
INFO - 2025-09-06 08:34:56 --> Controller Class Initialized
INFO - 2025-09-06 08:34:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:34:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
ERROR - 2025-09-06 08:34:56 --> Query error: Table 'mybadmintondb.centers' doesn't exist - Invalid query: SELECT *
FROM `centers`
INFO - 2025-09-06 08:34:56 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 08:35:05 --> Config Class Initialized
INFO - 2025-09-06 08:35:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:05 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:05 --> URI Class Initialized
INFO - 2025-09-06 08:35:05 --> Router Class Initialized
INFO - 2025-09-06 08:35:05 --> Output Class Initialized
INFO - 2025-09-06 08:35:05 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:05 --> Input Class Initialized
INFO - 2025-09-06 08:35:05 --> Language Class Initialized
INFO - 2025-09-06 08:35:05 --> Loader Class Initialized
INFO - 2025-09-06 08:35:05 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:06 --> Database Driver Class Initialized
INFO - 2025-09-06 08:35:06 --> Config Class Initialized
INFO - 2025-09-06 08:35:06 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-06 08:35:06 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:06 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:06 --> URI Class Initialized
INFO - 2025-09-06 08:35:06 --> Router Class Initialized
INFO - 2025-09-06 08:35:06 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:06 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:06 --> Controller Class Initialized
INFO - 2025-09-06 08:35:06 --> Output Class Initialized
INFO - 2025-09-06 08:35:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:35:06 --> Security Class Initialized
INFO - 2025-09-06 08:35:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:35:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 08:35:06 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-06 08:35:06 --> Total execution time: 0.3297
INFO - 2025-09-06 08:35:06 --> Input Class Initialized
INFO - 2025-09-06 08:35:06 --> Language Class Initialized
INFO - 2025-09-06 08:35:06 --> Loader Class Initialized
INFO - 2025-09-06 08:35:06 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:06 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:06 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:06 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:06 --> Controller Class Initialized
INFO - 2025-09-06 08:35:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:35:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:35:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 08:35:06 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:06 --> Total execution time: 0.1868
INFO - 2025-09-06 08:35:06 --> Config Class Initialized
INFO - 2025-09-06 08:35:06 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:06 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:06 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:06 --> URI Class Initialized
INFO - 2025-09-06 08:35:06 --> Router Class Initialized
INFO - 2025-09-06 08:35:06 --> Output Class Initialized
INFO - 2025-09-06 08:35:06 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:06 --> Input Class Initialized
INFO - 2025-09-06 08:35:06 --> Language Class Initialized
INFO - 2025-09-06 08:35:06 --> Loader Class Initialized
INFO - 2025-09-06 08:35:07 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:07 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:07 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:07 --> Controller Class Initialized
INFO - 2025-09-06 08:35:07 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:07 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:07 --> Total execution time: 0.4535
INFO - 2025-09-06 08:35:16 --> Config Class Initialized
INFO - 2025-09-06 08:35:16 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:16 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:16 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:16 --> URI Class Initialized
INFO - 2025-09-06 08:35:16 --> Router Class Initialized
INFO - 2025-09-06 08:35:16 --> Output Class Initialized
INFO - 2025-09-06 08:35:16 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:16 --> Input Class Initialized
INFO - 2025-09-06 08:35:16 --> Language Class Initialized
INFO - 2025-09-06 08:35:16 --> Loader Class Initialized
INFO - 2025-09-06 08:35:16 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:16 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:17 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:17 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:17 --> Controller Class Initialized
INFO - 2025-09-06 08:35:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:35:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:35:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 08:35:17 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:17 --> Total execution time: 0.2986
INFO - 2025-09-06 08:35:17 --> Config Class Initialized
INFO - 2025-09-06 08:35:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:17 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:17 --> URI Class Initialized
INFO - 2025-09-06 08:35:17 --> Router Class Initialized
INFO - 2025-09-06 08:35:17 --> Output Class Initialized
INFO - 2025-09-06 08:35:17 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:17 --> Input Class Initialized
INFO - 2025-09-06 08:35:17 --> Language Class Initialized
INFO - 2025-09-06 08:35:17 --> Loader Class Initialized
INFO - 2025-09-06 08:35:17 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:17 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:17 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:17 --> Controller Class Initialized
INFO - 2025-09-06 08:35:17 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:17 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:17 --> Total execution time: 0.2041
INFO - 2025-09-06 08:35:17 --> Config Class Initialized
INFO - 2025-09-06 08:35:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:17 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:17 --> URI Class Initialized
INFO - 2025-09-06 08:35:17 --> Router Class Initialized
INFO - 2025-09-06 08:35:17 --> Output Class Initialized
INFO - 2025-09-06 08:35:17 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:17 --> Input Class Initialized
INFO - 2025-09-06 08:35:17 --> Language Class Initialized
INFO - 2025-09-06 08:35:17 --> Loader Class Initialized
INFO - 2025-09-06 08:35:17 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:17 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:17 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:17 --> Controller Class Initialized
INFO - 2025-09-06 08:35:17 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:17 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:17 --> Total execution time: 0.1696
INFO - 2025-09-06 08:35:22 --> Config Class Initialized
INFO - 2025-09-06 08:35:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:22 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:22 --> URI Class Initialized
INFO - 2025-09-06 08:35:22 --> Router Class Initialized
INFO - 2025-09-06 08:35:22 --> Output Class Initialized
INFO - 2025-09-06 08:35:22 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:22 --> Input Class Initialized
INFO - 2025-09-06 08:35:22 --> Language Class Initialized
INFO - 2025-09-06 08:35:22 --> Loader Class Initialized
INFO - 2025-09-06 08:35:22 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:22 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:22 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:22 --> Controller Class Initialized
INFO - 2025-09-06 08:35:22 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:22 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:22 --> Total execution time: 0.2760
INFO - 2025-09-06 08:35:23 --> Config Class Initialized
INFO - 2025-09-06 08:35:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:23 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:23 --> URI Class Initialized
INFO - 2025-09-06 08:35:23 --> Router Class Initialized
INFO - 2025-09-06 08:35:23 --> Output Class Initialized
INFO - 2025-09-06 08:35:23 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:23 --> Input Class Initialized
INFO - 2025-09-06 08:35:23 --> Language Class Initialized
INFO - 2025-09-06 08:35:23 --> Loader Class Initialized
INFO - 2025-09-06 08:35:23 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:23 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:23 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:23 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:23 --> Controller Class Initialized
INFO - 2025-09-06 08:35:23 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:23 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:23 --> Total execution time: 0.1624
INFO - 2025-09-06 08:35:31 --> Config Class Initialized
INFO - 2025-09-06 08:35:31 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:31 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:31 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:31 --> URI Class Initialized
INFO - 2025-09-06 08:35:31 --> Router Class Initialized
INFO - 2025-09-06 08:35:31 --> Output Class Initialized
INFO - 2025-09-06 08:35:32 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:32 --> Input Class Initialized
INFO - 2025-09-06 08:35:32 --> Language Class Initialized
INFO - 2025-09-06 08:35:32 --> Loader Class Initialized
INFO - 2025-09-06 08:35:32 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:32 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:32 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:32 --> Controller Class Initialized
INFO - 2025-09-06 08:35:32 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:35:32 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:35:32 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 08:35:32 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:32 --> Total execution time: 0.2431
INFO - 2025-09-06 08:35:32 --> Config Class Initialized
INFO - 2025-09-06 08:35:32 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:32 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:32 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:32 --> URI Class Initialized
INFO - 2025-09-06 08:35:32 --> Router Class Initialized
INFO - 2025-09-06 08:35:32 --> Output Class Initialized
INFO - 2025-09-06 08:35:32 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:32 --> Input Class Initialized
INFO - 2025-09-06 08:35:32 --> Language Class Initialized
INFO - 2025-09-06 08:35:32 --> Loader Class Initialized
INFO - 2025-09-06 08:35:32 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:32 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:32 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:32 --> Controller Class Initialized
INFO - 2025-09-06 08:35:32 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:32 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:32 --> Total execution time: 0.4055
INFO - 2025-09-06 08:35:35 --> Config Class Initialized
INFO - 2025-09-06 08:35:35 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:35 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:35 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:35 --> URI Class Initialized
INFO - 2025-09-06 08:35:35 --> Router Class Initialized
INFO - 2025-09-06 08:35:35 --> Output Class Initialized
INFO - 2025-09-06 08:35:35 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:35 --> Input Class Initialized
INFO - 2025-09-06 08:35:35 --> Language Class Initialized
INFO - 2025-09-06 08:35:35 --> Loader Class Initialized
INFO - 2025-09-06 08:35:35 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:35 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:35 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:35 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:35 --> Controller Class Initialized
INFO - 2025-09-06 08:35:35 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:35:35 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:35:35 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 08:35:35 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:35 --> Total execution time: 0.1304
INFO - 2025-09-06 08:35:35 --> Config Class Initialized
INFO - 2025-09-06 08:35:35 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:35 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:35 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:35 --> URI Class Initialized
INFO - 2025-09-06 08:35:35 --> Router Class Initialized
INFO - 2025-09-06 08:35:35 --> Output Class Initialized
INFO - 2025-09-06 08:35:35 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:35 --> Input Class Initialized
INFO - 2025-09-06 08:35:35 --> Language Class Initialized
INFO - 2025-09-06 08:35:35 --> Loader Class Initialized
INFO - 2025-09-06 08:35:35 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:35 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:35 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:35 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:35 --> Controller Class Initialized
INFO - 2025-09-06 08:35:35 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:35 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:35 --> Total execution time: 0.1842
INFO - 2025-09-06 08:35:35 --> Config Class Initialized
INFO - 2025-09-06 08:35:35 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:35 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:35 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:35 --> URI Class Initialized
INFO - 2025-09-06 08:35:35 --> Router Class Initialized
INFO - 2025-09-06 08:35:35 --> Output Class Initialized
INFO - 2025-09-06 08:35:35 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:35 --> Input Class Initialized
INFO - 2025-09-06 08:35:35 --> Language Class Initialized
INFO - 2025-09-06 08:35:35 --> Loader Class Initialized
INFO - 2025-09-06 08:35:35 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:35 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:35 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:35 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:35 --> Controller Class Initialized
INFO - 2025-09-06 08:35:35 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:35 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:35 --> Total execution time: 0.1612
INFO - 2025-09-06 08:35:39 --> Config Class Initialized
INFO - 2025-09-06 08:35:39 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:35:39 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:35:39 --> Utf8 Class Initialized
INFO - 2025-09-06 08:35:39 --> URI Class Initialized
INFO - 2025-09-06 08:35:39 --> Router Class Initialized
INFO - 2025-09-06 08:35:39 --> Output Class Initialized
INFO - 2025-09-06 08:35:39 --> Security Class Initialized
DEBUG - 2025-09-06 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:35:39 --> Input Class Initialized
INFO - 2025-09-06 08:35:39 --> Language Class Initialized
INFO - 2025-09-06 08:35:39 --> Loader Class Initialized
INFO - 2025-09-06 08:35:39 --> Helper loaded: url_helper
INFO - 2025-09-06 08:35:39 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:35:39 --> Helper loaded: form_helper
INFO - 2025-09-06 08:35:39 --> Form Validation Class Initialized
INFO - 2025-09-06 08:35:39 --> Controller Class Initialized
INFO - 2025-09-06 08:35:39 --> Model "Center_model" initialized
INFO - 2025-09-06 08:35:39 --> Final output sent to browser
DEBUG - 2025-09-06 08:35:39 --> Total execution time: 0.2947
INFO - 2025-09-06 08:36:22 --> Config Class Initialized
INFO - 2025-09-06 08:36:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:36:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:36:22 --> Utf8 Class Initialized
INFO - 2025-09-06 08:36:22 --> URI Class Initialized
INFO - 2025-09-06 08:36:22 --> Router Class Initialized
INFO - 2025-09-06 08:36:22 --> Output Class Initialized
INFO - 2025-09-06 08:36:22 --> Security Class Initialized
DEBUG - 2025-09-06 08:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:36:22 --> Input Class Initialized
INFO - 2025-09-06 08:36:22 --> Language Class Initialized
INFO - 2025-09-06 08:36:22 --> Loader Class Initialized
INFO - 2025-09-06 08:36:22 --> Helper loaded: url_helper
INFO - 2025-09-06 08:36:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:36:22 --> Helper loaded: form_helper
INFO - 2025-09-06 08:36:22 --> Form Validation Class Initialized
INFO - 2025-09-06 08:36:22 --> Controller Class Initialized
INFO - 2025-09-06 08:36:22 --> Model "Center_model" initialized
INFO - 2025-09-06 08:36:22 --> Final output sent to browser
DEBUG - 2025-09-06 08:36:22 --> Total execution time: 0.2772
INFO - 2025-09-06 08:36:22 --> Config Class Initialized
INFO - 2025-09-06 08:36:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:36:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:36:22 --> Utf8 Class Initialized
INFO - 2025-09-06 08:36:22 --> URI Class Initialized
INFO - 2025-09-06 08:36:22 --> Router Class Initialized
INFO - 2025-09-06 08:36:22 --> Output Class Initialized
INFO - 2025-09-06 08:36:22 --> Security Class Initialized
DEBUG - 2025-09-06 08:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:36:22 --> Input Class Initialized
INFO - 2025-09-06 08:36:22 --> Language Class Initialized
INFO - 2025-09-06 08:36:22 --> Loader Class Initialized
INFO - 2025-09-06 08:36:22 --> Helper loaded: url_helper
INFO - 2025-09-06 08:36:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:36:22 --> Helper loaded: form_helper
INFO - 2025-09-06 08:36:22 --> Form Validation Class Initialized
INFO - 2025-09-06 08:36:22 --> Controller Class Initialized
INFO - 2025-09-06 08:36:22 --> Model "Center_model" initialized
INFO - 2025-09-06 08:36:22 --> Final output sent to browser
DEBUG - 2025-09-06 08:36:22 --> Total execution time: 0.1455
INFO - 2025-09-06 08:37:53 --> Config Class Initialized
INFO - 2025-09-06 08:37:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:37:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:37:53 --> Utf8 Class Initialized
INFO - 2025-09-06 08:37:53 --> URI Class Initialized
INFO - 2025-09-06 08:37:53 --> Router Class Initialized
INFO - 2025-09-06 08:37:53 --> Output Class Initialized
INFO - 2025-09-06 08:37:53 --> Security Class Initialized
DEBUG - 2025-09-06 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:37:53 --> Input Class Initialized
INFO - 2025-09-06 08:37:53 --> Language Class Initialized
INFO - 2025-09-06 08:37:53 --> Loader Class Initialized
INFO - 2025-09-06 08:37:53 --> Helper loaded: url_helper
INFO - 2025-09-06 08:37:53 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:37:53 --> Helper loaded: form_helper
INFO - 2025-09-06 08:37:53 --> Form Validation Class Initialized
INFO - 2025-09-06 08:37:53 --> Controller Class Initialized
INFO - 2025-09-06 08:37:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:37:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:37:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 08:37:53 --> Final output sent to browser
DEBUG - 2025-09-06 08:37:53 --> Total execution time: 0.1469
INFO - 2025-09-06 08:37:53 --> Config Class Initialized
INFO - 2025-09-06 08:37:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:37:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:37:53 --> Utf8 Class Initialized
INFO - 2025-09-06 08:37:53 --> URI Class Initialized
INFO - 2025-09-06 08:37:53 --> Router Class Initialized
INFO - 2025-09-06 08:37:53 --> Output Class Initialized
INFO - 2025-09-06 08:37:53 --> Security Class Initialized
DEBUG - 2025-09-06 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:37:53 --> Input Class Initialized
INFO - 2025-09-06 08:37:53 --> Language Class Initialized
INFO - 2025-09-06 08:37:53 --> Loader Class Initialized
INFO - 2025-09-06 08:37:53 --> Helper loaded: url_helper
INFO - 2025-09-06 08:37:53 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:37:53 --> Helper loaded: form_helper
INFO - 2025-09-06 08:37:53 --> Form Validation Class Initialized
INFO - 2025-09-06 08:37:53 --> Controller Class Initialized
INFO - 2025-09-06 08:37:53 --> Model "Center_model" initialized
INFO - 2025-09-06 08:37:53 --> Final output sent to browser
DEBUG - 2025-09-06 08:37:53 --> Total execution time: 0.1514
INFO - 2025-09-06 08:38:05 --> Config Class Initialized
INFO - 2025-09-06 08:38:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:05 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:05 --> URI Class Initialized
INFO - 2025-09-06 08:38:05 --> Router Class Initialized
INFO - 2025-09-06 08:38:05 --> Output Class Initialized
INFO - 2025-09-06 08:38:05 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:05 --> Input Class Initialized
INFO - 2025-09-06 08:38:05 --> Language Class Initialized
INFO - 2025-09-06 08:38:05 --> Loader Class Initialized
INFO - 2025-09-06 08:38:05 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:05 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:05 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:05 --> Controller Class Initialized
INFO - 2025-09-06 08:38:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:38:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:38:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 08:38:05 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:05 --> Total execution time: 0.1539
INFO - 2025-09-06 08:38:06 --> Config Class Initialized
INFO - 2025-09-06 08:38:06 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:06 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:06 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:06 --> URI Class Initialized
INFO - 2025-09-06 08:38:06 --> Router Class Initialized
INFO - 2025-09-06 08:38:06 --> Output Class Initialized
INFO - 2025-09-06 08:38:06 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:06 --> Input Class Initialized
INFO - 2025-09-06 08:38:06 --> Language Class Initialized
INFO - 2025-09-06 08:38:06 --> Loader Class Initialized
INFO - 2025-09-06 08:38:06 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:06 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:06 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:06 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:06 --> Controller Class Initialized
INFO - 2025-09-06 08:38:06 --> Model "Center_model" initialized
INFO - 2025-09-06 08:38:06 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:06 --> Total execution time: 0.1585
INFO - 2025-09-06 08:38:26 --> Config Class Initialized
INFO - 2025-09-06 08:38:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:26 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:26 --> URI Class Initialized
INFO - 2025-09-06 08:38:26 --> Router Class Initialized
INFO - 2025-09-06 08:38:26 --> Output Class Initialized
INFO - 2025-09-06 08:38:26 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:26 --> Input Class Initialized
INFO - 2025-09-06 08:38:26 --> Language Class Initialized
INFO - 2025-09-06 08:38:26 --> Loader Class Initialized
INFO - 2025-09-06 08:38:26 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:26 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:26 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:26 --> Controller Class Initialized
INFO - 2025-09-06 08:38:26 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:38:26 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:38:26 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 08:38:26 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:26 --> Total execution time: 0.1125
INFO - 2025-09-06 08:38:27 --> Config Class Initialized
INFO - 2025-09-06 08:38:27 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:27 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:27 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:27 --> URI Class Initialized
INFO - 2025-09-06 08:38:27 --> Router Class Initialized
INFO - 2025-09-06 08:38:27 --> Output Class Initialized
INFO - 2025-09-06 08:38:27 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:27 --> Input Class Initialized
INFO - 2025-09-06 08:38:27 --> Language Class Initialized
INFO - 2025-09-06 08:38:27 --> Loader Class Initialized
INFO - 2025-09-06 08:38:27 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:27 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:27 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:27 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:27 --> Controller Class Initialized
INFO - 2025-09-06 08:38:27 --> Model "Center_model" initialized
INFO - 2025-09-06 08:38:27 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:27 --> Total execution time: 0.1386
INFO - 2025-09-06 08:38:29 --> Config Class Initialized
INFO - 2025-09-06 08:38:29 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:29 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:29 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:29 --> URI Class Initialized
INFO - 2025-09-06 08:38:29 --> Router Class Initialized
INFO - 2025-09-06 08:38:29 --> Output Class Initialized
INFO - 2025-09-06 08:38:29 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:29 --> Input Class Initialized
INFO - 2025-09-06 08:38:29 --> Language Class Initialized
INFO - 2025-09-06 08:38:29 --> Loader Class Initialized
INFO - 2025-09-06 08:38:29 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:29 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:29 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:29 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:29 --> Controller Class Initialized
INFO - 2025-09-06 08:38:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:38:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:38:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 08:38:29 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:29 --> Total execution time: 0.1747
INFO - 2025-09-06 08:38:30 --> Config Class Initialized
INFO - 2025-09-06 08:38:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:30 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:30 --> URI Class Initialized
INFO - 2025-09-06 08:38:30 --> Router Class Initialized
INFO - 2025-09-06 08:38:30 --> Output Class Initialized
INFO - 2025-09-06 08:38:30 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:30 --> Input Class Initialized
INFO - 2025-09-06 08:38:30 --> Language Class Initialized
INFO - 2025-09-06 08:38:30 --> Loader Class Initialized
INFO - 2025-09-06 08:38:30 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:30 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:30 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:30 --> Controller Class Initialized
INFO - 2025-09-06 08:38:30 --> Model "Center_model" initialized
INFO - 2025-09-06 08:38:30 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:30 --> Total execution time: 0.1180
INFO - 2025-09-06 08:38:30 --> Config Class Initialized
INFO - 2025-09-06 08:38:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:30 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:30 --> URI Class Initialized
INFO - 2025-09-06 08:38:30 --> Router Class Initialized
INFO - 2025-09-06 08:38:30 --> Output Class Initialized
INFO - 2025-09-06 08:38:30 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:30 --> Input Class Initialized
INFO - 2025-09-06 08:38:30 --> Language Class Initialized
INFO - 2025-09-06 08:38:30 --> Loader Class Initialized
INFO - 2025-09-06 08:38:30 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:30 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:30 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:30 --> Controller Class Initialized
INFO - 2025-09-06 08:38:30 --> Model "Center_model" initialized
INFO - 2025-09-06 08:38:30 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:30 --> Total execution time: 0.0959
INFO - 2025-09-06 08:38:38 --> Config Class Initialized
INFO - 2025-09-06 08:38:38 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:38 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:38 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:38 --> URI Class Initialized
INFO - 2025-09-06 08:38:38 --> Router Class Initialized
INFO - 2025-09-06 08:38:38 --> Output Class Initialized
INFO - 2025-09-06 08:38:38 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:38 --> Input Class Initialized
INFO - 2025-09-06 08:38:38 --> Language Class Initialized
INFO - 2025-09-06 08:38:38 --> Loader Class Initialized
INFO - 2025-09-06 08:38:38 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:38 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:38 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:38 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:38 --> Controller Class Initialized
INFO - 2025-09-06 08:38:38 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:38:38 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:38:38 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 08:38:38 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:38 --> Total execution time: 0.1271
INFO - 2025-09-06 08:38:38 --> Config Class Initialized
INFO - 2025-09-06 08:38:38 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:38 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:38 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:38 --> URI Class Initialized
INFO - 2025-09-06 08:38:38 --> Router Class Initialized
INFO - 2025-09-06 08:38:38 --> Output Class Initialized
INFO - 2025-09-06 08:38:38 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:38 --> Input Class Initialized
INFO - 2025-09-06 08:38:38 --> Language Class Initialized
INFO - 2025-09-06 08:38:38 --> Loader Class Initialized
INFO - 2025-09-06 08:38:38 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:38 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:38 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:38 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:38 --> Controller Class Initialized
INFO - 2025-09-06 08:38:38 --> Model "Center_model" initialized
INFO - 2025-09-06 08:38:38 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:38 --> Total execution time: 0.1277
INFO - 2025-09-06 08:38:46 --> Config Class Initialized
INFO - 2025-09-06 08:38:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:46 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:46 --> URI Class Initialized
INFO - 2025-09-06 08:38:46 --> Router Class Initialized
INFO - 2025-09-06 08:38:46 --> Output Class Initialized
INFO - 2025-09-06 08:38:46 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:46 --> Input Class Initialized
INFO - 2025-09-06 08:38:46 --> Language Class Initialized
INFO - 2025-09-06 08:38:46 --> Loader Class Initialized
INFO - 2025-09-06 08:38:46 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:46 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:46 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:46 --> Controller Class Initialized
INFO - 2025-09-06 08:38:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:38:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:38:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 08:38:46 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:46 --> Total execution time: 0.1675
INFO - 2025-09-06 08:38:46 --> Config Class Initialized
INFO - 2025-09-06 08:38:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:46 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:46 --> URI Class Initialized
INFO - 2025-09-06 08:38:46 --> Router Class Initialized
INFO - 2025-09-06 08:38:46 --> Output Class Initialized
INFO - 2025-09-06 08:38:46 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:46 --> Input Class Initialized
INFO - 2025-09-06 08:38:46 --> Language Class Initialized
INFO - 2025-09-06 08:38:46 --> Loader Class Initialized
INFO - 2025-09-06 08:38:46 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:46 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:46 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:46 --> Controller Class Initialized
INFO - 2025-09-06 08:38:46 --> Model "Center_model" initialized
INFO - 2025-09-06 08:38:46 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:46 --> Total execution time: 0.1090
INFO - 2025-09-06 08:38:46 --> Config Class Initialized
INFO - 2025-09-06 08:38:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:46 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:46 --> URI Class Initialized
INFO - 2025-09-06 08:38:46 --> Router Class Initialized
INFO - 2025-09-06 08:38:46 --> Output Class Initialized
INFO - 2025-09-06 08:38:46 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:46 --> Input Class Initialized
INFO - 2025-09-06 08:38:46 --> Language Class Initialized
INFO - 2025-09-06 08:38:46 --> Loader Class Initialized
INFO - 2025-09-06 08:38:46 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:46 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:46 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:46 --> Controller Class Initialized
INFO - 2025-09-06 08:38:46 --> Model "Center_model" initialized
INFO - 2025-09-06 08:38:46 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:46 --> Total execution time: 0.1050
INFO - 2025-09-06 08:38:51 --> Config Class Initialized
INFO - 2025-09-06 08:38:51 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:38:51 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:38:51 --> Utf8 Class Initialized
INFO - 2025-09-06 08:38:51 --> URI Class Initialized
INFO - 2025-09-06 08:38:51 --> Router Class Initialized
INFO - 2025-09-06 08:38:51 --> Output Class Initialized
INFO - 2025-09-06 08:38:51 --> Security Class Initialized
DEBUG - 2025-09-06 08:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:38:51 --> Input Class Initialized
INFO - 2025-09-06 08:38:51 --> Language Class Initialized
INFO - 2025-09-06 08:38:51 --> Loader Class Initialized
INFO - 2025-09-06 08:38:51 --> Helper loaded: url_helper
INFO - 2025-09-06 08:38:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:38:51 --> Helper loaded: form_helper
INFO - 2025-09-06 08:38:51 --> Form Validation Class Initialized
INFO - 2025-09-06 08:38:51 --> Controller Class Initialized
INFO - 2025-09-06 08:38:51 --> Model "Center_model" initialized
INFO - 2025-09-06 08:38:51 --> Final output sent to browser
DEBUG - 2025-09-06 08:38:51 --> Total execution time: 0.1245
INFO - 2025-09-06 08:39:20 --> Config Class Initialized
INFO - 2025-09-06 08:39:20 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:39:20 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:39:20 --> Utf8 Class Initialized
INFO - 2025-09-06 08:39:20 --> URI Class Initialized
INFO - 2025-09-06 08:39:20 --> Router Class Initialized
INFO - 2025-09-06 08:39:20 --> Output Class Initialized
INFO - 2025-09-06 08:39:20 --> Security Class Initialized
DEBUG - 2025-09-06 08:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:39:20 --> Input Class Initialized
INFO - 2025-09-06 08:39:20 --> Language Class Initialized
INFO - 2025-09-06 08:39:20 --> Loader Class Initialized
INFO - 2025-09-06 08:39:20 --> Helper loaded: url_helper
INFO - 2025-09-06 08:39:20 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:39:20 --> Helper loaded: form_helper
INFO - 2025-09-06 08:39:20 --> Form Validation Class Initialized
INFO - 2025-09-06 08:39:20 --> Controller Class Initialized
INFO - 2025-09-06 08:39:20 --> Model "Center_model" initialized
INFO - 2025-09-06 08:39:20 --> Final output sent to browser
DEBUG - 2025-09-06 08:39:20 --> Total execution time: 0.1167
INFO - 2025-09-06 08:39:26 --> Config Class Initialized
INFO - 2025-09-06 08:39:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:39:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:39:26 --> Utf8 Class Initialized
INFO - 2025-09-06 08:39:26 --> URI Class Initialized
INFO - 2025-09-06 08:39:26 --> Router Class Initialized
INFO - 2025-09-06 08:39:26 --> Output Class Initialized
INFO - 2025-09-06 08:39:26 --> Security Class Initialized
DEBUG - 2025-09-06 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:39:26 --> Input Class Initialized
INFO - 2025-09-06 08:39:26 --> Language Class Initialized
INFO - 2025-09-06 08:39:26 --> Loader Class Initialized
INFO - 2025-09-06 08:39:26 --> Helper loaded: url_helper
INFO - 2025-09-06 08:39:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:39:26 --> Helper loaded: form_helper
INFO - 2025-09-06 08:39:26 --> Form Validation Class Initialized
INFO - 2025-09-06 08:39:26 --> Controller Class Initialized
INFO - 2025-09-06 08:39:26 --> Model "Center_model" initialized
INFO - 2025-09-06 08:39:26 --> Final output sent to browser
DEBUG - 2025-09-06 08:39:26 --> Total execution time: 0.1103
INFO - 2025-09-06 08:39:29 --> Config Class Initialized
INFO - 2025-09-06 08:39:29 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:39:29 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:39:29 --> Utf8 Class Initialized
INFO - 2025-09-06 08:39:29 --> URI Class Initialized
INFO - 2025-09-06 08:39:29 --> Router Class Initialized
INFO - 2025-09-06 08:39:29 --> Output Class Initialized
INFO - 2025-09-06 08:39:29 --> Security Class Initialized
DEBUG - 2025-09-06 08:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:39:29 --> Input Class Initialized
INFO - 2025-09-06 08:39:29 --> Language Class Initialized
INFO - 2025-09-06 08:39:29 --> Loader Class Initialized
INFO - 2025-09-06 08:39:29 --> Helper loaded: url_helper
INFO - 2025-09-06 08:39:29 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:39:29 --> Helper loaded: form_helper
INFO - 2025-09-06 08:39:29 --> Form Validation Class Initialized
INFO - 2025-09-06 08:39:29 --> Controller Class Initialized
INFO - 2025-09-06 08:39:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:39:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:39:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 08:39:29 --> Final output sent to browser
DEBUG - 2025-09-06 08:39:29 --> Total execution time: 0.1395
INFO - 2025-09-06 08:39:29 --> Config Class Initialized
INFO - 2025-09-06 08:39:29 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:39:29 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:39:29 --> Utf8 Class Initialized
INFO - 2025-09-06 08:39:29 --> URI Class Initialized
INFO - 2025-09-06 08:39:29 --> Router Class Initialized
INFO - 2025-09-06 08:39:29 --> Output Class Initialized
INFO - 2025-09-06 08:39:29 --> Security Class Initialized
DEBUG - 2025-09-06 08:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:39:29 --> Input Class Initialized
INFO - 2025-09-06 08:39:29 --> Language Class Initialized
INFO - 2025-09-06 08:39:29 --> Loader Class Initialized
INFO - 2025-09-06 08:39:29 --> Helper loaded: url_helper
INFO - 2025-09-06 08:39:29 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:39:29 --> Helper loaded: form_helper
INFO - 2025-09-06 08:39:29 --> Form Validation Class Initialized
INFO - 2025-09-06 08:39:29 --> Controller Class Initialized
INFO - 2025-09-06 08:39:29 --> Model "Center_model" initialized
INFO - 2025-09-06 08:39:29 --> Final output sent to browser
DEBUG - 2025-09-06 08:39:29 --> Total execution time: 0.1364
INFO - 2025-09-06 08:39:33 --> Config Class Initialized
INFO - 2025-09-06 08:39:33 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:39:33 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:39:33 --> Utf8 Class Initialized
INFO - 2025-09-06 08:39:33 --> URI Class Initialized
INFO - 2025-09-06 08:39:33 --> Router Class Initialized
INFO - 2025-09-06 08:39:33 --> Output Class Initialized
INFO - 2025-09-06 08:39:33 --> Security Class Initialized
DEBUG - 2025-09-06 08:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:39:33 --> Input Class Initialized
INFO - 2025-09-06 08:39:33 --> Language Class Initialized
INFO - 2025-09-06 08:39:33 --> Loader Class Initialized
INFO - 2025-09-06 08:39:33 --> Helper loaded: url_helper
INFO - 2025-09-06 08:39:33 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:39:33 --> Helper loaded: form_helper
INFO - 2025-09-06 08:39:33 --> Form Validation Class Initialized
INFO - 2025-09-06 08:39:33 --> Controller Class Initialized
INFO - 2025-09-06 08:39:33 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:39:33 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:39:33 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 08:39:33 --> Final output sent to browser
DEBUG - 2025-09-06 08:39:33 --> Total execution time: 0.1675
INFO - 2025-09-06 08:39:34 --> Config Class Initialized
INFO - 2025-09-06 08:39:34 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:39:34 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:39:34 --> Utf8 Class Initialized
INFO - 2025-09-06 08:39:34 --> URI Class Initialized
INFO - 2025-09-06 08:39:34 --> Router Class Initialized
INFO - 2025-09-06 08:39:34 --> Output Class Initialized
INFO - 2025-09-06 08:39:34 --> Security Class Initialized
DEBUG - 2025-09-06 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:39:34 --> Input Class Initialized
INFO - 2025-09-06 08:39:34 --> Language Class Initialized
INFO - 2025-09-06 08:39:34 --> Loader Class Initialized
INFO - 2025-09-06 08:39:34 --> Helper loaded: url_helper
INFO - 2025-09-06 08:39:34 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:39:34 --> Helper loaded: form_helper
INFO - 2025-09-06 08:39:34 --> Form Validation Class Initialized
INFO - 2025-09-06 08:39:34 --> Controller Class Initialized
INFO - 2025-09-06 08:39:34 --> Model "Center_model" initialized
INFO - 2025-09-06 08:39:34 --> Final output sent to browser
DEBUG - 2025-09-06 08:39:34 --> Total execution time: 0.1613
INFO - 2025-09-06 08:39:34 --> Config Class Initialized
INFO - 2025-09-06 08:39:34 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:39:34 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:39:34 --> Utf8 Class Initialized
INFO - 2025-09-06 08:39:34 --> URI Class Initialized
INFO - 2025-09-06 08:39:34 --> Router Class Initialized
INFO - 2025-09-06 08:39:34 --> Output Class Initialized
INFO - 2025-09-06 08:39:34 --> Security Class Initialized
DEBUG - 2025-09-06 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:39:34 --> Input Class Initialized
INFO - 2025-09-06 08:39:34 --> Language Class Initialized
INFO - 2025-09-06 08:39:34 --> Loader Class Initialized
INFO - 2025-09-06 08:39:34 --> Helper loaded: url_helper
INFO - 2025-09-06 08:39:34 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:39:34 --> Helper loaded: form_helper
INFO - 2025-09-06 08:39:34 --> Form Validation Class Initialized
INFO - 2025-09-06 08:39:34 --> Controller Class Initialized
INFO - 2025-09-06 08:39:34 --> Model "Center_model" initialized
INFO - 2025-09-06 08:39:34 --> Final output sent to browser
DEBUG - 2025-09-06 08:39:34 --> Total execution time: 0.1261
INFO - 2025-09-06 08:39:44 --> Config Class Initialized
INFO - 2025-09-06 08:39:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:39:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:39:44 --> Utf8 Class Initialized
INFO - 2025-09-06 08:39:44 --> URI Class Initialized
INFO - 2025-09-06 08:39:44 --> Router Class Initialized
INFO - 2025-09-06 08:39:44 --> Output Class Initialized
INFO - 2025-09-06 08:39:44 --> Security Class Initialized
DEBUG - 2025-09-06 08:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:39:44 --> Input Class Initialized
INFO - 2025-09-06 08:39:44 --> Language Class Initialized
INFO - 2025-09-06 08:39:44 --> Loader Class Initialized
INFO - 2025-09-06 08:39:44 --> Helper loaded: url_helper
INFO - 2025-09-06 08:39:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:39:44 --> Helper loaded: form_helper
INFO - 2025-09-06 08:39:44 --> Form Validation Class Initialized
INFO - 2025-09-06 08:39:44 --> Controller Class Initialized
INFO - 2025-09-06 08:39:44 --> Model "Center_model" initialized
INFO - 2025-09-06 08:39:44 --> Final output sent to browser
DEBUG - 2025-09-06 08:39:44 --> Total execution time: 0.1540
INFO - 2025-09-06 08:45:15 --> Config Class Initialized
INFO - 2025-09-06 08:45:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:45:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:45:15 --> Utf8 Class Initialized
INFO - 2025-09-06 08:45:15 --> URI Class Initialized
INFO - 2025-09-06 08:45:15 --> Router Class Initialized
INFO - 2025-09-06 08:45:15 --> Output Class Initialized
INFO - 2025-09-06 08:45:15 --> Security Class Initialized
DEBUG - 2025-09-06 08:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:45:15 --> Input Class Initialized
INFO - 2025-09-06 08:45:15 --> Language Class Initialized
INFO - 2025-09-06 08:45:15 --> Loader Class Initialized
INFO - 2025-09-06 08:45:15 --> Helper loaded: url_helper
INFO - 2025-09-06 08:45:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:45:15 --> Helper loaded: form_helper
INFO - 2025-09-06 08:45:15 --> Form Validation Class Initialized
INFO - 2025-09-06 08:45:15 --> Controller Class Initialized
INFO - 2025-09-06 08:45:15 --> Model "Center_model" initialized
INFO - 2025-09-06 08:45:15 --> Final output sent to browser
DEBUG - 2025-09-06 08:45:15 --> Total execution time: 0.0840
INFO - 2025-09-06 08:47:40 --> Config Class Initialized
INFO - 2025-09-06 08:47:40 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:47:40 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:47:40 --> Utf8 Class Initialized
INFO - 2025-09-06 08:47:40 --> URI Class Initialized
INFO - 2025-09-06 08:47:40 --> Router Class Initialized
INFO - 2025-09-06 08:47:40 --> Output Class Initialized
INFO - 2025-09-06 08:47:40 --> Security Class Initialized
DEBUG - 2025-09-06 08:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:47:40 --> Input Class Initialized
INFO - 2025-09-06 08:47:40 --> Language Class Initialized
INFO - 2025-09-06 08:47:40 --> Loader Class Initialized
INFO - 2025-09-06 08:47:40 --> Helper loaded: url_helper
INFO - 2025-09-06 08:47:40 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:47:40 --> Helper loaded: form_helper
INFO - 2025-09-06 08:47:40 --> Form Validation Class Initialized
INFO - 2025-09-06 08:47:40 --> Controller Class Initialized
INFO - 2025-09-06 08:47:40 --> Model "Center_model" initialized
INFO - 2025-09-06 08:47:40 --> Final output sent to browser
DEBUG - 2025-09-06 08:47:40 --> Total execution time: 0.0985
INFO - 2025-09-06 08:47:44 --> Config Class Initialized
INFO - 2025-09-06 08:47:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:47:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:47:44 --> Utf8 Class Initialized
INFO - 2025-09-06 08:47:44 --> URI Class Initialized
INFO - 2025-09-06 08:47:44 --> Router Class Initialized
INFO - 2025-09-06 08:47:44 --> Output Class Initialized
INFO - 2025-09-06 08:47:44 --> Security Class Initialized
DEBUG - 2025-09-06 08:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:47:44 --> Input Class Initialized
INFO - 2025-09-06 08:47:44 --> Language Class Initialized
INFO - 2025-09-06 08:47:44 --> Loader Class Initialized
INFO - 2025-09-06 08:47:44 --> Helper loaded: url_helper
INFO - 2025-09-06 08:47:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:47:44 --> Helper loaded: form_helper
INFO - 2025-09-06 08:47:44 --> Form Validation Class Initialized
INFO - 2025-09-06 08:47:44 --> Controller Class Initialized
INFO - 2025-09-06 08:47:44 --> Model "Center_model" initialized
INFO - 2025-09-06 08:47:44 --> Final output sent to browser
DEBUG - 2025-09-06 08:47:44 --> Total execution time: 0.0986
INFO - 2025-09-06 08:48:26 --> Config Class Initialized
INFO - 2025-09-06 08:48:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:48:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:48:26 --> Utf8 Class Initialized
INFO - 2025-09-06 08:48:26 --> URI Class Initialized
INFO - 2025-09-06 08:48:26 --> Router Class Initialized
INFO - 2025-09-06 08:48:26 --> Output Class Initialized
INFO - 2025-09-06 08:48:26 --> Security Class Initialized
DEBUG - 2025-09-06 08:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:48:26 --> Input Class Initialized
INFO - 2025-09-06 08:48:26 --> Language Class Initialized
ERROR - 2025-09-06 08:48:26 --> 404 Page Not Found: Batch/addBatch
INFO - 2025-09-06 08:52:21 --> Config Class Initialized
INFO - 2025-09-06 08:52:21 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:52:21 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:52:21 --> Utf8 Class Initialized
INFO - 2025-09-06 08:52:21 --> URI Class Initialized
INFO - 2025-09-06 08:52:21 --> Router Class Initialized
INFO - 2025-09-06 08:52:21 --> Output Class Initialized
INFO - 2025-09-06 08:52:21 --> Security Class Initialized
DEBUG - 2025-09-06 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:52:21 --> Input Class Initialized
INFO - 2025-09-06 08:52:21 --> Language Class Initialized
INFO - 2025-09-06 08:52:22 --> Loader Class Initialized
INFO - 2025-09-06 08:52:22 --> Helper loaded: url_helper
INFO - 2025-09-06 08:52:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:52:22 --> Helper loaded: form_helper
INFO - 2025-09-06 08:52:22 --> Form Validation Class Initialized
INFO - 2025-09-06 08:52:22 --> Controller Class Initialized
INFO - 2025-09-06 08:52:22 --> Model "Center_model" initialized
INFO - 2025-09-06 08:52:22 --> Final output sent to browser
DEBUG - 2025-09-06 08:52:22 --> Total execution time: 0.1270
INFO - 2025-09-06 08:52:26 --> Config Class Initialized
INFO - 2025-09-06 08:52:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:52:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:52:26 --> Utf8 Class Initialized
INFO - 2025-09-06 08:52:26 --> URI Class Initialized
INFO - 2025-09-06 08:52:26 --> Router Class Initialized
INFO - 2025-09-06 08:52:26 --> Output Class Initialized
INFO - 2025-09-06 08:52:26 --> Security Class Initialized
DEBUG - 2025-09-06 08:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:52:26 --> Input Class Initialized
INFO - 2025-09-06 08:52:26 --> Language Class Initialized
INFO - 2025-09-06 08:52:26 --> Loader Class Initialized
INFO - 2025-09-06 08:52:26 --> Helper loaded: url_helper
INFO - 2025-09-06 08:52:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:52:26 --> Helper loaded: form_helper
INFO - 2025-09-06 08:52:26 --> Form Validation Class Initialized
INFO - 2025-09-06 08:52:26 --> Controller Class Initialized
INFO - 2025-09-06 08:52:26 --> Model "Center_model" initialized
INFO - 2025-09-06 08:52:26 --> Final output sent to browser
DEBUG - 2025-09-06 08:52:26 --> Total execution time: 0.1414
INFO - 2025-09-06 08:52:30 --> Config Class Initialized
INFO - 2025-09-06 08:52:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:52:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:52:30 --> Utf8 Class Initialized
INFO - 2025-09-06 08:52:30 --> URI Class Initialized
INFO - 2025-09-06 08:52:30 --> Router Class Initialized
INFO - 2025-09-06 08:52:30 --> Output Class Initialized
INFO - 2025-09-06 08:52:30 --> Security Class Initialized
DEBUG - 2025-09-06 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:52:30 --> Input Class Initialized
INFO - 2025-09-06 08:52:30 --> Language Class Initialized
INFO - 2025-09-06 08:52:30 --> Loader Class Initialized
INFO - 2025-09-06 08:52:30 --> Helper loaded: url_helper
INFO - 2025-09-06 08:52:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:52:30 --> Helper loaded: form_helper
INFO - 2025-09-06 08:52:30 --> Form Validation Class Initialized
INFO - 2025-09-06 08:52:30 --> Controller Class Initialized
INFO - 2025-09-06 08:52:30 --> Model "Center_model" initialized
INFO - 2025-09-06 08:52:30 --> Final output sent to browser
DEBUG - 2025-09-06 08:52:30 --> Total execution time: 0.1228
INFO - 2025-09-06 08:53:47 --> Config Class Initialized
INFO - 2025-09-06 08:53:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:53:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:53:47 --> Utf8 Class Initialized
INFO - 2025-09-06 08:53:47 --> URI Class Initialized
INFO - 2025-09-06 08:53:47 --> Router Class Initialized
INFO - 2025-09-06 08:53:47 --> Output Class Initialized
INFO - 2025-09-06 08:53:47 --> Security Class Initialized
DEBUG - 2025-09-06 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:53:47 --> Input Class Initialized
INFO - 2025-09-06 08:53:47 --> Language Class Initialized
INFO - 2025-09-06 08:53:47 --> Loader Class Initialized
INFO - 2025-09-06 08:53:47 --> Helper loaded: url_helper
INFO - 2025-09-06 08:53:47 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:53:47 --> Helper loaded: form_helper
INFO - 2025-09-06 08:53:47 --> Form Validation Class Initialized
INFO - 2025-09-06 08:53:47 --> Controller Class Initialized
INFO - 2025-09-06 08:53:47 --> Model "Center_model" initialized
INFO - 2025-09-06 08:53:47 --> Final output sent to browser
DEBUG - 2025-09-06 08:53:47 --> Total execution time: 0.1240
INFO - 2025-09-06 08:53:50 --> Config Class Initialized
INFO - 2025-09-06 08:53:50 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:53:50 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:53:50 --> Utf8 Class Initialized
INFO - 2025-09-06 08:53:50 --> URI Class Initialized
INFO - 2025-09-06 08:53:50 --> Router Class Initialized
INFO - 2025-09-06 08:53:51 --> Output Class Initialized
INFO - 2025-09-06 08:53:51 --> Security Class Initialized
DEBUG - 2025-09-06 08:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:53:51 --> Input Class Initialized
INFO - 2025-09-06 08:53:51 --> Language Class Initialized
INFO - 2025-09-06 08:53:51 --> Loader Class Initialized
INFO - 2025-09-06 08:53:51 --> Helper loaded: url_helper
INFO - 2025-09-06 08:53:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:53:51 --> Helper loaded: form_helper
INFO - 2025-09-06 08:53:51 --> Form Validation Class Initialized
INFO - 2025-09-06 08:53:51 --> Controller Class Initialized
INFO - 2025-09-06 08:53:51 --> Model "Center_model" initialized
INFO - 2025-09-06 08:53:51 --> Final output sent to browser
DEBUG - 2025-09-06 08:53:51 --> Total execution time: 0.1109
INFO - 2025-09-06 08:53:57 --> Config Class Initialized
INFO - 2025-09-06 08:53:57 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:53:57 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:53:57 --> Utf8 Class Initialized
INFO - 2025-09-06 08:53:57 --> URI Class Initialized
INFO - 2025-09-06 08:53:57 --> Router Class Initialized
INFO - 2025-09-06 08:53:57 --> Output Class Initialized
INFO - 2025-09-06 08:53:57 --> Security Class Initialized
DEBUG - 2025-09-06 08:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:53:57 --> Input Class Initialized
INFO - 2025-09-06 08:53:57 --> Language Class Initialized
INFO - 2025-09-06 08:53:57 --> Loader Class Initialized
INFO - 2025-09-06 08:53:57 --> Helper loaded: url_helper
INFO - 2025-09-06 08:53:57 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:53:57 --> Helper loaded: form_helper
INFO - 2025-09-06 08:53:57 --> Form Validation Class Initialized
INFO - 2025-09-06 08:53:57 --> Controller Class Initialized
INFO - 2025-09-06 08:53:57 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:53:57 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:53:57 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 08:53:57 --> Final output sent to browser
DEBUG - 2025-09-06 08:53:57 --> Total execution time: 0.1309
INFO - 2025-09-06 08:53:58 --> Config Class Initialized
INFO - 2025-09-06 08:53:58 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:53:58 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:53:58 --> Utf8 Class Initialized
INFO - 2025-09-06 08:53:58 --> URI Class Initialized
INFO - 2025-09-06 08:53:58 --> Router Class Initialized
INFO - 2025-09-06 08:53:58 --> Output Class Initialized
INFO - 2025-09-06 08:53:58 --> Security Class Initialized
DEBUG - 2025-09-06 08:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:53:58 --> Input Class Initialized
INFO - 2025-09-06 08:53:58 --> Language Class Initialized
INFO - 2025-09-06 08:53:58 --> Loader Class Initialized
INFO - 2025-09-06 08:53:58 --> Helper loaded: url_helper
INFO - 2025-09-06 08:53:58 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:53:58 --> Helper loaded: form_helper
INFO - 2025-09-06 08:53:58 --> Form Validation Class Initialized
INFO - 2025-09-06 08:53:58 --> Controller Class Initialized
INFO - 2025-09-06 08:53:58 --> Model "Center_model" initialized
INFO - 2025-09-06 08:53:58 --> Final output sent to browser
DEBUG - 2025-09-06 08:53:58 --> Total execution time: 0.1319
INFO - 2025-09-06 08:54:02 --> Config Class Initialized
INFO - 2025-09-06 08:54:02 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:54:02 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:54:02 --> Utf8 Class Initialized
INFO - 2025-09-06 08:54:02 --> URI Class Initialized
INFO - 2025-09-06 08:54:02 --> Router Class Initialized
INFO - 2025-09-06 08:54:02 --> Output Class Initialized
INFO - 2025-09-06 08:54:02 --> Security Class Initialized
DEBUG - 2025-09-06 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:54:02 --> Input Class Initialized
INFO - 2025-09-06 08:54:02 --> Language Class Initialized
INFO - 2025-09-06 08:54:02 --> Loader Class Initialized
INFO - 2025-09-06 08:54:02 --> Helper loaded: url_helper
INFO - 2025-09-06 08:54:02 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:54:02 --> Helper loaded: form_helper
INFO - 2025-09-06 08:54:02 --> Form Validation Class Initialized
INFO - 2025-09-06 08:54:02 --> Controller Class Initialized
INFO - 2025-09-06 08:54:02 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:54:02 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:54:02 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 08:54:02 --> Final output sent to browser
DEBUG - 2025-09-06 08:54:02 --> Total execution time: 0.1389
INFO - 2025-09-06 08:54:02 --> Config Class Initialized
INFO - 2025-09-06 08:54:02 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:54:02 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:54:02 --> Utf8 Class Initialized
INFO - 2025-09-06 08:54:02 --> URI Class Initialized
INFO - 2025-09-06 08:54:02 --> Router Class Initialized
INFO - 2025-09-06 08:54:02 --> Output Class Initialized
INFO - 2025-09-06 08:54:02 --> Security Class Initialized
DEBUG - 2025-09-06 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:54:02 --> Input Class Initialized
INFO - 2025-09-06 08:54:02 --> Language Class Initialized
INFO - 2025-09-06 08:54:02 --> Loader Class Initialized
INFO - 2025-09-06 08:54:02 --> Helper loaded: url_helper
INFO - 2025-09-06 08:54:02 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:54:02 --> Helper loaded: form_helper
INFO - 2025-09-06 08:54:02 --> Form Validation Class Initialized
INFO - 2025-09-06 08:54:02 --> Controller Class Initialized
INFO - 2025-09-06 08:54:02 --> Model "Center_model" initialized
INFO - 2025-09-06 08:54:02 --> Final output sent to browser
DEBUG - 2025-09-06 08:54:02 --> Total execution time: 0.0963
INFO - 2025-09-06 08:54:02 --> Config Class Initialized
INFO - 2025-09-06 08:54:02 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:54:02 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:54:02 --> Utf8 Class Initialized
INFO - 2025-09-06 08:54:02 --> URI Class Initialized
INFO - 2025-09-06 08:54:02 --> Router Class Initialized
INFO - 2025-09-06 08:54:02 --> Output Class Initialized
INFO - 2025-09-06 08:54:02 --> Security Class Initialized
DEBUG - 2025-09-06 08:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:54:02 --> Input Class Initialized
INFO - 2025-09-06 08:54:02 --> Language Class Initialized
INFO - 2025-09-06 08:54:02 --> Loader Class Initialized
INFO - 2025-09-06 08:54:02 --> Helper loaded: url_helper
INFO - 2025-09-06 08:54:02 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:54:02 --> Helper loaded: form_helper
INFO - 2025-09-06 08:54:02 --> Form Validation Class Initialized
INFO - 2025-09-06 08:54:02 --> Controller Class Initialized
INFO - 2025-09-06 08:54:02 --> Model "Center_model" initialized
INFO - 2025-09-06 08:54:02 --> Final output sent to browser
DEBUG - 2025-09-06 08:54:02 --> Total execution time: 0.0920
INFO - 2025-09-06 08:54:08 --> Config Class Initialized
INFO - 2025-09-06 08:54:08 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:54:08 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:54:08 --> Utf8 Class Initialized
INFO - 2025-09-06 08:54:08 --> URI Class Initialized
INFO - 2025-09-06 08:54:08 --> Router Class Initialized
INFO - 2025-09-06 08:54:08 --> Output Class Initialized
INFO - 2025-09-06 08:54:08 --> Security Class Initialized
DEBUG - 2025-09-06 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:54:08 --> Input Class Initialized
INFO - 2025-09-06 08:54:08 --> Language Class Initialized
INFO - 2025-09-06 08:54:08 --> Loader Class Initialized
INFO - 2025-09-06 08:54:08 --> Helper loaded: url_helper
INFO - 2025-09-06 08:54:08 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:54:08 --> Helper loaded: form_helper
INFO - 2025-09-06 08:54:08 --> Form Validation Class Initialized
INFO - 2025-09-06 08:54:08 --> Controller Class Initialized
INFO - 2025-09-06 08:54:08 --> Model "Center_model" initialized
INFO - 2025-09-06 08:54:08 --> Final output sent to browser
DEBUG - 2025-09-06 08:54:08 --> Total execution time: 0.1160
INFO - 2025-09-06 08:54:20 --> Config Class Initialized
INFO - 2025-09-06 08:54:20 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:54:20 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:54:20 --> Utf8 Class Initialized
INFO - 2025-09-06 08:54:20 --> URI Class Initialized
INFO - 2025-09-06 08:54:20 --> Router Class Initialized
INFO - 2025-09-06 08:54:20 --> Output Class Initialized
INFO - 2025-09-06 08:54:20 --> Security Class Initialized
DEBUG - 2025-09-06 08:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:54:20 --> Input Class Initialized
INFO - 2025-09-06 08:54:20 --> Language Class Initialized
INFO - 2025-09-06 08:54:20 --> Loader Class Initialized
INFO - 2025-09-06 08:54:20 --> Helper loaded: url_helper
INFO - 2025-09-06 08:54:20 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:54:20 --> Helper loaded: form_helper
INFO - 2025-09-06 08:54:20 --> Form Validation Class Initialized
INFO - 2025-09-06 08:54:20 --> Controller Class Initialized
INFO - 2025-09-06 08:54:20 --> Model "Center_model" initialized
INFO - 2025-09-06 08:54:20 --> Final output sent to browser
DEBUG - 2025-09-06 08:54:20 --> Total execution time: 0.1092
INFO - 2025-09-06 08:57:34 --> Config Class Initialized
INFO - 2025-09-06 08:57:34 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:57:34 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:57:34 --> Utf8 Class Initialized
INFO - 2025-09-06 08:57:34 --> URI Class Initialized
INFO - 2025-09-06 08:57:34 --> Router Class Initialized
INFO - 2025-09-06 08:57:34 --> Output Class Initialized
INFO - 2025-09-06 08:57:34 --> Security Class Initialized
DEBUG - 2025-09-06 08:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:57:34 --> Input Class Initialized
INFO - 2025-09-06 08:57:34 --> Language Class Initialized
INFO - 2025-09-06 08:57:34 --> Loader Class Initialized
INFO - 2025-09-06 08:57:34 --> Helper loaded: url_helper
INFO - 2025-09-06 08:57:34 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:57:34 --> Helper loaded: form_helper
INFO - 2025-09-06 08:57:34 --> Form Validation Class Initialized
INFO - 2025-09-06 08:57:34 --> Controller Class Initialized
INFO - 2025-09-06 08:57:34 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 08:57:34 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 08:57:34 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 08:57:34 --> Final output sent to browser
DEBUG - 2025-09-06 08:57:34 --> Total execution time: 0.0958
INFO - 2025-09-06 08:57:34 --> Config Class Initialized
INFO - 2025-09-06 08:57:34 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:57:34 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:57:34 --> Utf8 Class Initialized
INFO - 2025-09-06 08:57:34 --> URI Class Initialized
INFO - 2025-09-06 08:57:34 --> Router Class Initialized
INFO - 2025-09-06 08:57:34 --> Output Class Initialized
INFO - 2025-09-06 08:57:34 --> Security Class Initialized
DEBUG - 2025-09-06 08:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:57:34 --> Input Class Initialized
INFO - 2025-09-06 08:57:34 --> Language Class Initialized
INFO - 2025-09-06 08:57:34 --> Loader Class Initialized
INFO - 2025-09-06 08:57:34 --> Helper loaded: url_helper
INFO - 2025-09-06 08:57:34 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:57:34 --> Helper loaded: form_helper
INFO - 2025-09-06 08:57:34 --> Form Validation Class Initialized
INFO - 2025-09-06 08:57:34 --> Controller Class Initialized
INFO - 2025-09-06 08:57:34 --> Model "Center_model" initialized
INFO - 2025-09-06 08:57:34 --> Final output sent to browser
DEBUG - 2025-09-06 08:57:34 --> Total execution time: 0.1057
INFO - 2025-09-06 08:57:34 --> Config Class Initialized
INFO - 2025-09-06 08:57:34 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:57:34 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:57:34 --> Utf8 Class Initialized
INFO - 2025-09-06 08:57:34 --> URI Class Initialized
INFO - 2025-09-06 08:57:34 --> Router Class Initialized
INFO - 2025-09-06 08:57:34 --> Output Class Initialized
INFO - 2025-09-06 08:57:34 --> Security Class Initialized
DEBUG - 2025-09-06 08:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:57:34 --> Input Class Initialized
INFO - 2025-09-06 08:57:34 --> Language Class Initialized
INFO - 2025-09-06 08:57:34 --> Loader Class Initialized
INFO - 2025-09-06 08:57:34 --> Helper loaded: url_helper
INFO - 2025-09-06 08:57:34 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:57:34 --> Helper loaded: form_helper
INFO - 2025-09-06 08:57:34 --> Form Validation Class Initialized
INFO - 2025-09-06 08:57:34 --> Controller Class Initialized
INFO - 2025-09-06 08:57:34 --> Model "Center_model" initialized
INFO - 2025-09-06 08:57:34 --> Final output sent to browser
DEBUG - 2025-09-06 08:57:34 --> Total execution time: 0.1242
INFO - 2025-09-06 08:57:37 --> Config Class Initialized
INFO - 2025-09-06 08:57:37 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:57:37 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:57:37 --> Utf8 Class Initialized
INFO - 2025-09-06 08:57:37 --> URI Class Initialized
INFO - 2025-09-06 08:57:37 --> Router Class Initialized
INFO - 2025-09-06 08:57:37 --> Output Class Initialized
INFO - 2025-09-06 08:57:37 --> Security Class Initialized
DEBUG - 2025-09-06 08:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:57:37 --> Input Class Initialized
INFO - 2025-09-06 08:57:37 --> Language Class Initialized
INFO - 2025-09-06 08:57:37 --> Loader Class Initialized
INFO - 2025-09-06 08:57:37 --> Helper loaded: url_helper
INFO - 2025-09-06 08:57:37 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:57:37 --> Helper loaded: form_helper
INFO - 2025-09-06 08:57:37 --> Form Validation Class Initialized
INFO - 2025-09-06 08:57:37 --> Controller Class Initialized
INFO - 2025-09-06 08:57:37 --> Model "Center_model" initialized
INFO - 2025-09-06 08:57:37 --> Final output sent to browser
DEBUG - 2025-09-06 08:57:37 --> Total execution time: 0.1453
INFO - 2025-09-06 08:57:41 --> Config Class Initialized
INFO - 2025-09-06 08:57:41 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:57:41 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:57:41 --> Utf8 Class Initialized
INFO - 2025-09-06 08:57:41 --> URI Class Initialized
INFO - 2025-09-06 08:57:41 --> Router Class Initialized
INFO - 2025-09-06 08:57:41 --> Output Class Initialized
INFO - 2025-09-06 08:57:41 --> Security Class Initialized
DEBUG - 2025-09-06 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:57:41 --> Input Class Initialized
INFO - 2025-09-06 08:57:41 --> Language Class Initialized
INFO - 2025-09-06 08:57:41 --> Loader Class Initialized
INFO - 2025-09-06 08:57:41 --> Helper loaded: url_helper
INFO - 2025-09-06 08:57:41 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:57:41 --> Helper loaded: form_helper
INFO - 2025-09-06 08:57:41 --> Form Validation Class Initialized
INFO - 2025-09-06 08:57:41 --> Controller Class Initialized
INFO - 2025-09-06 08:57:41 --> Model "Center_model" initialized
INFO - 2025-09-06 08:57:41 --> Final output sent to browser
DEBUG - 2025-09-06 08:57:41 --> Total execution time: 0.1365
INFO - 2025-09-06 08:57:46 --> Config Class Initialized
INFO - 2025-09-06 08:57:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:57:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:57:46 --> Utf8 Class Initialized
INFO - 2025-09-06 08:57:46 --> URI Class Initialized
INFO - 2025-09-06 08:57:46 --> Router Class Initialized
INFO - 2025-09-06 08:57:46 --> Output Class Initialized
INFO - 2025-09-06 08:57:46 --> Security Class Initialized
DEBUG - 2025-09-06 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:57:46 --> Input Class Initialized
INFO - 2025-09-06 08:57:46 --> Language Class Initialized
INFO - 2025-09-06 08:57:46 --> Loader Class Initialized
INFO - 2025-09-06 08:57:46 --> Helper loaded: url_helper
INFO - 2025-09-06 08:57:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:57:46 --> Helper loaded: form_helper
INFO - 2025-09-06 08:57:46 --> Form Validation Class Initialized
INFO - 2025-09-06 08:57:46 --> Controller Class Initialized
INFO - 2025-09-06 08:57:46 --> Model "Center_model" initialized
INFO - 2025-09-06 08:57:46 --> Final output sent to browser
DEBUG - 2025-09-06 08:57:46 --> Total execution time: 0.1130
INFO - 2025-09-06 08:57:56 --> Config Class Initialized
INFO - 2025-09-06 08:57:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 08:57:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 08:57:56 --> Utf8 Class Initialized
INFO - 2025-09-06 08:57:56 --> URI Class Initialized
INFO - 2025-09-06 08:57:56 --> Router Class Initialized
INFO - 2025-09-06 08:57:56 --> Output Class Initialized
INFO - 2025-09-06 08:57:56 --> Security Class Initialized
DEBUG - 2025-09-06 08:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 08:57:56 --> Input Class Initialized
INFO - 2025-09-06 08:57:56 --> Language Class Initialized
INFO - 2025-09-06 08:57:56 --> Loader Class Initialized
INFO - 2025-09-06 08:57:56 --> Helper loaded: url_helper
INFO - 2025-09-06 08:57:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 08:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 08:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 08:57:56 --> Helper loaded: form_helper
INFO - 2025-09-06 08:57:56 --> Form Validation Class Initialized
INFO - 2025-09-06 08:57:56 --> Controller Class Initialized
INFO - 2025-09-06 08:57:56 --> Model "Center_model" initialized
INFO - 2025-09-06 08:57:56 --> Final output sent to browser
DEBUG - 2025-09-06 08:57:56 --> Total execution time: 0.1358
INFO - 2025-09-06 09:03:10 --> Config Class Initialized
INFO - 2025-09-06 09:03:10 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:03:10 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:03:10 --> Utf8 Class Initialized
INFO - 2025-09-06 09:03:10 --> URI Class Initialized
INFO - 2025-09-06 09:03:10 --> Router Class Initialized
INFO - 2025-09-06 09:03:10 --> Output Class Initialized
INFO - 2025-09-06 09:03:10 --> Security Class Initialized
DEBUG - 2025-09-06 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:03:10 --> Input Class Initialized
INFO - 2025-09-06 09:03:10 --> Language Class Initialized
INFO - 2025-09-06 09:03:10 --> Loader Class Initialized
INFO - 2025-09-06 09:03:10 --> Helper loaded: url_helper
INFO - 2025-09-06 09:03:10 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:03:10 --> Helper loaded: form_helper
INFO - 2025-09-06 09:03:10 --> Form Validation Class Initialized
INFO - 2025-09-06 09:03:10 --> Controller Class Initialized
INFO - 2025-09-06 09:03:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:03:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:03:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:03:10 --> Final output sent to browser
DEBUG - 2025-09-06 09:03:10 --> Total execution time: 0.1223
INFO - 2025-09-06 09:03:10 --> Config Class Initialized
INFO - 2025-09-06 09:03:10 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:03:10 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:03:10 --> Utf8 Class Initialized
INFO - 2025-09-06 09:03:10 --> URI Class Initialized
INFO - 2025-09-06 09:03:10 --> Router Class Initialized
INFO - 2025-09-06 09:03:10 --> Output Class Initialized
INFO - 2025-09-06 09:03:10 --> Security Class Initialized
DEBUG - 2025-09-06 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:03:10 --> Input Class Initialized
INFO - 2025-09-06 09:03:10 --> Language Class Initialized
INFO - 2025-09-06 09:03:11 --> Loader Class Initialized
INFO - 2025-09-06 09:03:11 --> Helper loaded: url_helper
INFO - 2025-09-06 09:03:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:03:11 --> Helper loaded: form_helper
INFO - 2025-09-06 09:03:11 --> Form Validation Class Initialized
INFO - 2025-09-06 09:03:11 --> Controller Class Initialized
INFO - 2025-09-06 09:03:11 --> Model "Center_model" initialized
INFO - 2025-09-06 09:03:11 --> Final output sent to browser
DEBUG - 2025-09-06 09:03:11 --> Total execution time: 0.1242
INFO - 2025-09-06 09:03:11 --> Config Class Initialized
INFO - 2025-09-06 09:03:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:03:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:03:11 --> Utf8 Class Initialized
INFO - 2025-09-06 09:03:11 --> URI Class Initialized
INFO - 2025-09-06 09:03:11 --> Router Class Initialized
INFO - 2025-09-06 09:03:11 --> Output Class Initialized
INFO - 2025-09-06 09:03:11 --> Security Class Initialized
DEBUG - 2025-09-06 09:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:03:11 --> Input Class Initialized
INFO - 2025-09-06 09:03:11 --> Language Class Initialized
INFO - 2025-09-06 09:03:11 --> Loader Class Initialized
INFO - 2025-09-06 09:03:11 --> Helper loaded: url_helper
INFO - 2025-09-06 09:03:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:03:11 --> Helper loaded: form_helper
INFO - 2025-09-06 09:03:11 --> Form Validation Class Initialized
INFO - 2025-09-06 09:03:11 --> Controller Class Initialized
INFO - 2025-09-06 09:03:11 --> Model "Center_model" initialized
INFO - 2025-09-06 09:03:11 --> Final output sent to browser
DEBUG - 2025-09-06 09:03:11 --> Total execution time: 0.0950
INFO - 2025-09-06 09:03:13 --> Config Class Initialized
INFO - 2025-09-06 09:03:13 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:03:13 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:03:13 --> Utf8 Class Initialized
INFO - 2025-09-06 09:03:13 --> URI Class Initialized
INFO - 2025-09-06 09:03:13 --> Router Class Initialized
INFO - 2025-09-06 09:03:13 --> Output Class Initialized
INFO - 2025-09-06 09:03:13 --> Security Class Initialized
DEBUG - 2025-09-06 09:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:03:13 --> Input Class Initialized
INFO - 2025-09-06 09:03:13 --> Language Class Initialized
INFO - 2025-09-06 09:03:13 --> Loader Class Initialized
INFO - 2025-09-06 09:03:13 --> Helper loaded: url_helper
INFO - 2025-09-06 09:03:13 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:03:13 --> Helper loaded: form_helper
INFO - 2025-09-06 09:03:13 --> Form Validation Class Initialized
INFO - 2025-09-06 09:03:13 --> Controller Class Initialized
INFO - 2025-09-06 09:03:13 --> Model "Center_model" initialized
INFO - 2025-09-06 09:03:13 --> Final output sent to browser
DEBUG - 2025-09-06 09:03:13 --> Total execution time: 0.1410
INFO - 2025-09-06 09:09:04 --> Config Class Initialized
INFO - 2025-09-06 09:09:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:09:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:09:04 --> Utf8 Class Initialized
INFO - 2025-09-06 09:09:04 --> URI Class Initialized
INFO - 2025-09-06 09:09:04 --> Router Class Initialized
INFO - 2025-09-06 09:09:04 --> Output Class Initialized
INFO - 2025-09-06 09:09:04 --> Security Class Initialized
DEBUG - 2025-09-06 09:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:09:04 --> Input Class Initialized
INFO - 2025-09-06 09:09:04 --> Language Class Initialized
INFO - 2025-09-06 09:09:04 --> Loader Class Initialized
INFO - 2025-09-06 09:09:04 --> Helper loaded: url_helper
INFO - 2025-09-06 09:09:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:09:04 --> Helper loaded: form_helper
INFO - 2025-09-06 09:09:04 --> Form Validation Class Initialized
INFO - 2025-09-06 09:09:04 --> Controller Class Initialized
INFO - 2025-09-06 09:09:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:09:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:09:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:09:04 --> Final output sent to browser
DEBUG - 2025-09-06 09:09:04 --> Total execution time: 0.0866
INFO - 2025-09-06 09:09:04 --> Config Class Initialized
INFO - 2025-09-06 09:09:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:09:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:09:04 --> Utf8 Class Initialized
INFO - 2025-09-06 09:09:04 --> URI Class Initialized
INFO - 2025-09-06 09:09:04 --> Router Class Initialized
INFO - 2025-09-06 09:09:04 --> Output Class Initialized
INFO - 2025-09-06 09:09:04 --> Security Class Initialized
DEBUG - 2025-09-06 09:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:09:04 --> Input Class Initialized
INFO - 2025-09-06 09:09:04 --> Language Class Initialized
INFO - 2025-09-06 09:09:04 --> Loader Class Initialized
INFO - 2025-09-06 09:09:04 --> Helper loaded: url_helper
INFO - 2025-09-06 09:09:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:09:04 --> Helper loaded: form_helper
INFO - 2025-09-06 09:09:04 --> Form Validation Class Initialized
INFO - 2025-09-06 09:09:04 --> Controller Class Initialized
INFO - 2025-09-06 09:09:04 --> Model "Center_model" initialized
INFO - 2025-09-06 09:09:04 --> Final output sent to browser
DEBUG - 2025-09-06 09:09:04 --> Total execution time: 0.0778
INFO - 2025-09-06 09:09:04 --> Config Class Initialized
INFO - 2025-09-06 09:09:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:09:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:09:04 --> Utf8 Class Initialized
INFO - 2025-09-06 09:09:04 --> URI Class Initialized
INFO - 2025-09-06 09:09:04 --> Router Class Initialized
INFO - 2025-09-06 09:09:04 --> Output Class Initialized
INFO - 2025-09-06 09:09:04 --> Security Class Initialized
DEBUG - 2025-09-06 09:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:09:04 --> Input Class Initialized
INFO - 2025-09-06 09:09:04 --> Language Class Initialized
INFO - 2025-09-06 09:09:04 --> Loader Class Initialized
INFO - 2025-09-06 09:09:04 --> Helper loaded: url_helper
INFO - 2025-09-06 09:09:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:09:05 --> Helper loaded: form_helper
INFO - 2025-09-06 09:09:05 --> Form Validation Class Initialized
INFO - 2025-09-06 09:09:05 --> Controller Class Initialized
INFO - 2025-09-06 09:09:05 --> Model "Center_model" initialized
INFO - 2025-09-06 09:09:05 --> Final output sent to browser
DEBUG - 2025-09-06 09:09:05 --> Total execution time: 0.0667
INFO - 2025-09-06 09:09:07 --> Config Class Initialized
INFO - 2025-09-06 09:09:07 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:09:07 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:09:07 --> Utf8 Class Initialized
INFO - 2025-09-06 09:09:07 --> URI Class Initialized
INFO - 2025-09-06 09:09:07 --> Router Class Initialized
INFO - 2025-09-06 09:09:07 --> Output Class Initialized
INFO - 2025-09-06 09:09:07 --> Security Class Initialized
DEBUG - 2025-09-06 09:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:09:07 --> Input Class Initialized
INFO - 2025-09-06 09:09:07 --> Language Class Initialized
INFO - 2025-09-06 09:09:07 --> Loader Class Initialized
INFO - 2025-09-06 09:09:07 --> Helper loaded: url_helper
INFO - 2025-09-06 09:09:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:09:07 --> Helper loaded: form_helper
INFO - 2025-09-06 09:09:07 --> Form Validation Class Initialized
INFO - 2025-09-06 09:09:07 --> Controller Class Initialized
INFO - 2025-09-06 09:09:07 --> Model "Center_model" initialized
INFO - 2025-09-06 09:09:07 --> Final output sent to browser
DEBUG - 2025-09-06 09:09:07 --> Total execution time: 0.0699
INFO - 2025-09-06 09:11:56 --> Config Class Initialized
INFO - 2025-09-06 09:11:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:11:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:11:56 --> Utf8 Class Initialized
INFO - 2025-09-06 09:11:56 --> URI Class Initialized
INFO - 2025-09-06 09:11:56 --> Router Class Initialized
INFO - 2025-09-06 09:11:56 --> Output Class Initialized
INFO - 2025-09-06 09:11:56 --> Security Class Initialized
DEBUG - 2025-09-06 09:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:11:56 --> Input Class Initialized
INFO - 2025-09-06 09:11:56 --> Language Class Initialized
INFO - 2025-09-06 09:11:56 --> Loader Class Initialized
INFO - 2025-09-06 09:11:56 --> Helper loaded: url_helper
INFO - 2025-09-06 09:11:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:11:56 --> Helper loaded: form_helper
INFO - 2025-09-06 09:11:56 --> Form Validation Class Initialized
INFO - 2025-09-06 09:11:56 --> Controller Class Initialized
INFO - 2025-09-06 09:11:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:11:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:11:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:11:56 --> Final output sent to browser
DEBUG - 2025-09-06 09:11:56 --> Total execution time: 0.0997
INFO - 2025-09-06 09:11:56 --> Config Class Initialized
INFO - 2025-09-06 09:11:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:11:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:11:56 --> Utf8 Class Initialized
INFO - 2025-09-06 09:11:56 --> URI Class Initialized
INFO - 2025-09-06 09:11:56 --> Router Class Initialized
INFO - 2025-09-06 09:11:56 --> Output Class Initialized
INFO - 2025-09-06 09:11:56 --> Security Class Initialized
DEBUG - 2025-09-06 09:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:11:56 --> Input Class Initialized
INFO - 2025-09-06 09:11:56 --> Language Class Initialized
INFO - 2025-09-06 09:11:56 --> Loader Class Initialized
INFO - 2025-09-06 09:11:56 --> Helper loaded: url_helper
INFO - 2025-09-06 09:11:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:11:56 --> Helper loaded: form_helper
INFO - 2025-09-06 09:11:56 --> Form Validation Class Initialized
INFO - 2025-09-06 09:11:56 --> Controller Class Initialized
INFO - 2025-09-06 09:11:56 --> Model "Center_model" initialized
INFO - 2025-09-06 09:11:56 --> Final output sent to browser
DEBUG - 2025-09-06 09:11:56 --> Total execution time: 0.0812
INFO - 2025-09-06 09:11:56 --> Config Class Initialized
INFO - 2025-09-06 09:11:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:11:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:11:56 --> Utf8 Class Initialized
INFO - 2025-09-06 09:11:56 --> URI Class Initialized
INFO - 2025-09-06 09:11:56 --> Router Class Initialized
INFO - 2025-09-06 09:11:56 --> Output Class Initialized
INFO - 2025-09-06 09:11:56 --> Security Class Initialized
DEBUG - 2025-09-06 09:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:11:56 --> Input Class Initialized
INFO - 2025-09-06 09:11:56 --> Language Class Initialized
INFO - 2025-09-06 09:11:56 --> Loader Class Initialized
INFO - 2025-09-06 09:11:56 --> Helper loaded: url_helper
INFO - 2025-09-06 09:11:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:11:56 --> Helper loaded: form_helper
INFO - 2025-09-06 09:11:56 --> Form Validation Class Initialized
INFO - 2025-09-06 09:11:56 --> Controller Class Initialized
INFO - 2025-09-06 09:11:56 --> Model "Center_model" initialized
INFO - 2025-09-06 09:11:56 --> Final output sent to browser
DEBUG - 2025-09-06 09:11:56 --> Total execution time: 0.0682
INFO - 2025-09-06 09:11:58 --> Config Class Initialized
INFO - 2025-09-06 09:11:58 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:11:58 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:11:58 --> Utf8 Class Initialized
INFO - 2025-09-06 09:11:58 --> URI Class Initialized
INFO - 2025-09-06 09:11:58 --> Router Class Initialized
INFO - 2025-09-06 09:11:58 --> Output Class Initialized
INFO - 2025-09-06 09:11:58 --> Security Class Initialized
DEBUG - 2025-09-06 09:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:11:58 --> Input Class Initialized
INFO - 2025-09-06 09:11:58 --> Language Class Initialized
INFO - 2025-09-06 09:11:58 --> Loader Class Initialized
INFO - 2025-09-06 09:11:58 --> Helper loaded: url_helper
INFO - 2025-09-06 09:11:58 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:11:58 --> Helper loaded: form_helper
INFO - 2025-09-06 09:11:58 --> Form Validation Class Initialized
INFO - 2025-09-06 09:11:58 --> Controller Class Initialized
INFO - 2025-09-06 09:11:58 --> Model "Center_model" initialized
INFO - 2025-09-06 09:11:58 --> Final output sent to browser
DEBUG - 2025-09-06 09:11:58 --> Total execution time: 0.0689
INFO - 2025-09-06 09:12:45 --> Config Class Initialized
INFO - 2025-09-06 09:12:45 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:12:45 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:12:45 --> Utf8 Class Initialized
INFO - 2025-09-06 09:12:45 --> URI Class Initialized
INFO - 2025-09-06 09:12:45 --> Router Class Initialized
INFO - 2025-09-06 09:12:45 --> Output Class Initialized
INFO - 2025-09-06 09:12:45 --> Security Class Initialized
DEBUG - 2025-09-06 09:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:12:45 --> Input Class Initialized
INFO - 2025-09-06 09:12:45 --> Language Class Initialized
INFO - 2025-09-06 09:12:45 --> Loader Class Initialized
INFO - 2025-09-06 09:12:45 --> Helper loaded: url_helper
INFO - 2025-09-06 09:12:45 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:12:45 --> Helper loaded: form_helper
INFO - 2025-09-06 09:12:45 --> Form Validation Class Initialized
INFO - 2025-09-06 09:12:45 --> Controller Class Initialized
INFO - 2025-09-06 09:12:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:12:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:12:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:12:45 --> Final output sent to browser
DEBUG - 2025-09-06 09:12:45 --> Total execution time: 0.0805
INFO - 2025-09-06 09:12:45 --> Config Class Initialized
INFO - 2025-09-06 09:12:45 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:12:45 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:12:45 --> Utf8 Class Initialized
INFO - 2025-09-06 09:12:45 --> URI Class Initialized
INFO - 2025-09-06 09:12:45 --> Router Class Initialized
INFO - 2025-09-06 09:12:45 --> Output Class Initialized
INFO - 2025-09-06 09:12:45 --> Security Class Initialized
DEBUG - 2025-09-06 09:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:12:45 --> Input Class Initialized
INFO - 2025-09-06 09:12:45 --> Language Class Initialized
INFO - 2025-09-06 09:12:45 --> Loader Class Initialized
INFO - 2025-09-06 09:12:45 --> Helper loaded: url_helper
INFO - 2025-09-06 09:12:45 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:12:45 --> Helper loaded: form_helper
INFO - 2025-09-06 09:12:45 --> Form Validation Class Initialized
INFO - 2025-09-06 09:12:45 --> Controller Class Initialized
INFO - 2025-09-06 09:12:45 --> Model "Center_model" initialized
INFO - 2025-09-06 09:12:45 --> Final output sent to browser
DEBUG - 2025-09-06 09:12:45 --> Total execution time: 0.0891
INFO - 2025-09-06 09:12:45 --> Config Class Initialized
INFO - 2025-09-06 09:12:45 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:12:45 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:12:45 --> Utf8 Class Initialized
INFO - 2025-09-06 09:12:45 --> URI Class Initialized
INFO - 2025-09-06 09:12:45 --> Router Class Initialized
INFO - 2025-09-06 09:12:45 --> Output Class Initialized
INFO - 2025-09-06 09:12:45 --> Security Class Initialized
DEBUG - 2025-09-06 09:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:12:45 --> Input Class Initialized
INFO - 2025-09-06 09:12:45 --> Language Class Initialized
INFO - 2025-09-06 09:12:45 --> Loader Class Initialized
INFO - 2025-09-06 09:12:45 --> Helper loaded: url_helper
INFO - 2025-09-06 09:12:45 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:12:45 --> Helper loaded: form_helper
INFO - 2025-09-06 09:12:45 --> Form Validation Class Initialized
INFO - 2025-09-06 09:12:45 --> Controller Class Initialized
INFO - 2025-09-06 09:12:45 --> Model "Center_model" initialized
INFO - 2025-09-06 09:12:45 --> Final output sent to browser
DEBUG - 2025-09-06 09:12:45 --> Total execution time: 0.0695
INFO - 2025-09-06 09:12:48 --> Config Class Initialized
INFO - 2025-09-06 09:12:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:12:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:12:48 --> Utf8 Class Initialized
INFO - 2025-09-06 09:12:48 --> URI Class Initialized
INFO - 2025-09-06 09:12:48 --> Router Class Initialized
INFO - 2025-09-06 09:12:48 --> Output Class Initialized
INFO - 2025-09-06 09:12:48 --> Security Class Initialized
DEBUG - 2025-09-06 09:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:12:48 --> Input Class Initialized
INFO - 2025-09-06 09:12:48 --> Language Class Initialized
INFO - 2025-09-06 09:12:48 --> Loader Class Initialized
INFO - 2025-09-06 09:12:48 --> Helper loaded: url_helper
INFO - 2025-09-06 09:12:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:12:48 --> Helper loaded: form_helper
INFO - 2025-09-06 09:12:48 --> Form Validation Class Initialized
INFO - 2025-09-06 09:12:48 --> Controller Class Initialized
INFO - 2025-09-06 09:12:48 --> Model "Center_model" initialized
INFO - 2025-09-06 09:12:48 --> Final output sent to browser
DEBUG - 2025-09-06 09:12:48 --> Total execution time: 0.0675
INFO - 2025-09-06 09:12:49 --> Config Class Initialized
INFO - 2025-09-06 09:12:49 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:12:49 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:12:49 --> Utf8 Class Initialized
INFO - 2025-09-06 09:12:49 --> URI Class Initialized
INFO - 2025-09-06 09:12:49 --> Router Class Initialized
INFO - 2025-09-06 09:12:49 --> Output Class Initialized
INFO - 2025-09-06 09:12:49 --> Security Class Initialized
DEBUG - 2025-09-06 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:12:49 --> Input Class Initialized
INFO - 2025-09-06 09:12:49 --> Language Class Initialized
INFO - 2025-09-06 09:12:49 --> Loader Class Initialized
INFO - 2025-09-06 09:12:49 --> Helper loaded: url_helper
INFO - 2025-09-06 09:12:49 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:12:49 --> Helper loaded: form_helper
INFO - 2025-09-06 09:12:49 --> Form Validation Class Initialized
INFO - 2025-09-06 09:12:49 --> Controller Class Initialized
INFO - 2025-09-06 09:12:49 --> Model "Center_model" initialized
INFO - 2025-09-06 09:12:49 --> Final output sent to browser
DEBUG - 2025-09-06 09:12:49 --> Total execution time: 0.0585
INFO - 2025-09-06 09:15:20 --> Config Class Initialized
INFO - 2025-09-06 09:15:20 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:15:20 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:15:20 --> Utf8 Class Initialized
INFO - 2025-09-06 09:15:20 --> URI Class Initialized
INFO - 2025-09-06 09:15:20 --> Router Class Initialized
INFO - 2025-09-06 09:15:20 --> Output Class Initialized
INFO - 2025-09-06 09:15:20 --> Security Class Initialized
DEBUG - 2025-09-06 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:15:20 --> Input Class Initialized
INFO - 2025-09-06 09:15:20 --> Language Class Initialized
INFO - 2025-09-06 09:15:20 --> Loader Class Initialized
INFO - 2025-09-06 09:15:20 --> Helper loaded: url_helper
INFO - 2025-09-06 09:15:20 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:15:20 --> Helper loaded: form_helper
INFO - 2025-09-06 09:15:20 --> Form Validation Class Initialized
INFO - 2025-09-06 09:15:20 --> Controller Class Initialized
INFO - 2025-09-06 09:15:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:15:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:15:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:15:20 --> Final output sent to browser
DEBUG - 2025-09-06 09:15:20 --> Total execution time: 0.0683
INFO - 2025-09-06 09:15:21 --> Config Class Initialized
INFO - 2025-09-06 09:15:21 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:15:21 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:15:21 --> Utf8 Class Initialized
INFO - 2025-09-06 09:15:21 --> URI Class Initialized
INFO - 2025-09-06 09:15:21 --> Router Class Initialized
INFO - 2025-09-06 09:15:21 --> Output Class Initialized
INFO - 2025-09-06 09:15:21 --> Security Class Initialized
DEBUG - 2025-09-06 09:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:15:21 --> Input Class Initialized
INFO - 2025-09-06 09:15:21 --> Language Class Initialized
INFO - 2025-09-06 09:15:21 --> Loader Class Initialized
INFO - 2025-09-06 09:15:21 --> Helper loaded: url_helper
INFO - 2025-09-06 09:15:21 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:15:21 --> Helper loaded: form_helper
INFO - 2025-09-06 09:15:21 --> Form Validation Class Initialized
INFO - 2025-09-06 09:15:21 --> Controller Class Initialized
INFO - 2025-09-06 09:15:21 --> Model "Center_model" initialized
INFO - 2025-09-06 09:15:21 --> Final output sent to browser
DEBUG - 2025-09-06 09:15:21 --> Total execution time: 0.0725
INFO - 2025-09-06 09:15:21 --> Config Class Initialized
INFO - 2025-09-06 09:15:21 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:15:21 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:15:21 --> Utf8 Class Initialized
INFO - 2025-09-06 09:15:21 --> URI Class Initialized
INFO - 2025-09-06 09:15:21 --> Router Class Initialized
INFO - 2025-09-06 09:15:21 --> Output Class Initialized
INFO - 2025-09-06 09:15:21 --> Security Class Initialized
DEBUG - 2025-09-06 09:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:15:21 --> Input Class Initialized
INFO - 2025-09-06 09:15:21 --> Language Class Initialized
INFO - 2025-09-06 09:15:21 --> Loader Class Initialized
INFO - 2025-09-06 09:15:21 --> Helper loaded: url_helper
INFO - 2025-09-06 09:15:21 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:15:21 --> Helper loaded: form_helper
INFO - 2025-09-06 09:15:21 --> Form Validation Class Initialized
INFO - 2025-09-06 09:15:21 --> Controller Class Initialized
INFO - 2025-09-06 09:15:21 --> Model "Center_model" initialized
INFO - 2025-09-06 09:15:21 --> Final output sent to browser
DEBUG - 2025-09-06 09:15:21 --> Total execution time: 0.0663
INFO - 2025-09-06 09:15:22 --> Config Class Initialized
INFO - 2025-09-06 09:15:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:15:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:15:22 --> Utf8 Class Initialized
INFO - 2025-09-06 09:15:22 --> URI Class Initialized
INFO - 2025-09-06 09:15:22 --> Router Class Initialized
INFO - 2025-09-06 09:15:22 --> Output Class Initialized
INFO - 2025-09-06 09:15:22 --> Security Class Initialized
DEBUG - 2025-09-06 09:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:15:22 --> Input Class Initialized
INFO - 2025-09-06 09:15:22 --> Language Class Initialized
INFO - 2025-09-06 09:15:22 --> Loader Class Initialized
INFO - 2025-09-06 09:15:22 --> Helper loaded: url_helper
INFO - 2025-09-06 09:15:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:15:22 --> Helper loaded: form_helper
INFO - 2025-09-06 09:15:22 --> Form Validation Class Initialized
INFO - 2025-09-06 09:15:22 --> Controller Class Initialized
INFO - 2025-09-06 09:15:22 --> Model "Center_model" initialized
INFO - 2025-09-06 09:15:22 --> Final output sent to browser
DEBUG - 2025-09-06 09:15:22 --> Total execution time: 0.0702
INFO - 2025-09-06 09:15:23 --> Config Class Initialized
INFO - 2025-09-06 09:15:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:15:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:15:23 --> Utf8 Class Initialized
INFO - 2025-09-06 09:15:23 --> URI Class Initialized
INFO - 2025-09-06 09:15:23 --> Router Class Initialized
INFO - 2025-09-06 09:15:23 --> Output Class Initialized
INFO - 2025-09-06 09:15:23 --> Security Class Initialized
DEBUG - 2025-09-06 09:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:15:24 --> Input Class Initialized
INFO - 2025-09-06 09:15:24 --> Language Class Initialized
INFO - 2025-09-06 09:15:24 --> Loader Class Initialized
INFO - 2025-09-06 09:15:24 --> Helper loaded: url_helper
INFO - 2025-09-06 09:15:24 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:15:24 --> Helper loaded: form_helper
INFO - 2025-09-06 09:15:24 --> Form Validation Class Initialized
INFO - 2025-09-06 09:15:24 --> Controller Class Initialized
INFO - 2025-09-06 09:15:24 --> Model "Center_model" initialized
INFO - 2025-09-06 09:15:24 --> Final output sent to browser
DEBUG - 2025-09-06 09:15:24 --> Total execution time: 0.0816
INFO - 2025-09-06 09:17:16 --> Config Class Initialized
INFO - 2025-09-06 09:17:16 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:16 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:16 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:16 --> URI Class Initialized
INFO - 2025-09-06 09:17:16 --> Router Class Initialized
INFO - 2025-09-06 09:17:16 --> Output Class Initialized
INFO - 2025-09-06 09:17:16 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:16 --> Input Class Initialized
INFO - 2025-09-06 09:17:16 --> Language Class Initialized
INFO - 2025-09-06 09:17:16 --> Loader Class Initialized
INFO - 2025-09-06 09:17:16 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:16 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:16 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:16 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:16 --> Controller Class Initialized
INFO - 2025-09-06 09:17:16 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:17:16 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:17:16 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:17:16 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:16 --> Total execution time: 0.1027
INFO - 2025-09-06 09:17:16 --> Config Class Initialized
INFO - 2025-09-06 09:17:16 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:16 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:16 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:16 --> URI Class Initialized
INFO - 2025-09-06 09:17:16 --> Router Class Initialized
INFO - 2025-09-06 09:17:16 --> Output Class Initialized
INFO - 2025-09-06 09:17:16 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:16 --> Input Class Initialized
INFO - 2025-09-06 09:17:16 --> Language Class Initialized
INFO - 2025-09-06 09:17:16 --> Loader Class Initialized
INFO - 2025-09-06 09:17:16 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:16 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:16 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:16 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:16 --> Controller Class Initialized
INFO - 2025-09-06 09:17:16 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:16 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:16 --> Total execution time: 0.0850
INFO - 2025-09-06 09:17:16 --> Config Class Initialized
INFO - 2025-09-06 09:17:16 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:17 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:17 --> URI Class Initialized
INFO - 2025-09-06 09:17:17 --> Router Class Initialized
INFO - 2025-09-06 09:17:17 --> Output Class Initialized
INFO - 2025-09-06 09:17:17 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:17 --> Input Class Initialized
INFO - 2025-09-06 09:17:17 --> Language Class Initialized
INFO - 2025-09-06 09:17:17 --> Loader Class Initialized
INFO - 2025-09-06 09:17:17 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:17 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:17 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:17 --> Controller Class Initialized
INFO - 2025-09-06 09:17:17 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:17 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:17 --> Total execution time: 0.0896
INFO - 2025-09-06 09:17:18 --> Config Class Initialized
INFO - 2025-09-06 09:17:18 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:18 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:18 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:18 --> URI Class Initialized
INFO - 2025-09-06 09:17:18 --> Router Class Initialized
INFO - 2025-09-06 09:17:18 --> Output Class Initialized
INFO - 2025-09-06 09:17:18 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:18 --> Input Class Initialized
INFO - 2025-09-06 09:17:18 --> Language Class Initialized
INFO - 2025-09-06 09:17:18 --> Loader Class Initialized
INFO - 2025-09-06 09:17:18 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:18 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:18 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:18 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:18 --> Controller Class Initialized
INFO - 2025-09-06 09:17:18 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:18 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:18 --> Total execution time: 0.0698
INFO - 2025-09-06 09:17:19 --> Config Class Initialized
INFO - 2025-09-06 09:17:19 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:19 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:19 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:19 --> URI Class Initialized
INFO - 2025-09-06 09:17:19 --> Router Class Initialized
INFO - 2025-09-06 09:17:19 --> Output Class Initialized
INFO - 2025-09-06 09:17:19 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:19 --> Input Class Initialized
INFO - 2025-09-06 09:17:19 --> Language Class Initialized
INFO - 2025-09-06 09:17:19 --> Loader Class Initialized
INFO - 2025-09-06 09:17:19 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:19 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:19 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:19 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:19 --> Controller Class Initialized
INFO - 2025-09-06 09:17:19 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:19 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:19 --> Total execution time: 0.0614
INFO - 2025-09-06 09:17:45 --> Config Class Initialized
INFO - 2025-09-06 09:17:45 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:45 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:45 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:45 --> URI Class Initialized
INFO - 2025-09-06 09:17:45 --> Router Class Initialized
INFO - 2025-09-06 09:17:45 --> Output Class Initialized
INFO - 2025-09-06 09:17:45 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:45 --> Input Class Initialized
INFO - 2025-09-06 09:17:45 --> Language Class Initialized
INFO - 2025-09-06 09:17:45 --> Loader Class Initialized
INFO - 2025-09-06 09:17:45 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:45 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:45 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:45 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:45 --> Controller Class Initialized
INFO - 2025-09-06 09:17:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:17:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:17:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 09:17:45 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:45 --> Total execution time: 0.0774
INFO - 2025-09-06 09:17:45 --> Config Class Initialized
INFO - 2025-09-06 09:17:45 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:45 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:45 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:45 --> URI Class Initialized
INFO - 2025-09-06 09:17:45 --> Router Class Initialized
INFO - 2025-09-06 09:17:45 --> Output Class Initialized
INFO - 2025-09-06 09:17:45 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:45 --> Input Class Initialized
INFO - 2025-09-06 09:17:45 --> Language Class Initialized
INFO - 2025-09-06 09:17:45 --> Loader Class Initialized
INFO - 2025-09-06 09:17:45 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:45 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:45 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:45 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:45 --> Controller Class Initialized
INFO - 2025-09-06 09:17:45 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:45 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:45 --> Total execution time: 0.0778
INFO - 2025-09-06 09:17:47 --> Config Class Initialized
INFO - 2025-09-06 09:17:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:47 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:47 --> URI Class Initialized
INFO - 2025-09-06 09:17:47 --> Router Class Initialized
INFO - 2025-09-06 09:17:47 --> Output Class Initialized
INFO - 2025-09-06 09:17:47 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:47 --> Input Class Initialized
INFO - 2025-09-06 09:17:47 --> Language Class Initialized
INFO - 2025-09-06 09:17:47 --> Loader Class Initialized
INFO - 2025-09-06 09:17:47 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:47 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:47 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:47 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:47 --> Controller Class Initialized
INFO - 2025-09-06 09:17:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:17:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:17:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:17:47 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:47 --> Total execution time: 0.0794
INFO - 2025-09-06 09:17:47 --> Config Class Initialized
INFO - 2025-09-06 09:17:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:47 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:47 --> URI Class Initialized
INFO - 2025-09-06 09:17:47 --> Router Class Initialized
INFO - 2025-09-06 09:17:47 --> Output Class Initialized
INFO - 2025-09-06 09:17:47 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:47 --> Input Class Initialized
INFO - 2025-09-06 09:17:47 --> Language Class Initialized
INFO - 2025-09-06 09:17:47 --> Loader Class Initialized
INFO - 2025-09-06 09:17:47 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:47 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:47 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:47 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:47 --> Controller Class Initialized
INFO - 2025-09-06 09:17:47 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:47 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:47 --> Total execution time: 0.0741
INFO - 2025-09-06 09:17:48 --> Config Class Initialized
INFO - 2025-09-06 09:17:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:48 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:48 --> URI Class Initialized
INFO - 2025-09-06 09:17:48 --> Router Class Initialized
INFO - 2025-09-06 09:17:48 --> Output Class Initialized
INFO - 2025-09-06 09:17:48 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:48 --> Input Class Initialized
INFO - 2025-09-06 09:17:48 --> Language Class Initialized
INFO - 2025-09-06 09:17:48 --> Loader Class Initialized
INFO - 2025-09-06 09:17:48 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:48 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:48 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:48 --> Controller Class Initialized
INFO - 2025-09-06 09:17:48 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:48 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:48 --> Total execution time: 0.0726
INFO - 2025-09-06 09:17:51 --> Config Class Initialized
INFO - 2025-09-06 09:17:51 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:51 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:51 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:51 --> URI Class Initialized
INFO - 2025-09-06 09:17:51 --> Router Class Initialized
INFO - 2025-09-06 09:17:51 --> Output Class Initialized
INFO - 2025-09-06 09:17:51 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:51 --> Input Class Initialized
INFO - 2025-09-06 09:17:51 --> Language Class Initialized
INFO - 2025-09-06 09:17:51 --> Loader Class Initialized
INFO - 2025-09-06 09:17:51 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:51 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:51 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:51 --> Controller Class Initialized
INFO - 2025-09-06 09:17:51 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:51 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:51 --> Total execution time: 0.0677
INFO - 2025-09-06 09:17:53 --> Config Class Initialized
INFO - 2025-09-06 09:17:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:53 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:54 --> URI Class Initialized
INFO - 2025-09-06 09:17:54 --> Router Class Initialized
INFO - 2025-09-06 09:17:54 --> Output Class Initialized
INFO - 2025-09-06 09:17:54 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:54 --> Input Class Initialized
INFO - 2025-09-06 09:17:54 --> Language Class Initialized
INFO - 2025-09-06 09:17:54 --> Loader Class Initialized
INFO - 2025-09-06 09:17:54 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:54 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:54 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:54 --> Controller Class Initialized
INFO - 2025-09-06 09:17:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:17:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:17:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 09:17:54 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:54 --> Total execution time: 0.1311
INFO - 2025-09-06 09:17:54 --> Config Class Initialized
INFO - 2025-09-06 09:17:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:54 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:54 --> URI Class Initialized
INFO - 2025-09-06 09:17:54 --> Router Class Initialized
INFO - 2025-09-06 09:17:54 --> Output Class Initialized
INFO - 2025-09-06 09:17:54 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:54 --> Input Class Initialized
INFO - 2025-09-06 09:17:54 --> Language Class Initialized
INFO - 2025-09-06 09:17:54 --> Loader Class Initialized
INFO - 2025-09-06 09:17:54 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:54 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:54 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:54 --> Controller Class Initialized
INFO - 2025-09-06 09:17:54 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:54 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:54 --> Total execution time: 0.0861
INFO - 2025-09-06 09:17:56 --> Config Class Initialized
INFO - 2025-09-06 09:17:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:56 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:56 --> URI Class Initialized
INFO - 2025-09-06 09:17:56 --> Router Class Initialized
INFO - 2025-09-06 09:17:56 --> Output Class Initialized
INFO - 2025-09-06 09:17:56 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:56 --> Input Class Initialized
INFO - 2025-09-06 09:17:56 --> Language Class Initialized
INFO - 2025-09-06 09:17:56 --> Loader Class Initialized
INFO - 2025-09-06 09:17:56 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:56 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:56 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:56 --> Controller Class Initialized
INFO - 2025-09-06 09:17:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:17:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:17:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:17:56 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:56 --> Total execution time: 0.0826
INFO - 2025-09-06 09:17:56 --> Config Class Initialized
INFO - 2025-09-06 09:17:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:56 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:56 --> URI Class Initialized
INFO - 2025-09-06 09:17:56 --> Router Class Initialized
INFO - 2025-09-06 09:17:56 --> Output Class Initialized
INFO - 2025-09-06 09:17:56 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:56 --> Input Class Initialized
INFO - 2025-09-06 09:17:56 --> Language Class Initialized
INFO - 2025-09-06 09:17:56 --> Loader Class Initialized
INFO - 2025-09-06 09:17:56 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:56 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:56 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:56 --> Controller Class Initialized
INFO - 2025-09-06 09:17:56 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:56 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:56 --> Total execution time: 0.0953
INFO - 2025-09-06 09:17:56 --> Config Class Initialized
INFO - 2025-09-06 09:17:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:56 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:56 --> URI Class Initialized
INFO - 2025-09-06 09:17:56 --> Router Class Initialized
INFO - 2025-09-06 09:17:56 --> Output Class Initialized
INFO - 2025-09-06 09:17:56 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:56 --> Input Class Initialized
INFO - 2025-09-06 09:17:56 --> Language Class Initialized
INFO - 2025-09-06 09:17:56 --> Loader Class Initialized
INFO - 2025-09-06 09:17:56 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:56 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:56 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:56 --> Controller Class Initialized
INFO - 2025-09-06 09:17:56 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:56 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:56 --> Total execution time: 0.0790
INFO - 2025-09-06 09:17:57 --> Config Class Initialized
INFO - 2025-09-06 09:17:57 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:17:57 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:17:57 --> Utf8 Class Initialized
INFO - 2025-09-06 09:17:57 --> URI Class Initialized
INFO - 2025-09-06 09:17:57 --> Router Class Initialized
INFO - 2025-09-06 09:17:57 --> Output Class Initialized
INFO - 2025-09-06 09:17:57 --> Security Class Initialized
DEBUG - 2025-09-06 09:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:17:57 --> Input Class Initialized
INFO - 2025-09-06 09:17:57 --> Language Class Initialized
INFO - 2025-09-06 09:17:57 --> Loader Class Initialized
INFO - 2025-09-06 09:17:57 --> Helper loaded: url_helper
INFO - 2025-09-06 09:17:57 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:17:57 --> Helper loaded: form_helper
INFO - 2025-09-06 09:17:57 --> Form Validation Class Initialized
INFO - 2025-09-06 09:17:57 --> Controller Class Initialized
INFO - 2025-09-06 09:17:57 --> Model "Center_model" initialized
INFO - 2025-09-06 09:17:57 --> Final output sent to browser
DEBUG - 2025-09-06 09:17:57 --> Total execution time: 0.1057
INFO - 2025-09-06 09:18:02 --> Config Class Initialized
INFO - 2025-09-06 09:18:02 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:18:02 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:18:02 --> Utf8 Class Initialized
INFO - 2025-09-06 09:18:02 --> URI Class Initialized
INFO - 2025-09-06 09:18:02 --> Router Class Initialized
INFO - 2025-09-06 09:18:02 --> Output Class Initialized
INFO - 2025-09-06 09:18:02 --> Security Class Initialized
DEBUG - 2025-09-06 09:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:18:02 --> Input Class Initialized
INFO - 2025-09-06 09:18:02 --> Language Class Initialized
INFO - 2025-09-06 09:18:02 --> Loader Class Initialized
INFO - 2025-09-06 09:18:02 --> Helper loaded: url_helper
INFO - 2025-09-06 09:18:02 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:18:02 --> Helper loaded: form_helper
INFO - 2025-09-06 09:18:02 --> Form Validation Class Initialized
INFO - 2025-09-06 09:18:02 --> Controller Class Initialized
INFO - 2025-09-06 09:18:02 --> Model "Center_model" initialized
INFO - 2025-09-06 09:18:02 --> Final output sent to browser
DEBUG - 2025-09-06 09:18:02 --> Total execution time: 0.0529
INFO - 2025-09-06 09:19:25 --> Config Class Initialized
INFO - 2025-09-06 09:19:25 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:19:25 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:19:25 --> Utf8 Class Initialized
INFO - 2025-09-06 09:19:25 --> URI Class Initialized
INFO - 2025-09-06 09:19:25 --> Router Class Initialized
INFO - 2025-09-06 09:19:25 --> Output Class Initialized
INFO - 2025-09-06 09:19:25 --> Security Class Initialized
DEBUG - 2025-09-06 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:19:25 --> Input Class Initialized
INFO - 2025-09-06 09:19:25 --> Language Class Initialized
INFO - 2025-09-06 09:19:25 --> Loader Class Initialized
INFO - 2025-09-06 09:19:25 --> Helper loaded: url_helper
INFO - 2025-09-06 09:19:25 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:19:26 --> Helper loaded: form_helper
INFO - 2025-09-06 09:19:26 --> Form Validation Class Initialized
INFO - 2025-09-06 09:19:26 --> Controller Class Initialized
INFO - 2025-09-06 09:19:26 --> Model "Center_model" initialized
INFO - 2025-09-06 09:19:26 --> Final output sent to browser
DEBUG - 2025-09-06 09:19:26 --> Total execution time: 0.0650
INFO - 2025-09-06 09:24:50 --> Config Class Initialized
INFO - 2025-09-06 09:24:50 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:24:50 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:24:50 --> Utf8 Class Initialized
INFO - 2025-09-06 09:24:50 --> URI Class Initialized
INFO - 2025-09-06 09:24:50 --> Router Class Initialized
INFO - 2025-09-06 09:24:50 --> Output Class Initialized
INFO - 2025-09-06 09:24:50 --> Security Class Initialized
DEBUG - 2025-09-06 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:24:50 --> Input Class Initialized
INFO - 2025-09-06 09:24:50 --> Language Class Initialized
INFO - 2025-09-06 09:24:50 --> Loader Class Initialized
INFO - 2025-09-06 09:24:50 --> Helper loaded: url_helper
INFO - 2025-09-06 09:24:50 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:24:50 --> Helper loaded: form_helper
INFO - 2025-09-06 09:24:50 --> Form Validation Class Initialized
INFO - 2025-09-06 09:24:50 --> Controller Class Initialized
INFO - 2025-09-06 09:24:50 --> Model "Center_model" initialized
INFO - 2025-09-06 09:24:50 --> Final output sent to browser
DEBUG - 2025-09-06 09:24:50 --> Total execution time: 0.0879
INFO - 2025-09-06 09:24:52 --> Config Class Initialized
INFO - 2025-09-06 09:24:52 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:24:52 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:24:52 --> Utf8 Class Initialized
INFO - 2025-09-06 09:24:52 --> URI Class Initialized
INFO - 2025-09-06 09:24:52 --> Router Class Initialized
INFO - 2025-09-06 09:24:52 --> Output Class Initialized
INFO - 2025-09-06 09:24:52 --> Security Class Initialized
DEBUG - 2025-09-06 09:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:24:52 --> Input Class Initialized
INFO - 2025-09-06 09:24:52 --> Language Class Initialized
INFO - 2025-09-06 09:24:52 --> Loader Class Initialized
INFO - 2025-09-06 09:24:52 --> Helper loaded: url_helper
INFO - 2025-09-06 09:24:52 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:24:52 --> Helper loaded: form_helper
INFO - 2025-09-06 09:24:52 --> Form Validation Class Initialized
INFO - 2025-09-06 09:24:52 --> Controller Class Initialized
INFO - 2025-09-06 09:24:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:24:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:24:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:24:52 --> Final output sent to browser
DEBUG - 2025-09-06 09:24:52 --> Total execution time: 0.1093
INFO - 2025-09-06 09:24:52 --> Config Class Initialized
INFO - 2025-09-06 09:24:52 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:24:52 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:24:52 --> Utf8 Class Initialized
INFO - 2025-09-06 09:24:52 --> URI Class Initialized
INFO - 2025-09-06 09:24:52 --> Router Class Initialized
INFO - 2025-09-06 09:24:52 --> Output Class Initialized
INFO - 2025-09-06 09:24:52 --> Security Class Initialized
DEBUG - 2025-09-06 09:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:24:52 --> Input Class Initialized
INFO - 2025-09-06 09:24:52 --> Language Class Initialized
INFO - 2025-09-06 09:24:52 --> Loader Class Initialized
INFO - 2025-09-06 09:24:52 --> Helper loaded: url_helper
INFO - 2025-09-06 09:24:52 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:24:52 --> Helper loaded: form_helper
INFO - 2025-09-06 09:24:52 --> Form Validation Class Initialized
INFO - 2025-09-06 09:24:52 --> Controller Class Initialized
INFO - 2025-09-06 09:24:52 --> Model "Center_model" initialized
INFO - 2025-09-06 09:24:52 --> Final output sent to browser
DEBUG - 2025-09-06 09:24:52 --> Total execution time: 0.0735
INFO - 2025-09-06 09:24:52 --> Config Class Initialized
INFO - 2025-09-06 09:24:52 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:24:52 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:24:52 --> Utf8 Class Initialized
INFO - 2025-09-06 09:24:52 --> URI Class Initialized
INFO - 2025-09-06 09:24:52 --> Router Class Initialized
INFO - 2025-09-06 09:24:52 --> Output Class Initialized
INFO - 2025-09-06 09:24:52 --> Security Class Initialized
DEBUG - 2025-09-06 09:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:24:52 --> Input Class Initialized
INFO - 2025-09-06 09:24:52 --> Language Class Initialized
INFO - 2025-09-06 09:24:52 --> Loader Class Initialized
INFO - 2025-09-06 09:24:52 --> Helper loaded: url_helper
INFO - 2025-09-06 09:24:52 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:24:52 --> Helper loaded: form_helper
INFO - 2025-09-06 09:24:52 --> Form Validation Class Initialized
INFO - 2025-09-06 09:24:52 --> Controller Class Initialized
INFO - 2025-09-06 09:24:52 --> Model "Center_model" initialized
INFO - 2025-09-06 09:24:52 --> Final output sent to browser
DEBUG - 2025-09-06 09:24:52 --> Total execution time: 0.0891
INFO - 2025-09-06 09:24:56 --> Config Class Initialized
INFO - 2025-09-06 09:24:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:24:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:24:56 --> Utf8 Class Initialized
INFO - 2025-09-06 09:24:56 --> URI Class Initialized
INFO - 2025-09-06 09:24:56 --> Router Class Initialized
INFO - 2025-09-06 09:24:56 --> Output Class Initialized
INFO - 2025-09-06 09:24:56 --> Security Class Initialized
DEBUG - 2025-09-06 09:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:24:56 --> Input Class Initialized
INFO - 2025-09-06 09:24:56 --> Language Class Initialized
INFO - 2025-09-06 09:24:56 --> Loader Class Initialized
INFO - 2025-09-06 09:24:56 --> Helper loaded: url_helper
INFO - 2025-09-06 09:24:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:24:56 --> Helper loaded: form_helper
INFO - 2025-09-06 09:24:56 --> Form Validation Class Initialized
INFO - 2025-09-06 09:24:56 --> Controller Class Initialized
INFO - 2025-09-06 09:24:56 --> Model "Center_model" initialized
INFO - 2025-09-06 09:24:56 --> Final output sent to browser
DEBUG - 2025-09-06 09:24:56 --> Total execution time: 0.0668
INFO - 2025-09-06 09:27:46 --> Config Class Initialized
INFO - 2025-09-06 09:27:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:27:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:27:46 --> Utf8 Class Initialized
INFO - 2025-09-06 09:27:46 --> URI Class Initialized
INFO - 2025-09-06 09:27:46 --> Router Class Initialized
INFO - 2025-09-06 09:27:46 --> Output Class Initialized
INFO - 2025-09-06 09:27:46 --> Security Class Initialized
DEBUG - 2025-09-06 09:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:27:46 --> Input Class Initialized
INFO - 2025-09-06 09:27:46 --> Language Class Initialized
INFO - 2025-09-06 09:27:46 --> Loader Class Initialized
INFO - 2025-09-06 09:27:46 --> Helper loaded: url_helper
INFO - 2025-09-06 09:27:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:27:46 --> Helper loaded: form_helper
INFO - 2025-09-06 09:27:46 --> Form Validation Class Initialized
INFO - 2025-09-06 09:27:46 --> Controller Class Initialized
INFO - 2025-09-06 09:27:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:27:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:27:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:27:46 --> Final output sent to browser
DEBUG - 2025-09-06 09:27:46 --> Total execution time: 0.0964
INFO - 2025-09-06 09:27:46 --> Config Class Initialized
INFO - 2025-09-06 09:27:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:27:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:27:46 --> Utf8 Class Initialized
INFO - 2025-09-06 09:27:46 --> URI Class Initialized
INFO - 2025-09-06 09:27:46 --> Router Class Initialized
INFO - 2025-09-06 09:27:46 --> Output Class Initialized
INFO - 2025-09-06 09:27:46 --> Security Class Initialized
DEBUG - 2025-09-06 09:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:27:46 --> Input Class Initialized
INFO - 2025-09-06 09:27:46 --> Language Class Initialized
INFO - 2025-09-06 09:27:46 --> Loader Class Initialized
INFO - 2025-09-06 09:27:46 --> Helper loaded: url_helper
INFO - 2025-09-06 09:27:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:27:46 --> Helper loaded: form_helper
INFO - 2025-09-06 09:27:46 --> Form Validation Class Initialized
INFO - 2025-09-06 09:27:46 --> Controller Class Initialized
INFO - 2025-09-06 09:27:46 --> Model "Center_model" initialized
INFO - 2025-09-06 09:27:46 --> Final output sent to browser
DEBUG - 2025-09-06 09:27:46 --> Total execution time: 0.0756
INFO - 2025-09-06 09:27:46 --> Config Class Initialized
INFO - 2025-09-06 09:27:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:27:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:27:46 --> Utf8 Class Initialized
INFO - 2025-09-06 09:27:46 --> URI Class Initialized
INFO - 2025-09-06 09:27:46 --> Router Class Initialized
INFO - 2025-09-06 09:27:46 --> Output Class Initialized
INFO - 2025-09-06 09:27:46 --> Security Class Initialized
DEBUG - 2025-09-06 09:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:27:46 --> Input Class Initialized
INFO - 2025-09-06 09:27:46 --> Language Class Initialized
INFO - 2025-09-06 09:27:46 --> Loader Class Initialized
INFO - 2025-09-06 09:27:46 --> Helper loaded: url_helper
INFO - 2025-09-06 09:27:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:27:46 --> Helper loaded: form_helper
INFO - 2025-09-06 09:27:46 --> Form Validation Class Initialized
INFO - 2025-09-06 09:27:46 --> Controller Class Initialized
INFO - 2025-09-06 09:27:46 --> Model "Center_model" initialized
INFO - 2025-09-06 09:27:46 --> Final output sent to browser
DEBUG - 2025-09-06 09:27:46 --> Total execution time: 0.1071
INFO - 2025-09-06 09:27:47 --> Config Class Initialized
INFO - 2025-09-06 09:27:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:27:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:27:47 --> Utf8 Class Initialized
INFO - 2025-09-06 09:27:47 --> URI Class Initialized
INFO - 2025-09-06 09:27:47 --> Router Class Initialized
INFO - 2025-09-06 09:27:47 --> Output Class Initialized
INFO - 2025-09-06 09:27:47 --> Security Class Initialized
DEBUG - 2025-09-06 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:27:47 --> Input Class Initialized
INFO - 2025-09-06 09:27:47 --> Language Class Initialized
INFO - 2025-09-06 09:27:47 --> Loader Class Initialized
INFO - 2025-09-06 09:27:47 --> Helper loaded: url_helper
INFO - 2025-09-06 09:27:47 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:27:48 --> Helper loaded: form_helper
INFO - 2025-09-06 09:27:48 --> Form Validation Class Initialized
INFO - 2025-09-06 09:27:48 --> Controller Class Initialized
INFO - 2025-09-06 09:27:48 --> Model "Center_model" initialized
INFO - 2025-09-06 09:27:48 --> Final output sent to browser
DEBUG - 2025-09-06 09:27:48 --> Total execution time: 0.0787
INFO - 2025-09-06 09:27:49 --> Config Class Initialized
INFO - 2025-09-06 09:27:49 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:27:49 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:27:49 --> Utf8 Class Initialized
INFO - 2025-09-06 09:27:49 --> URI Class Initialized
INFO - 2025-09-06 09:27:49 --> Router Class Initialized
INFO - 2025-09-06 09:27:49 --> Output Class Initialized
INFO - 2025-09-06 09:27:49 --> Security Class Initialized
DEBUG - 2025-09-06 09:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:27:49 --> Input Class Initialized
INFO - 2025-09-06 09:27:49 --> Language Class Initialized
INFO - 2025-09-06 09:27:49 --> Loader Class Initialized
INFO - 2025-09-06 09:27:49 --> Helper loaded: url_helper
INFO - 2025-09-06 09:27:49 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:27:49 --> Helper loaded: form_helper
INFO - 2025-09-06 09:27:49 --> Form Validation Class Initialized
INFO - 2025-09-06 09:27:49 --> Controller Class Initialized
INFO - 2025-09-06 09:27:49 --> Model "Center_model" initialized
INFO - 2025-09-06 09:27:49 --> Final output sent to browser
DEBUG - 2025-09-06 09:27:49 --> Total execution time: 0.0640
INFO - 2025-09-06 09:27:59 --> Config Class Initialized
INFO - 2025-09-06 09:27:59 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:27:59 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:27:59 --> Utf8 Class Initialized
INFO - 2025-09-06 09:27:59 --> URI Class Initialized
INFO - 2025-09-06 09:27:59 --> Router Class Initialized
INFO - 2025-09-06 09:27:59 --> Output Class Initialized
INFO - 2025-09-06 09:27:59 --> Security Class Initialized
DEBUG - 2025-09-06 09:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:27:59 --> Input Class Initialized
INFO - 2025-09-06 09:27:59 --> Language Class Initialized
INFO - 2025-09-06 09:27:59 --> Loader Class Initialized
INFO - 2025-09-06 09:27:59 --> Helper loaded: url_helper
INFO - 2025-09-06 09:27:59 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:27:59 --> Helper loaded: form_helper
INFO - 2025-09-06 09:27:59 --> Form Validation Class Initialized
INFO - 2025-09-06 09:27:59 --> Controller Class Initialized
INFO - 2025-09-06 09:27:59 --> Model "Center_model" initialized
INFO - 2025-09-06 09:27:59 --> Final output sent to browser
DEBUG - 2025-09-06 09:27:59 --> Total execution time: 0.0524
INFO - 2025-09-06 09:29:22 --> Config Class Initialized
INFO - 2025-09-06 09:29:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:29:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:29:22 --> Utf8 Class Initialized
INFO - 2025-09-06 09:29:22 --> URI Class Initialized
INFO - 2025-09-06 09:29:22 --> Router Class Initialized
INFO - 2025-09-06 09:29:22 --> Output Class Initialized
INFO - 2025-09-06 09:29:22 --> Security Class Initialized
DEBUG - 2025-09-06 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:29:22 --> Input Class Initialized
INFO - 2025-09-06 09:29:22 --> Language Class Initialized
INFO - 2025-09-06 09:29:22 --> Loader Class Initialized
INFO - 2025-09-06 09:29:22 --> Helper loaded: url_helper
INFO - 2025-09-06 09:29:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:29:22 --> Helper loaded: form_helper
INFO - 2025-09-06 09:29:22 --> Form Validation Class Initialized
INFO - 2025-09-06 09:29:22 --> Controller Class Initialized
INFO - 2025-09-06 09:29:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:29:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:29:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:29:22 --> Final output sent to browser
DEBUG - 2025-09-06 09:29:22 --> Total execution time: 0.0691
INFO - 2025-09-06 09:29:22 --> Config Class Initialized
INFO - 2025-09-06 09:29:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:29:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:29:22 --> Utf8 Class Initialized
INFO - 2025-09-06 09:29:22 --> URI Class Initialized
INFO - 2025-09-06 09:29:22 --> Router Class Initialized
INFO - 2025-09-06 09:29:22 --> Output Class Initialized
INFO - 2025-09-06 09:29:22 --> Security Class Initialized
DEBUG - 2025-09-06 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:29:22 --> Input Class Initialized
INFO - 2025-09-06 09:29:22 --> Language Class Initialized
INFO - 2025-09-06 09:29:22 --> Loader Class Initialized
INFO - 2025-09-06 09:29:22 --> Helper loaded: url_helper
INFO - 2025-09-06 09:29:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:29:22 --> Helper loaded: form_helper
INFO - 2025-09-06 09:29:22 --> Form Validation Class Initialized
INFO - 2025-09-06 09:29:22 --> Controller Class Initialized
INFO - 2025-09-06 09:29:22 --> Model "Center_model" initialized
INFO - 2025-09-06 09:29:22 --> Final output sent to browser
DEBUG - 2025-09-06 09:29:22 --> Total execution time: 0.0749
INFO - 2025-09-06 09:29:22 --> Config Class Initialized
INFO - 2025-09-06 09:29:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:29:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:29:22 --> Utf8 Class Initialized
INFO - 2025-09-06 09:29:22 --> URI Class Initialized
INFO - 2025-09-06 09:29:22 --> Router Class Initialized
INFO - 2025-09-06 09:29:22 --> Output Class Initialized
INFO - 2025-09-06 09:29:22 --> Security Class Initialized
DEBUG - 2025-09-06 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:29:22 --> Input Class Initialized
INFO - 2025-09-06 09:29:22 --> Language Class Initialized
INFO - 2025-09-06 09:29:22 --> Loader Class Initialized
INFO - 2025-09-06 09:29:22 --> Helper loaded: url_helper
INFO - 2025-09-06 09:29:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:29:22 --> Helper loaded: form_helper
INFO - 2025-09-06 09:29:22 --> Form Validation Class Initialized
INFO - 2025-09-06 09:29:22 --> Controller Class Initialized
INFO - 2025-09-06 09:29:22 --> Model "Center_model" initialized
INFO - 2025-09-06 09:29:22 --> Final output sent to browser
DEBUG - 2025-09-06 09:29:22 --> Total execution time: 0.0636
INFO - 2025-09-06 09:29:24 --> Config Class Initialized
INFO - 2025-09-06 09:29:24 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:29:24 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:29:24 --> Utf8 Class Initialized
INFO - 2025-09-06 09:29:24 --> URI Class Initialized
INFO - 2025-09-06 09:29:24 --> Router Class Initialized
INFO - 2025-09-06 09:29:24 --> Output Class Initialized
INFO - 2025-09-06 09:29:24 --> Security Class Initialized
DEBUG - 2025-09-06 09:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:29:24 --> Input Class Initialized
INFO - 2025-09-06 09:29:24 --> Language Class Initialized
INFO - 2025-09-06 09:29:24 --> Loader Class Initialized
INFO - 2025-09-06 09:29:24 --> Helper loaded: url_helper
INFO - 2025-09-06 09:29:24 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:29:24 --> Helper loaded: form_helper
INFO - 2025-09-06 09:29:24 --> Form Validation Class Initialized
INFO - 2025-09-06 09:29:24 --> Controller Class Initialized
INFO - 2025-09-06 09:29:24 --> Model "Center_model" initialized
INFO - 2025-09-06 09:29:24 --> Final output sent to browser
DEBUG - 2025-09-06 09:29:24 --> Total execution time: 0.0784
INFO - 2025-09-06 09:29:32 --> Config Class Initialized
INFO - 2025-09-06 09:29:32 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:29:32 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:29:32 --> Utf8 Class Initialized
INFO - 2025-09-06 09:29:32 --> URI Class Initialized
INFO - 2025-09-06 09:29:32 --> Router Class Initialized
INFO - 2025-09-06 09:29:32 --> Output Class Initialized
INFO - 2025-09-06 09:29:32 --> Security Class Initialized
DEBUG - 2025-09-06 09:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:29:32 --> Input Class Initialized
INFO - 2025-09-06 09:29:32 --> Language Class Initialized
INFO - 2025-09-06 09:29:32 --> Loader Class Initialized
INFO - 2025-09-06 09:29:32 --> Helper loaded: url_helper
INFO - 2025-09-06 09:29:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:29:32 --> Helper loaded: form_helper
INFO - 2025-09-06 09:29:32 --> Form Validation Class Initialized
INFO - 2025-09-06 09:29:32 --> Controller Class Initialized
INFO - 2025-09-06 09:29:32 --> Model "Center_model" initialized
INFO - 2025-09-06 09:29:32 --> Final output sent to browser
DEBUG - 2025-09-06 09:29:32 --> Total execution time: 0.0608
INFO - 2025-09-06 09:29:44 --> Config Class Initialized
INFO - 2025-09-06 09:29:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:29:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:29:44 --> Utf8 Class Initialized
INFO - 2025-09-06 09:29:44 --> URI Class Initialized
INFO - 2025-09-06 09:29:44 --> Router Class Initialized
INFO - 2025-09-06 09:29:44 --> Output Class Initialized
INFO - 2025-09-06 09:29:44 --> Security Class Initialized
DEBUG - 2025-09-06 09:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:29:44 --> Input Class Initialized
INFO - 2025-09-06 09:29:44 --> Language Class Initialized
INFO - 2025-09-06 09:29:44 --> Loader Class Initialized
INFO - 2025-09-06 09:29:44 --> Helper loaded: url_helper
INFO - 2025-09-06 09:29:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:29:44 --> Helper loaded: form_helper
INFO - 2025-09-06 09:29:44 --> Form Validation Class Initialized
INFO - 2025-09-06 09:29:44 --> Controller Class Initialized
INFO - 2025-09-06 09:29:44 --> Model "Center_model" initialized
INFO - 2025-09-06 09:29:44 --> Final output sent to browser
DEBUG - 2025-09-06 09:29:44 --> Total execution time: 0.0537
INFO - 2025-09-06 09:30:22 --> Config Class Initialized
INFO - 2025-09-06 09:30:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:30:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:30:22 --> Utf8 Class Initialized
INFO - 2025-09-06 09:30:22 --> URI Class Initialized
INFO - 2025-09-06 09:30:22 --> Router Class Initialized
INFO - 2025-09-06 09:30:22 --> Output Class Initialized
INFO - 2025-09-06 09:30:22 --> Security Class Initialized
DEBUG - 2025-09-06 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:30:22 --> Input Class Initialized
INFO - 2025-09-06 09:30:22 --> Language Class Initialized
INFO - 2025-09-06 09:30:22 --> Loader Class Initialized
INFO - 2025-09-06 09:30:22 --> Helper loaded: url_helper
INFO - 2025-09-06 09:30:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:30:22 --> Helper loaded: form_helper
INFO - 2025-09-06 09:30:22 --> Form Validation Class Initialized
INFO - 2025-09-06 09:30:22 --> Controller Class Initialized
INFO - 2025-09-06 09:30:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:30:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:30:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:30:22 --> Final output sent to browser
DEBUG - 2025-09-06 09:30:22 --> Total execution time: 0.0965
INFO - 2025-09-06 09:30:22 --> Config Class Initialized
INFO - 2025-09-06 09:30:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:30:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:30:22 --> Utf8 Class Initialized
INFO - 2025-09-06 09:30:22 --> URI Class Initialized
INFO - 2025-09-06 09:30:22 --> Router Class Initialized
INFO - 2025-09-06 09:30:22 --> Output Class Initialized
INFO - 2025-09-06 09:30:22 --> Security Class Initialized
DEBUG - 2025-09-06 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:30:22 --> Input Class Initialized
INFO - 2025-09-06 09:30:22 --> Language Class Initialized
INFO - 2025-09-06 09:30:22 --> Loader Class Initialized
INFO - 2025-09-06 09:30:22 --> Helper loaded: url_helper
INFO - 2025-09-06 09:30:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:30:22 --> Helper loaded: form_helper
INFO - 2025-09-06 09:30:22 --> Form Validation Class Initialized
INFO - 2025-09-06 09:30:22 --> Controller Class Initialized
INFO - 2025-09-06 09:30:22 --> Model "Center_model" initialized
INFO - 2025-09-06 09:30:22 --> Final output sent to browser
DEBUG - 2025-09-06 09:30:22 --> Total execution time: 0.0757
INFO - 2025-09-06 09:30:24 --> Config Class Initialized
INFO - 2025-09-06 09:30:24 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:30:24 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:30:24 --> Utf8 Class Initialized
INFO - 2025-09-06 09:30:24 --> URI Class Initialized
INFO - 2025-09-06 09:30:24 --> Router Class Initialized
INFO - 2025-09-06 09:30:25 --> Output Class Initialized
INFO - 2025-09-06 09:30:25 --> Security Class Initialized
DEBUG - 2025-09-06 09:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:30:25 --> Input Class Initialized
INFO - 2025-09-06 09:30:25 --> Language Class Initialized
INFO - 2025-09-06 09:30:25 --> Loader Class Initialized
INFO - 2025-09-06 09:30:25 --> Helper loaded: url_helper
INFO - 2025-09-06 09:30:25 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:30:25 --> Helper loaded: form_helper
INFO - 2025-09-06 09:30:25 --> Form Validation Class Initialized
INFO - 2025-09-06 09:30:25 --> Controller Class Initialized
INFO - 2025-09-06 09:30:25 --> Model "Center_model" initialized
INFO - 2025-09-06 09:30:25 --> Final output sent to browser
DEBUG - 2025-09-06 09:30:25 --> Total execution time: 0.0731
INFO - 2025-09-06 09:32:44 --> Config Class Initialized
INFO - 2025-09-06 09:32:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:32:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:32:44 --> Utf8 Class Initialized
INFO - 2025-09-06 09:32:44 --> URI Class Initialized
INFO - 2025-09-06 09:32:44 --> Router Class Initialized
INFO - 2025-09-06 09:32:44 --> Output Class Initialized
INFO - 2025-09-06 09:32:44 --> Security Class Initialized
DEBUG - 2025-09-06 09:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:32:44 --> Input Class Initialized
INFO - 2025-09-06 09:32:44 --> Language Class Initialized
INFO - 2025-09-06 09:32:44 --> Loader Class Initialized
INFO - 2025-09-06 09:32:44 --> Helper loaded: url_helper
INFO - 2025-09-06 09:32:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:32:44 --> Helper loaded: form_helper
INFO - 2025-09-06 09:32:44 --> Form Validation Class Initialized
INFO - 2025-09-06 09:32:44 --> Controller Class Initialized
INFO - 2025-09-06 09:32:44 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:32:44 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:32:44 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:32:44 --> Final output sent to browser
DEBUG - 2025-09-06 09:32:44 --> Total execution time: 0.0942
INFO - 2025-09-06 09:32:44 --> Config Class Initialized
INFO - 2025-09-06 09:32:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:32:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:32:44 --> Utf8 Class Initialized
INFO - 2025-09-06 09:32:44 --> URI Class Initialized
INFO - 2025-09-06 09:32:44 --> Router Class Initialized
INFO - 2025-09-06 09:32:44 --> Output Class Initialized
INFO - 2025-09-06 09:32:44 --> Security Class Initialized
DEBUG - 2025-09-06 09:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:32:44 --> Input Class Initialized
INFO - 2025-09-06 09:32:44 --> Language Class Initialized
INFO - 2025-09-06 09:32:44 --> Loader Class Initialized
INFO - 2025-09-06 09:32:44 --> Helper loaded: url_helper
INFO - 2025-09-06 09:32:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:32:44 --> Helper loaded: form_helper
INFO - 2025-09-06 09:32:44 --> Form Validation Class Initialized
INFO - 2025-09-06 09:32:44 --> Controller Class Initialized
INFO - 2025-09-06 09:32:44 --> Model "Center_model" initialized
INFO - 2025-09-06 09:32:44 --> Final output sent to browser
DEBUG - 2025-09-06 09:32:44 --> Total execution time: 0.0660
INFO - 2025-09-06 09:32:44 --> Config Class Initialized
INFO - 2025-09-06 09:32:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:32:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:32:44 --> Utf8 Class Initialized
INFO - 2025-09-06 09:32:44 --> URI Class Initialized
INFO - 2025-09-06 09:32:44 --> Router Class Initialized
INFO - 2025-09-06 09:32:44 --> Output Class Initialized
INFO - 2025-09-06 09:32:44 --> Security Class Initialized
DEBUG - 2025-09-06 09:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:32:44 --> Input Class Initialized
INFO - 2025-09-06 09:32:44 --> Language Class Initialized
INFO - 2025-09-06 09:32:44 --> Loader Class Initialized
INFO - 2025-09-06 09:32:44 --> Helper loaded: url_helper
INFO - 2025-09-06 09:32:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:32:44 --> Helper loaded: form_helper
INFO - 2025-09-06 09:32:44 --> Form Validation Class Initialized
INFO - 2025-09-06 09:32:44 --> Controller Class Initialized
INFO - 2025-09-06 09:32:44 --> Model "Center_model" initialized
INFO - 2025-09-06 09:32:44 --> Final output sent to browser
DEBUG - 2025-09-06 09:32:44 --> Total execution time: 0.0587
INFO - 2025-09-06 09:32:46 --> Config Class Initialized
INFO - 2025-09-06 09:32:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:32:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:32:46 --> Utf8 Class Initialized
INFO - 2025-09-06 09:32:46 --> URI Class Initialized
INFO - 2025-09-06 09:32:46 --> Router Class Initialized
INFO - 2025-09-06 09:32:46 --> Output Class Initialized
INFO - 2025-09-06 09:32:46 --> Security Class Initialized
DEBUG - 2025-09-06 09:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:32:46 --> Input Class Initialized
INFO - 2025-09-06 09:32:46 --> Language Class Initialized
INFO - 2025-09-06 09:32:46 --> Loader Class Initialized
INFO - 2025-09-06 09:32:46 --> Helper loaded: url_helper
INFO - 2025-09-06 09:32:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:32:46 --> Helper loaded: form_helper
INFO - 2025-09-06 09:32:46 --> Form Validation Class Initialized
INFO - 2025-09-06 09:32:46 --> Controller Class Initialized
INFO - 2025-09-06 09:32:46 --> Model "Center_model" initialized
INFO - 2025-09-06 09:32:46 --> Final output sent to browser
DEBUG - 2025-09-06 09:32:46 --> Total execution time: 0.0530
INFO - 2025-09-06 09:32:49 --> Config Class Initialized
INFO - 2025-09-06 09:32:49 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:32:49 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:32:49 --> Utf8 Class Initialized
INFO - 2025-09-06 09:32:49 --> URI Class Initialized
INFO - 2025-09-06 09:32:49 --> Router Class Initialized
INFO - 2025-09-06 09:32:49 --> Output Class Initialized
INFO - 2025-09-06 09:32:49 --> Security Class Initialized
DEBUG - 2025-09-06 09:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:32:49 --> Input Class Initialized
INFO - 2025-09-06 09:32:49 --> Language Class Initialized
INFO - 2025-09-06 09:32:49 --> Loader Class Initialized
INFO - 2025-09-06 09:32:49 --> Helper loaded: url_helper
INFO - 2025-09-06 09:32:49 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:32:49 --> Helper loaded: form_helper
INFO - 2025-09-06 09:32:49 --> Form Validation Class Initialized
INFO - 2025-09-06 09:32:49 --> Controller Class Initialized
INFO - 2025-09-06 09:32:49 --> Model "Center_model" initialized
INFO - 2025-09-06 09:32:49 --> Final output sent to browser
DEBUG - 2025-09-06 09:32:49 --> Total execution time: 0.0657
INFO - 2025-09-06 09:33:05 --> Config Class Initialized
INFO - 2025-09-06 09:33:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:33:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:33:05 --> Utf8 Class Initialized
INFO - 2025-09-06 09:33:05 --> URI Class Initialized
INFO - 2025-09-06 09:33:05 --> Router Class Initialized
INFO - 2025-09-06 09:33:05 --> Output Class Initialized
INFO - 2025-09-06 09:33:05 --> Security Class Initialized
DEBUG - 2025-09-06 09:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:33:05 --> Input Class Initialized
INFO - 2025-09-06 09:33:05 --> Language Class Initialized
INFO - 2025-09-06 09:33:05 --> Loader Class Initialized
INFO - 2025-09-06 09:33:05 --> Helper loaded: url_helper
INFO - 2025-09-06 09:33:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:33:05 --> Helper loaded: form_helper
INFO - 2025-09-06 09:33:05 --> Form Validation Class Initialized
INFO - 2025-09-06 09:33:05 --> Controller Class Initialized
INFO - 2025-09-06 09:33:05 --> Model "Center_model" initialized
INFO - 2025-09-06 09:33:05 --> Final output sent to browser
DEBUG - 2025-09-06 09:33:05 --> Total execution time: 0.0564
INFO - 2025-09-06 09:33:07 --> Config Class Initialized
INFO - 2025-09-06 09:33:07 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:33:07 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:33:07 --> Utf8 Class Initialized
INFO - 2025-09-06 09:33:07 --> URI Class Initialized
INFO - 2025-09-06 09:33:07 --> Router Class Initialized
INFO - 2025-09-06 09:33:07 --> Output Class Initialized
INFO - 2025-09-06 09:33:07 --> Security Class Initialized
DEBUG - 2025-09-06 09:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:33:07 --> Input Class Initialized
INFO - 2025-09-06 09:33:07 --> Language Class Initialized
INFO - 2025-09-06 09:33:07 --> Loader Class Initialized
INFO - 2025-09-06 09:33:07 --> Helper loaded: url_helper
INFO - 2025-09-06 09:33:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:33:07 --> Helper loaded: form_helper
INFO - 2025-09-06 09:33:07 --> Form Validation Class Initialized
INFO - 2025-09-06 09:33:07 --> Controller Class Initialized
INFO - 2025-09-06 09:33:07 --> Model "Center_model" initialized
INFO - 2025-09-06 09:33:07 --> Final output sent to browser
DEBUG - 2025-09-06 09:33:07 --> Total execution time: 0.0537
INFO - 2025-09-06 09:33:44 --> Config Class Initialized
INFO - 2025-09-06 09:33:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:33:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:33:44 --> Utf8 Class Initialized
INFO - 2025-09-06 09:33:44 --> URI Class Initialized
INFO - 2025-09-06 09:33:44 --> Router Class Initialized
INFO - 2025-09-06 09:33:44 --> Output Class Initialized
INFO - 2025-09-06 09:33:44 --> Security Class Initialized
DEBUG - 2025-09-06 09:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:33:44 --> Input Class Initialized
INFO - 2025-09-06 09:33:44 --> Language Class Initialized
INFO - 2025-09-06 09:33:44 --> Loader Class Initialized
INFO - 2025-09-06 09:33:44 --> Helper loaded: url_helper
INFO - 2025-09-06 09:33:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:33:44 --> Helper loaded: form_helper
INFO - 2025-09-06 09:33:44 --> Form Validation Class Initialized
INFO - 2025-09-06 09:33:44 --> Controller Class Initialized
INFO - 2025-09-06 09:33:44 --> Model "Center_model" initialized
INFO - 2025-09-06 09:33:44 --> Final output sent to browser
DEBUG - 2025-09-06 09:33:44 --> Total execution time: 0.0565
INFO - 2025-09-06 09:41:57 --> Config Class Initialized
INFO - 2025-09-06 09:41:57 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:41:57 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:41:57 --> Utf8 Class Initialized
INFO - 2025-09-06 09:41:57 --> URI Class Initialized
INFO - 2025-09-06 09:41:57 --> Router Class Initialized
INFO - 2025-09-06 09:41:57 --> Output Class Initialized
INFO - 2025-09-06 09:41:57 --> Security Class Initialized
DEBUG - 2025-09-06 09:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:41:57 --> Input Class Initialized
INFO - 2025-09-06 09:41:57 --> Language Class Initialized
INFO - 2025-09-06 09:41:57 --> Loader Class Initialized
INFO - 2025-09-06 09:41:57 --> Helper loaded: url_helper
INFO - 2025-09-06 09:41:57 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:41:57 --> Helper loaded: form_helper
INFO - 2025-09-06 09:41:57 --> Form Validation Class Initialized
INFO - 2025-09-06 09:41:57 --> Controller Class Initialized
INFO - 2025-09-06 09:41:57 --> Model "Center_model" initialized
INFO - 2025-09-06 09:41:57 --> Final output sent to browser
DEBUG - 2025-09-06 09:41:57 --> Total execution time: 0.0916
INFO - 2025-09-06 09:41:59 --> Config Class Initialized
INFO - 2025-09-06 09:41:59 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:41:59 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:41:59 --> Utf8 Class Initialized
INFO - 2025-09-06 09:41:59 --> URI Class Initialized
INFO - 2025-09-06 09:41:59 --> Router Class Initialized
INFO - 2025-09-06 09:41:59 --> Output Class Initialized
INFO - 2025-09-06 09:41:59 --> Security Class Initialized
DEBUG - 2025-09-06 09:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:41:59 --> Input Class Initialized
INFO - 2025-09-06 09:41:59 --> Language Class Initialized
INFO - 2025-09-06 09:41:59 --> Loader Class Initialized
INFO - 2025-09-06 09:41:59 --> Helper loaded: url_helper
INFO - 2025-09-06 09:41:59 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:41:59 --> Helper loaded: form_helper
INFO - 2025-09-06 09:41:59 --> Form Validation Class Initialized
INFO - 2025-09-06 09:41:59 --> Controller Class Initialized
INFO - 2025-09-06 09:41:59 --> Model "Center_model" initialized
INFO - 2025-09-06 09:41:59 --> Final output sent to browser
DEBUG - 2025-09-06 09:41:59 --> Total execution time: 0.0684
INFO - 2025-09-06 09:42:11 --> Config Class Initialized
INFO - 2025-09-06 09:42:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:11 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:11 --> URI Class Initialized
INFO - 2025-09-06 09:42:11 --> Router Class Initialized
INFO - 2025-09-06 09:42:11 --> Output Class Initialized
INFO - 2025-09-06 09:42:11 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:11 --> Input Class Initialized
INFO - 2025-09-06 09:42:11 --> Language Class Initialized
INFO - 2025-09-06 09:42:11 --> Loader Class Initialized
INFO - 2025-09-06 09:42:11 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:11 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:11 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:11 --> Controller Class Initialized
INFO - 2025-09-06 09:42:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:42:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:42:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 09:42:11 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:11 --> Total execution time: 0.0920
INFO - 2025-09-06 09:42:12 --> Config Class Initialized
INFO - 2025-09-06 09:42:12 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:12 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:12 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:12 --> URI Class Initialized
INFO - 2025-09-06 09:42:12 --> Router Class Initialized
INFO - 2025-09-06 09:42:12 --> Output Class Initialized
INFO - 2025-09-06 09:42:12 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:12 --> Input Class Initialized
INFO - 2025-09-06 09:42:12 --> Language Class Initialized
INFO - 2025-09-06 09:42:12 --> Loader Class Initialized
INFO - 2025-09-06 09:42:12 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:12 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:12 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:12 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:12 --> Controller Class Initialized
INFO - 2025-09-06 09:42:12 --> Model "Center_model" initialized
INFO - 2025-09-06 09:42:12 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:12 --> Total execution time: 0.0802
INFO - 2025-09-06 09:42:15 --> Config Class Initialized
INFO - 2025-09-06 09:42:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:15 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:15 --> URI Class Initialized
INFO - 2025-09-06 09:42:15 --> Router Class Initialized
INFO - 2025-09-06 09:42:15 --> Output Class Initialized
INFO - 2025-09-06 09:42:15 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:15 --> Input Class Initialized
INFO - 2025-09-06 09:42:15 --> Language Class Initialized
INFO - 2025-09-06 09:42:15 --> Loader Class Initialized
INFO - 2025-09-06 09:42:15 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:15 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:15 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:15 --> Controller Class Initialized
INFO - 2025-09-06 09:42:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:42:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:42:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:42:15 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:15 --> Total execution time: 0.0969
INFO - 2025-09-06 09:42:15 --> Config Class Initialized
INFO - 2025-09-06 09:42:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:15 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:15 --> URI Class Initialized
INFO - 2025-09-06 09:42:15 --> Router Class Initialized
INFO - 2025-09-06 09:42:15 --> Output Class Initialized
INFO - 2025-09-06 09:42:15 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:15 --> Input Class Initialized
INFO - 2025-09-06 09:42:15 --> Language Class Initialized
INFO - 2025-09-06 09:42:15 --> Loader Class Initialized
INFO - 2025-09-06 09:42:15 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:15 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:15 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:15 --> Controller Class Initialized
INFO - 2025-09-06 09:42:15 --> Model "Center_model" initialized
INFO - 2025-09-06 09:42:15 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:15 --> Total execution time: 0.0912
INFO - 2025-09-06 09:42:15 --> Config Class Initialized
INFO - 2025-09-06 09:42:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:15 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:15 --> URI Class Initialized
INFO - 2025-09-06 09:42:15 --> Router Class Initialized
INFO - 2025-09-06 09:42:15 --> Output Class Initialized
INFO - 2025-09-06 09:42:15 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:15 --> Input Class Initialized
INFO - 2025-09-06 09:42:15 --> Language Class Initialized
INFO - 2025-09-06 09:42:15 --> Loader Class Initialized
INFO - 2025-09-06 09:42:15 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:15 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:15 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:15 --> Controller Class Initialized
INFO - 2025-09-06 09:42:16 --> Model "Center_model" initialized
INFO - 2025-09-06 09:42:16 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:16 --> Total execution time: 0.0786
INFO - 2025-09-06 09:42:17 --> Config Class Initialized
INFO - 2025-09-06 09:42:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:17 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:17 --> URI Class Initialized
INFO - 2025-09-06 09:42:17 --> Router Class Initialized
INFO - 2025-09-06 09:42:17 --> Output Class Initialized
INFO - 2025-09-06 09:42:17 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:17 --> Input Class Initialized
INFO - 2025-09-06 09:42:17 --> Language Class Initialized
INFO - 2025-09-06 09:42:17 --> Loader Class Initialized
INFO - 2025-09-06 09:42:17 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:17 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:17 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:17 --> Controller Class Initialized
INFO - 2025-09-06 09:42:17 --> Model "Center_model" initialized
INFO - 2025-09-06 09:42:17 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:17 --> Total execution time: 0.0802
INFO - 2025-09-06 09:42:26 --> Config Class Initialized
INFO - 2025-09-06 09:42:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:26 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:26 --> URI Class Initialized
INFO - 2025-09-06 09:42:26 --> Router Class Initialized
INFO - 2025-09-06 09:42:26 --> Output Class Initialized
INFO - 2025-09-06 09:42:26 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:26 --> Input Class Initialized
INFO - 2025-09-06 09:42:26 --> Language Class Initialized
INFO - 2025-09-06 09:42:26 --> Loader Class Initialized
INFO - 2025-09-06 09:42:26 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:26 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:26 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:26 --> Controller Class Initialized
INFO - 2025-09-06 09:42:26 --> Model "Center_model" initialized
INFO - 2025-09-06 09:42:26 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:26 --> Total execution time: 0.0734
INFO - 2025-09-06 09:42:35 --> Config Class Initialized
INFO - 2025-09-06 09:42:35 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:35 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:35 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:35 --> URI Class Initialized
INFO - 2025-09-06 09:42:35 --> Router Class Initialized
INFO - 2025-09-06 09:42:35 --> Output Class Initialized
INFO - 2025-09-06 09:42:35 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:35 --> Input Class Initialized
INFO - 2025-09-06 09:42:35 --> Language Class Initialized
INFO - 2025-09-06 09:42:35 --> Loader Class Initialized
INFO - 2025-09-06 09:42:35 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:35 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:35 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:35 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:35 --> Controller Class Initialized
INFO - 2025-09-06 09:42:35 --> Model "Center_model" initialized
INFO - 2025-09-06 09:42:35 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:35 --> Total execution time: 0.0665
INFO - 2025-09-06 09:42:38 --> Config Class Initialized
INFO - 2025-09-06 09:42:38 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:42:38 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:42:38 --> Utf8 Class Initialized
INFO - 2025-09-06 09:42:38 --> URI Class Initialized
INFO - 2025-09-06 09:42:38 --> Router Class Initialized
INFO - 2025-09-06 09:42:38 --> Output Class Initialized
INFO - 2025-09-06 09:42:38 --> Security Class Initialized
DEBUG - 2025-09-06 09:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:42:38 --> Input Class Initialized
INFO - 2025-09-06 09:42:38 --> Language Class Initialized
INFO - 2025-09-06 09:42:38 --> Loader Class Initialized
INFO - 2025-09-06 09:42:38 --> Helper loaded: url_helper
INFO - 2025-09-06 09:42:38 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:42:38 --> Helper loaded: form_helper
INFO - 2025-09-06 09:42:38 --> Form Validation Class Initialized
INFO - 2025-09-06 09:42:38 --> Controller Class Initialized
INFO - 2025-09-06 09:42:38 --> Model "Center_model" initialized
INFO - 2025-09-06 09:42:38 --> Final output sent to browser
DEBUG - 2025-09-06 09:42:38 --> Total execution time: 0.0633
INFO - 2025-09-06 09:44:14 --> Config Class Initialized
INFO - 2025-09-06 09:44:14 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:44:14 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:44:14 --> Utf8 Class Initialized
INFO - 2025-09-06 09:44:14 --> URI Class Initialized
INFO - 2025-09-06 09:44:14 --> Router Class Initialized
INFO - 2025-09-06 09:44:14 --> Output Class Initialized
INFO - 2025-09-06 09:44:14 --> Security Class Initialized
DEBUG - 2025-09-06 09:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:44:14 --> Input Class Initialized
INFO - 2025-09-06 09:44:14 --> Language Class Initialized
INFO - 2025-09-06 09:44:14 --> Loader Class Initialized
INFO - 2025-09-06 09:44:14 --> Helper loaded: url_helper
INFO - 2025-09-06 09:44:14 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:44:14 --> Helper loaded: form_helper
INFO - 2025-09-06 09:44:14 --> Form Validation Class Initialized
INFO - 2025-09-06 09:44:14 --> Controller Class Initialized
INFO - 2025-09-06 09:44:14 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:44:14 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:44:14 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 09:44:14 --> Final output sent to browser
DEBUG - 2025-09-06 09:44:14 --> Total execution time: 0.0777
INFO - 2025-09-06 09:44:14 --> Config Class Initialized
INFO - 2025-09-06 09:44:14 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:44:14 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:44:14 --> Utf8 Class Initialized
INFO - 2025-09-06 09:44:14 --> URI Class Initialized
INFO - 2025-09-06 09:44:14 --> Router Class Initialized
INFO - 2025-09-06 09:44:14 --> Output Class Initialized
INFO - 2025-09-06 09:44:14 --> Security Class Initialized
DEBUG - 2025-09-06 09:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:44:14 --> Input Class Initialized
INFO - 2025-09-06 09:44:14 --> Language Class Initialized
INFO - 2025-09-06 09:44:14 --> Loader Class Initialized
INFO - 2025-09-06 09:44:14 --> Helper loaded: url_helper
INFO - 2025-09-06 09:44:14 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:44:14 --> Helper loaded: form_helper
INFO - 2025-09-06 09:44:14 --> Form Validation Class Initialized
INFO - 2025-09-06 09:44:14 --> Controller Class Initialized
INFO - 2025-09-06 09:44:14 --> Model "Center_model" initialized
INFO - 2025-09-06 09:44:14 --> Final output sent to browser
DEBUG - 2025-09-06 09:44:14 --> Total execution time: 0.0657
INFO - 2025-09-06 09:44:17 --> Config Class Initialized
INFO - 2025-09-06 09:44:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:44:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:44:17 --> Utf8 Class Initialized
INFO - 2025-09-06 09:44:17 --> URI Class Initialized
INFO - 2025-09-06 09:44:17 --> Router Class Initialized
INFO - 2025-09-06 09:44:17 --> Output Class Initialized
INFO - 2025-09-06 09:44:17 --> Security Class Initialized
DEBUG - 2025-09-06 09:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:44:17 --> Input Class Initialized
INFO - 2025-09-06 09:44:17 --> Language Class Initialized
INFO - 2025-09-06 09:44:17 --> Loader Class Initialized
INFO - 2025-09-06 09:44:17 --> Helper loaded: url_helper
INFO - 2025-09-06 09:44:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:44:17 --> Helper loaded: form_helper
INFO - 2025-09-06 09:44:17 --> Form Validation Class Initialized
INFO - 2025-09-06 09:44:17 --> Controller Class Initialized
INFO - 2025-09-06 09:44:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:44:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:44:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:44:17 --> Final output sent to browser
DEBUG - 2025-09-06 09:44:17 --> Total execution time: 0.0601
INFO - 2025-09-06 09:44:17 --> Config Class Initialized
INFO - 2025-09-06 09:44:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:44:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:44:17 --> Utf8 Class Initialized
INFO - 2025-09-06 09:44:17 --> URI Class Initialized
INFO - 2025-09-06 09:44:17 --> Router Class Initialized
INFO - 2025-09-06 09:44:17 --> Output Class Initialized
INFO - 2025-09-06 09:44:17 --> Security Class Initialized
DEBUG - 2025-09-06 09:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:44:17 --> Input Class Initialized
INFO - 2025-09-06 09:44:17 --> Language Class Initialized
INFO - 2025-09-06 09:44:17 --> Loader Class Initialized
INFO - 2025-09-06 09:44:17 --> Helper loaded: url_helper
INFO - 2025-09-06 09:44:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:44:17 --> Helper loaded: form_helper
INFO - 2025-09-06 09:44:17 --> Form Validation Class Initialized
INFO - 2025-09-06 09:44:17 --> Controller Class Initialized
INFO - 2025-09-06 09:44:17 --> Model "Center_model" initialized
INFO - 2025-09-06 09:44:17 --> Final output sent to browser
DEBUG - 2025-09-06 09:44:17 --> Total execution time: 0.0706
INFO - 2025-09-06 09:44:17 --> Config Class Initialized
INFO - 2025-09-06 09:44:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:44:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:44:17 --> Utf8 Class Initialized
INFO - 2025-09-06 09:44:17 --> URI Class Initialized
INFO - 2025-09-06 09:44:17 --> Router Class Initialized
INFO - 2025-09-06 09:44:17 --> Output Class Initialized
INFO - 2025-09-06 09:44:17 --> Security Class Initialized
DEBUG - 2025-09-06 09:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:44:17 --> Input Class Initialized
INFO - 2025-09-06 09:44:17 --> Language Class Initialized
INFO - 2025-09-06 09:44:17 --> Loader Class Initialized
INFO - 2025-09-06 09:44:17 --> Helper loaded: url_helper
INFO - 2025-09-06 09:44:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:44:17 --> Helper loaded: form_helper
INFO - 2025-09-06 09:44:17 --> Form Validation Class Initialized
INFO - 2025-09-06 09:44:17 --> Controller Class Initialized
INFO - 2025-09-06 09:44:17 --> Model "Center_model" initialized
INFO - 2025-09-06 09:44:17 --> Final output sent to browser
DEBUG - 2025-09-06 09:44:17 --> Total execution time: 0.0797
INFO - 2025-09-06 09:44:18 --> Config Class Initialized
INFO - 2025-09-06 09:44:18 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:44:18 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:44:18 --> Utf8 Class Initialized
INFO - 2025-09-06 09:44:18 --> URI Class Initialized
INFO - 2025-09-06 09:44:18 --> Router Class Initialized
INFO - 2025-09-06 09:44:18 --> Output Class Initialized
INFO - 2025-09-06 09:44:18 --> Security Class Initialized
DEBUG - 2025-09-06 09:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:44:18 --> Input Class Initialized
INFO - 2025-09-06 09:44:18 --> Language Class Initialized
INFO - 2025-09-06 09:44:18 --> Loader Class Initialized
INFO - 2025-09-06 09:44:18 --> Helper loaded: url_helper
INFO - 2025-09-06 09:44:18 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:44:18 --> Helper loaded: form_helper
INFO - 2025-09-06 09:44:18 --> Form Validation Class Initialized
INFO - 2025-09-06 09:44:18 --> Controller Class Initialized
INFO - 2025-09-06 09:44:18 --> Model "Center_model" initialized
INFO - 2025-09-06 09:44:18 --> Final output sent to browser
DEBUG - 2025-09-06 09:44:18 --> Total execution time: 0.0537
INFO - 2025-09-06 09:46:16 --> Config Class Initialized
INFO - 2025-09-06 09:46:16 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:16 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:16 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:16 --> URI Class Initialized
INFO - 2025-09-06 09:46:16 --> Router Class Initialized
INFO - 2025-09-06 09:46:16 --> Output Class Initialized
INFO - 2025-09-06 09:46:16 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:16 --> Input Class Initialized
INFO - 2025-09-06 09:46:16 --> Language Class Initialized
INFO - 2025-09-06 09:46:16 --> Loader Class Initialized
INFO - 2025-09-06 09:46:16 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:16 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:16 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:16 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:16 --> Controller Class Initialized
INFO - 2025-09-06 09:46:16 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:16 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:16 --> Total execution time: 0.0531
INFO - 2025-09-06 09:46:23 --> Config Class Initialized
INFO - 2025-09-06 09:46:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:23 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:23 --> URI Class Initialized
INFO - 2025-09-06 09:46:23 --> Router Class Initialized
INFO - 2025-09-06 09:46:23 --> Output Class Initialized
INFO - 2025-09-06 09:46:23 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:23 --> Input Class Initialized
INFO - 2025-09-06 09:46:23 --> Language Class Initialized
INFO - 2025-09-06 09:46:23 --> Loader Class Initialized
INFO - 2025-09-06 09:46:23 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:23 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:23 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:23 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:23 --> Controller Class Initialized
INFO - 2025-09-06 09:46:23 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:23 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:23 --> Total execution time: 0.0711
INFO - 2025-09-06 09:46:31 --> Config Class Initialized
INFO - 2025-09-06 09:46:31 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:31 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:31 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:31 --> URI Class Initialized
INFO - 2025-09-06 09:46:31 --> Router Class Initialized
INFO - 2025-09-06 09:46:31 --> Output Class Initialized
INFO - 2025-09-06 09:46:31 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:31 --> Input Class Initialized
INFO - 2025-09-06 09:46:31 --> Language Class Initialized
INFO - 2025-09-06 09:46:31 --> Loader Class Initialized
INFO - 2025-09-06 09:46:31 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:31 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:31 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:31 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:31 --> Controller Class Initialized
INFO - 2025-09-06 09:46:31 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:31 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:31 --> Total execution time: 0.0544
INFO - 2025-09-06 09:46:40 --> Config Class Initialized
INFO - 2025-09-06 09:46:40 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:40 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:40 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:40 --> URI Class Initialized
INFO - 2025-09-06 09:46:40 --> Router Class Initialized
INFO - 2025-09-06 09:46:40 --> Output Class Initialized
INFO - 2025-09-06 09:46:40 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:40 --> Input Class Initialized
INFO - 2025-09-06 09:46:40 --> Language Class Initialized
INFO - 2025-09-06 09:46:40 --> Loader Class Initialized
INFO - 2025-09-06 09:46:40 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:40 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:40 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:40 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:40 --> Controller Class Initialized
INFO - 2025-09-06 09:46:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:46:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:46:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 09:46:40 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:40 --> Total execution time: 0.0975
INFO - 2025-09-06 09:46:40 --> Config Class Initialized
INFO - 2025-09-06 09:46:40 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:40 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:40 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:40 --> URI Class Initialized
INFO - 2025-09-06 09:46:40 --> Router Class Initialized
INFO - 2025-09-06 09:46:40 --> Output Class Initialized
INFO - 2025-09-06 09:46:40 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:40 --> Input Class Initialized
INFO - 2025-09-06 09:46:40 --> Language Class Initialized
INFO - 2025-09-06 09:46:40 --> Loader Class Initialized
INFO - 2025-09-06 09:46:40 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:40 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:40 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:40 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:40 --> Controller Class Initialized
INFO - 2025-09-06 09:46:40 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:40 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:40 --> Total execution time: 0.0806
INFO - 2025-09-06 09:46:44 --> Config Class Initialized
INFO - 2025-09-06 09:46:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:44 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:44 --> URI Class Initialized
INFO - 2025-09-06 09:46:44 --> Router Class Initialized
INFO - 2025-09-06 09:46:44 --> Output Class Initialized
INFO - 2025-09-06 09:46:44 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:44 --> Input Class Initialized
INFO - 2025-09-06 09:46:44 --> Language Class Initialized
INFO - 2025-09-06 09:46:44 --> Loader Class Initialized
INFO - 2025-09-06 09:46:44 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:44 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:44 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:44 --> Controller Class Initialized
INFO - 2025-09-06 09:46:44 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:46:44 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:46:44 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:46:44 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:44 --> Total execution time: 0.0799
INFO - 2025-09-06 09:46:44 --> Config Class Initialized
INFO - 2025-09-06 09:46:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:44 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:44 --> URI Class Initialized
INFO - 2025-09-06 09:46:44 --> Router Class Initialized
INFO - 2025-09-06 09:46:44 --> Output Class Initialized
INFO - 2025-09-06 09:46:44 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:44 --> Input Class Initialized
INFO - 2025-09-06 09:46:44 --> Language Class Initialized
INFO - 2025-09-06 09:46:44 --> Loader Class Initialized
INFO - 2025-09-06 09:46:44 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:44 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:44 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:44 --> Controller Class Initialized
INFO - 2025-09-06 09:46:44 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:44 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:44 --> Total execution time: 0.0731
INFO - 2025-09-06 09:46:44 --> Config Class Initialized
INFO - 2025-09-06 09:46:44 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:44 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:44 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:44 --> URI Class Initialized
INFO - 2025-09-06 09:46:44 --> Router Class Initialized
INFO - 2025-09-06 09:46:44 --> Output Class Initialized
INFO - 2025-09-06 09:46:44 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:44 --> Input Class Initialized
INFO - 2025-09-06 09:46:44 --> Language Class Initialized
INFO - 2025-09-06 09:46:44 --> Loader Class Initialized
INFO - 2025-09-06 09:46:44 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:44 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:44 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:44 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:44 --> Controller Class Initialized
INFO - 2025-09-06 09:46:44 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:44 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:44 --> Total execution time: 0.0704
INFO - 2025-09-06 09:46:46 --> Config Class Initialized
INFO - 2025-09-06 09:46:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:46 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:46 --> URI Class Initialized
INFO - 2025-09-06 09:46:46 --> Router Class Initialized
INFO - 2025-09-06 09:46:46 --> Output Class Initialized
INFO - 2025-09-06 09:46:46 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:46 --> Input Class Initialized
INFO - 2025-09-06 09:46:46 --> Language Class Initialized
INFO - 2025-09-06 09:46:46 --> Loader Class Initialized
INFO - 2025-09-06 09:46:46 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:46 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:46 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:46 --> Controller Class Initialized
INFO - 2025-09-06 09:46:46 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:46 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:46 --> Total execution time: 0.0710
INFO - 2025-09-06 09:46:46 --> Config Class Initialized
INFO - 2025-09-06 09:46:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:46 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:46 --> URI Class Initialized
INFO - 2025-09-06 09:46:46 --> Router Class Initialized
INFO - 2025-09-06 09:46:46 --> Output Class Initialized
INFO - 2025-09-06 09:46:46 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:46 --> Input Class Initialized
INFO - 2025-09-06 09:46:46 --> Language Class Initialized
INFO - 2025-09-06 09:46:46 --> Loader Class Initialized
INFO - 2025-09-06 09:46:46 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:46 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:46 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:46 --> Controller Class Initialized
INFO - 2025-09-06 09:46:46 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:46 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:46 --> Total execution time: 0.0692
INFO - 2025-09-06 09:46:47 --> Config Class Initialized
INFO - 2025-09-06 09:46:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:47 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:47 --> URI Class Initialized
INFO - 2025-09-06 09:46:47 --> Router Class Initialized
INFO - 2025-09-06 09:46:47 --> Output Class Initialized
INFO - 2025-09-06 09:46:47 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:47 --> Input Class Initialized
INFO - 2025-09-06 09:46:47 --> Language Class Initialized
INFO - 2025-09-06 09:46:47 --> Loader Class Initialized
INFO - 2025-09-06 09:46:47 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:47 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:47 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:47 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:47 --> Controller Class Initialized
INFO - 2025-09-06 09:46:47 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:47 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:47 --> Total execution time: 0.0823
INFO - 2025-09-06 09:46:48 --> Config Class Initialized
INFO - 2025-09-06 09:46:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:48 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:48 --> URI Class Initialized
INFO - 2025-09-06 09:46:48 --> Router Class Initialized
INFO - 2025-09-06 09:46:48 --> Output Class Initialized
INFO - 2025-09-06 09:46:48 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:48 --> Input Class Initialized
INFO - 2025-09-06 09:46:48 --> Language Class Initialized
INFO - 2025-09-06 09:46:48 --> Loader Class Initialized
INFO - 2025-09-06 09:46:48 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:48 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:48 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:48 --> Controller Class Initialized
INFO - 2025-09-06 09:46:48 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:48 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:48 --> Total execution time: 0.0468
INFO - 2025-09-06 09:46:49 --> Config Class Initialized
INFO - 2025-09-06 09:46:49 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:49 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:49 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:49 --> URI Class Initialized
INFO - 2025-09-06 09:46:49 --> Router Class Initialized
INFO - 2025-09-06 09:46:49 --> Output Class Initialized
INFO - 2025-09-06 09:46:49 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:49 --> Input Class Initialized
INFO - 2025-09-06 09:46:49 --> Language Class Initialized
INFO - 2025-09-06 09:46:49 --> Loader Class Initialized
INFO - 2025-09-06 09:46:49 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:49 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:49 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:49 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:49 --> Controller Class Initialized
INFO - 2025-09-06 09:46:49 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:49 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:49 --> Total execution time: 0.0506
INFO - 2025-09-06 09:46:54 --> Config Class Initialized
INFO - 2025-09-06 09:46:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:54 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:54 --> URI Class Initialized
INFO - 2025-09-06 09:46:54 --> Router Class Initialized
INFO - 2025-09-06 09:46:54 --> Output Class Initialized
INFO - 2025-09-06 09:46:54 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:54 --> Input Class Initialized
INFO - 2025-09-06 09:46:54 --> Language Class Initialized
INFO - 2025-09-06 09:46:54 --> Loader Class Initialized
INFO - 2025-09-06 09:46:54 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:54 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:54 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:54 --> Controller Class Initialized
INFO - 2025-09-06 09:46:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:46:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:46:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 09:46:54 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:54 --> Total execution time: 0.0618
INFO - 2025-09-06 09:46:54 --> Config Class Initialized
INFO - 2025-09-06 09:46:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:54 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:54 --> URI Class Initialized
INFO - 2025-09-06 09:46:54 --> Router Class Initialized
INFO - 2025-09-06 09:46:54 --> Output Class Initialized
INFO - 2025-09-06 09:46:54 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:54 --> Input Class Initialized
INFO - 2025-09-06 09:46:54 --> Language Class Initialized
INFO - 2025-09-06 09:46:54 --> Loader Class Initialized
INFO - 2025-09-06 09:46:54 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:54 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:54 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:54 --> Controller Class Initialized
INFO - 2025-09-06 09:46:54 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:54 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:54 --> Total execution time: 0.0603
INFO - 2025-09-06 09:46:58 --> Config Class Initialized
INFO - 2025-09-06 09:46:58 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:58 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:58 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:58 --> URI Class Initialized
INFO - 2025-09-06 09:46:58 --> Router Class Initialized
INFO - 2025-09-06 09:46:58 --> Output Class Initialized
INFO - 2025-09-06 09:46:58 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:58 --> Input Class Initialized
INFO - 2025-09-06 09:46:58 --> Language Class Initialized
INFO - 2025-09-06 09:46:58 --> Loader Class Initialized
INFO - 2025-09-06 09:46:58 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:58 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:58 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:58 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:58 --> Controller Class Initialized
INFO - 2025-09-06 09:46:58 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:46:58 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:46:58 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:46:58 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:58 --> Total execution time: 0.0634
INFO - 2025-09-06 09:46:58 --> Config Class Initialized
INFO - 2025-09-06 09:46:58 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:58 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:58 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:58 --> URI Class Initialized
INFO - 2025-09-06 09:46:58 --> Router Class Initialized
INFO - 2025-09-06 09:46:58 --> Output Class Initialized
INFO - 2025-09-06 09:46:58 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:58 --> Input Class Initialized
INFO - 2025-09-06 09:46:58 --> Language Class Initialized
INFO - 2025-09-06 09:46:58 --> Loader Class Initialized
INFO - 2025-09-06 09:46:58 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:58 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:58 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:58 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:58 --> Controller Class Initialized
INFO - 2025-09-06 09:46:58 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:58 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:58 --> Total execution time: 0.0611
INFO - 2025-09-06 09:46:58 --> Config Class Initialized
INFO - 2025-09-06 09:46:58 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:46:58 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:46:58 --> Utf8 Class Initialized
INFO - 2025-09-06 09:46:58 --> URI Class Initialized
INFO - 2025-09-06 09:46:58 --> Router Class Initialized
INFO - 2025-09-06 09:46:58 --> Output Class Initialized
INFO - 2025-09-06 09:46:58 --> Security Class Initialized
DEBUG - 2025-09-06 09:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:46:58 --> Input Class Initialized
INFO - 2025-09-06 09:46:58 --> Language Class Initialized
INFO - 2025-09-06 09:46:58 --> Loader Class Initialized
INFO - 2025-09-06 09:46:58 --> Helper loaded: url_helper
INFO - 2025-09-06 09:46:58 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:46:58 --> Helper loaded: form_helper
INFO - 2025-09-06 09:46:58 --> Form Validation Class Initialized
INFO - 2025-09-06 09:46:58 --> Controller Class Initialized
INFO - 2025-09-06 09:46:58 --> Model "Center_model" initialized
INFO - 2025-09-06 09:46:58 --> Final output sent to browser
DEBUG - 2025-09-06 09:46:58 --> Total execution time: 0.0741
INFO - 2025-09-06 09:47:00 --> Config Class Initialized
INFO - 2025-09-06 09:47:00 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:00 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:00 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:00 --> URI Class Initialized
INFO - 2025-09-06 09:47:00 --> Router Class Initialized
INFO - 2025-09-06 09:47:00 --> Output Class Initialized
INFO - 2025-09-06 09:47:00 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:00 --> Input Class Initialized
INFO - 2025-09-06 09:47:00 --> Language Class Initialized
INFO - 2025-09-06 09:47:00 --> Loader Class Initialized
INFO - 2025-09-06 09:47:00 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:00 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:00 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:00 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:00 --> Controller Class Initialized
INFO - 2025-09-06 09:47:00 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:00 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:00 --> Total execution time: 0.0833
INFO - 2025-09-06 09:47:01 --> Config Class Initialized
INFO - 2025-09-06 09:47:01 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:01 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:01 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:01 --> URI Class Initialized
INFO - 2025-09-06 09:47:01 --> Router Class Initialized
INFO - 2025-09-06 09:47:01 --> Output Class Initialized
INFO - 2025-09-06 09:47:01 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:01 --> Input Class Initialized
INFO - 2025-09-06 09:47:01 --> Language Class Initialized
INFO - 2025-09-06 09:47:01 --> Loader Class Initialized
INFO - 2025-09-06 09:47:01 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:01 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:02 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:02 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:02 --> Controller Class Initialized
INFO - 2025-09-06 09:47:02 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:02 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:02 --> Total execution time: 0.0866
INFO - 2025-09-06 09:47:13 --> Config Class Initialized
INFO - 2025-09-06 09:47:13 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:13 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:13 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:13 --> URI Class Initialized
INFO - 2025-09-06 09:47:13 --> Router Class Initialized
INFO - 2025-09-06 09:47:13 --> Output Class Initialized
INFO - 2025-09-06 09:47:13 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:13 --> Input Class Initialized
INFO - 2025-09-06 09:47:13 --> Language Class Initialized
INFO - 2025-09-06 09:47:13 --> Loader Class Initialized
INFO - 2025-09-06 09:47:13 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:13 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:13 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:13 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:13 --> Controller Class Initialized
INFO - 2025-09-06 09:47:13 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:13 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:13 --> Total execution time: 0.0492
INFO - 2025-09-06 09:47:15 --> Config Class Initialized
INFO - 2025-09-06 09:47:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:15 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:15 --> URI Class Initialized
INFO - 2025-09-06 09:47:15 --> Router Class Initialized
INFO - 2025-09-06 09:47:15 --> Output Class Initialized
INFO - 2025-09-06 09:47:15 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:15 --> Input Class Initialized
INFO - 2025-09-06 09:47:15 --> Language Class Initialized
INFO - 2025-09-06 09:47:15 --> Loader Class Initialized
INFO - 2025-09-06 09:47:15 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:15 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:15 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:15 --> Controller Class Initialized
INFO - 2025-09-06 09:47:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:47:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:47:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 09:47:15 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:15 --> Total execution time: 0.0636
INFO - 2025-09-06 09:47:15 --> Config Class Initialized
INFO - 2025-09-06 09:47:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:15 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:15 --> URI Class Initialized
INFO - 2025-09-06 09:47:15 --> Router Class Initialized
INFO - 2025-09-06 09:47:15 --> Output Class Initialized
INFO - 2025-09-06 09:47:15 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:15 --> Input Class Initialized
INFO - 2025-09-06 09:47:15 --> Language Class Initialized
INFO - 2025-09-06 09:47:15 --> Loader Class Initialized
INFO - 2025-09-06 09:47:15 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:15 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:15 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:15 --> Controller Class Initialized
INFO - 2025-09-06 09:47:15 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:15 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:15 --> Total execution time: 0.0634
INFO - 2025-09-06 09:47:17 --> Config Class Initialized
INFO - 2025-09-06 09:47:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:17 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:17 --> URI Class Initialized
INFO - 2025-09-06 09:47:17 --> Router Class Initialized
INFO - 2025-09-06 09:47:17 --> Output Class Initialized
INFO - 2025-09-06 09:47:17 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:17 --> Input Class Initialized
INFO - 2025-09-06 09:47:17 --> Language Class Initialized
INFO - 2025-09-06 09:47:17 --> Loader Class Initialized
INFO - 2025-09-06 09:47:17 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:17 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:17 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:17 --> Controller Class Initialized
INFO - 2025-09-06 09:47:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:47:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:47:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:47:18 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:18 --> Total execution time: 0.0575
INFO - 2025-09-06 09:47:18 --> Config Class Initialized
INFO - 2025-09-06 09:47:18 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:18 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:18 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:18 --> URI Class Initialized
INFO - 2025-09-06 09:47:18 --> Router Class Initialized
INFO - 2025-09-06 09:47:18 --> Output Class Initialized
INFO - 2025-09-06 09:47:18 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:18 --> Input Class Initialized
INFO - 2025-09-06 09:47:18 --> Language Class Initialized
INFO - 2025-09-06 09:47:18 --> Loader Class Initialized
INFO - 2025-09-06 09:47:18 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:18 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:18 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:18 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:18 --> Controller Class Initialized
INFO - 2025-09-06 09:47:18 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:18 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:18 --> Total execution time: 0.0557
INFO - 2025-09-06 09:47:18 --> Config Class Initialized
INFO - 2025-09-06 09:47:18 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:18 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:18 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:18 --> URI Class Initialized
INFO - 2025-09-06 09:47:18 --> Router Class Initialized
INFO - 2025-09-06 09:47:18 --> Output Class Initialized
INFO - 2025-09-06 09:47:18 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:18 --> Input Class Initialized
INFO - 2025-09-06 09:47:18 --> Language Class Initialized
INFO - 2025-09-06 09:47:18 --> Loader Class Initialized
INFO - 2025-09-06 09:47:18 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:18 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:18 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:18 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:18 --> Controller Class Initialized
INFO - 2025-09-06 09:47:18 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:18 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:18 --> Total execution time: 0.0544
INFO - 2025-09-06 09:47:20 --> Config Class Initialized
INFO - 2025-09-06 09:47:20 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:20 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:20 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:20 --> URI Class Initialized
INFO - 2025-09-06 09:47:20 --> Router Class Initialized
INFO - 2025-09-06 09:47:20 --> Output Class Initialized
INFO - 2025-09-06 09:47:20 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:20 --> Input Class Initialized
INFO - 2025-09-06 09:47:20 --> Language Class Initialized
INFO - 2025-09-06 09:47:20 --> Loader Class Initialized
INFO - 2025-09-06 09:47:20 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:20 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:20 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:20 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:20 --> Controller Class Initialized
INFO - 2025-09-06 09:47:20 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:20 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:20 --> Total execution time: 0.0564
INFO - 2025-09-06 09:47:32 --> Config Class Initialized
INFO - 2025-09-06 09:47:32 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:32 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:32 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:32 --> URI Class Initialized
INFO - 2025-09-06 09:47:32 --> Router Class Initialized
INFO - 2025-09-06 09:47:32 --> Output Class Initialized
INFO - 2025-09-06 09:47:32 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:32 --> Input Class Initialized
INFO - 2025-09-06 09:47:32 --> Language Class Initialized
INFO - 2025-09-06 09:47:32 --> Loader Class Initialized
INFO - 2025-09-06 09:47:32 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:32 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:32 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:32 --> Controller Class Initialized
INFO - 2025-09-06 09:47:32 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:47:32 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:47:32 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 09:47:32 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:32 --> Total execution time: 0.0661
INFO - 2025-09-06 09:47:32 --> Config Class Initialized
INFO - 2025-09-06 09:47:32 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:32 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:32 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:32 --> URI Class Initialized
INFO - 2025-09-06 09:47:32 --> Router Class Initialized
INFO - 2025-09-06 09:47:32 --> Output Class Initialized
INFO - 2025-09-06 09:47:32 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:32 --> Input Class Initialized
INFO - 2025-09-06 09:47:32 --> Language Class Initialized
INFO - 2025-09-06 09:47:32 --> Loader Class Initialized
INFO - 2025-09-06 09:47:32 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:32 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:32 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:32 --> Controller Class Initialized
INFO - 2025-09-06 09:47:32 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:32 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:32 --> Total execution time: 0.0594
INFO - 2025-09-06 09:47:48 --> Config Class Initialized
INFO - 2025-09-06 09:47:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:48 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:48 --> URI Class Initialized
INFO - 2025-09-06 09:47:48 --> Router Class Initialized
INFO - 2025-09-06 09:47:48 --> Output Class Initialized
INFO - 2025-09-06 09:47:48 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:48 --> Input Class Initialized
INFO - 2025-09-06 09:47:48 --> Language Class Initialized
INFO - 2025-09-06 09:47:48 --> Loader Class Initialized
INFO - 2025-09-06 09:47:48 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:48 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:48 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:48 --> Controller Class Initialized
INFO - 2025-09-06 09:47:48 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 09:47:48 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 09:47:48 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 09:47:48 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:48 --> Total execution time: 0.1020
INFO - 2025-09-06 09:47:48 --> Config Class Initialized
INFO - 2025-09-06 09:47:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:48 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:48 --> URI Class Initialized
INFO - 2025-09-06 09:47:48 --> Router Class Initialized
INFO - 2025-09-06 09:47:48 --> Output Class Initialized
INFO - 2025-09-06 09:47:48 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:48 --> Input Class Initialized
INFO - 2025-09-06 09:47:48 --> Language Class Initialized
INFO - 2025-09-06 09:47:48 --> Loader Class Initialized
INFO - 2025-09-06 09:47:48 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:48 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:48 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:48 --> Controller Class Initialized
INFO - 2025-09-06 09:47:48 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:48 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:48 --> Total execution time: 0.0868
INFO - 2025-09-06 09:47:48 --> Config Class Initialized
INFO - 2025-09-06 09:47:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:47:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:47:48 --> Utf8 Class Initialized
INFO - 2025-09-06 09:47:48 --> URI Class Initialized
INFO - 2025-09-06 09:47:48 --> Router Class Initialized
INFO - 2025-09-06 09:47:48 --> Output Class Initialized
INFO - 2025-09-06 09:47:48 --> Security Class Initialized
DEBUG - 2025-09-06 09:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:47:48 --> Input Class Initialized
INFO - 2025-09-06 09:47:48 --> Language Class Initialized
INFO - 2025-09-06 09:47:48 --> Loader Class Initialized
INFO - 2025-09-06 09:47:48 --> Helper loaded: url_helper
INFO - 2025-09-06 09:47:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:47:48 --> Helper loaded: form_helper
INFO - 2025-09-06 09:47:48 --> Form Validation Class Initialized
INFO - 2025-09-06 09:47:48 --> Controller Class Initialized
INFO - 2025-09-06 09:47:48 --> Model "Center_model" initialized
INFO - 2025-09-06 09:47:48 --> Final output sent to browser
DEBUG - 2025-09-06 09:47:48 --> Total execution time: 0.0761
INFO - 2025-09-06 09:48:00 --> Config Class Initialized
INFO - 2025-09-06 09:48:00 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:48:00 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:48:00 --> Utf8 Class Initialized
INFO - 2025-09-06 09:48:00 --> URI Class Initialized
INFO - 2025-09-06 09:48:00 --> Router Class Initialized
INFO - 2025-09-06 09:48:00 --> Output Class Initialized
INFO - 2025-09-06 09:48:00 --> Security Class Initialized
DEBUG - 2025-09-06 09:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:48:00 --> Input Class Initialized
INFO - 2025-09-06 09:48:00 --> Language Class Initialized
INFO - 2025-09-06 09:48:00 --> Loader Class Initialized
INFO - 2025-09-06 09:48:00 --> Helper loaded: url_helper
INFO - 2025-09-06 09:48:00 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:48:00 --> Helper loaded: form_helper
INFO - 2025-09-06 09:48:00 --> Form Validation Class Initialized
INFO - 2025-09-06 09:48:00 --> Controller Class Initialized
INFO - 2025-09-06 09:48:00 --> Model "Center_model" initialized
INFO - 2025-09-06 09:48:00 --> Final output sent to browser
DEBUG - 2025-09-06 09:48:00 --> Total execution time: 0.0593
INFO - 2025-09-06 09:48:05 --> Config Class Initialized
INFO - 2025-09-06 09:48:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:48:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:48:05 --> Utf8 Class Initialized
INFO - 2025-09-06 09:48:05 --> URI Class Initialized
INFO - 2025-09-06 09:48:05 --> Router Class Initialized
INFO - 2025-09-06 09:48:05 --> Output Class Initialized
INFO - 2025-09-06 09:48:05 --> Security Class Initialized
DEBUG - 2025-09-06 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:48:05 --> Input Class Initialized
INFO - 2025-09-06 09:48:05 --> Language Class Initialized
INFO - 2025-09-06 09:48:05 --> Loader Class Initialized
INFO - 2025-09-06 09:48:05 --> Helper loaded: url_helper
INFO - 2025-09-06 09:48:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:48:05 --> Helper loaded: form_helper
INFO - 2025-09-06 09:48:05 --> Form Validation Class Initialized
INFO - 2025-09-06 09:48:05 --> Controller Class Initialized
INFO - 2025-09-06 09:48:05 --> Model "Center_model" initialized
INFO - 2025-09-06 09:48:05 --> Final output sent to browser
DEBUG - 2025-09-06 09:48:05 --> Total execution time: 0.0579
INFO - 2025-09-06 09:48:11 --> Config Class Initialized
INFO - 2025-09-06 09:48:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:48:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:48:11 --> Utf8 Class Initialized
INFO - 2025-09-06 09:48:11 --> URI Class Initialized
INFO - 2025-09-06 09:48:11 --> Router Class Initialized
INFO - 2025-09-06 09:48:11 --> Output Class Initialized
INFO - 2025-09-06 09:48:11 --> Security Class Initialized
DEBUG - 2025-09-06 09:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:48:11 --> Input Class Initialized
INFO - 2025-09-06 09:48:11 --> Language Class Initialized
INFO - 2025-09-06 09:48:11 --> Loader Class Initialized
INFO - 2025-09-06 09:48:11 --> Helper loaded: url_helper
INFO - 2025-09-06 09:48:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:48:11 --> Helper loaded: form_helper
INFO - 2025-09-06 09:48:11 --> Form Validation Class Initialized
INFO - 2025-09-06 09:48:11 --> Controller Class Initialized
INFO - 2025-09-06 09:48:11 --> Model "Center_model" initialized
INFO - 2025-09-06 09:48:11 --> Final output sent to browser
DEBUG - 2025-09-06 09:48:11 --> Total execution time: 0.0537
INFO - 2025-09-06 09:48:22 --> Config Class Initialized
INFO - 2025-09-06 09:48:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:48:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:48:22 --> Utf8 Class Initialized
INFO - 2025-09-06 09:48:22 --> URI Class Initialized
INFO - 2025-09-06 09:48:22 --> Router Class Initialized
INFO - 2025-09-06 09:48:22 --> Output Class Initialized
INFO - 2025-09-06 09:48:22 --> Security Class Initialized
DEBUG - 2025-09-06 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:48:22 --> Input Class Initialized
INFO - 2025-09-06 09:48:22 --> Language Class Initialized
INFO - 2025-09-06 09:48:22 --> Loader Class Initialized
INFO - 2025-09-06 09:48:22 --> Helper loaded: url_helper
INFO - 2025-09-06 09:48:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:48:22 --> Helper loaded: form_helper
INFO - 2025-09-06 09:48:22 --> Form Validation Class Initialized
INFO - 2025-09-06 09:48:22 --> Controller Class Initialized
INFO - 2025-09-06 09:48:22 --> Model "Center_model" initialized
INFO - 2025-09-06 09:48:22 --> Final output sent to browser
DEBUG - 2025-09-06 09:48:22 --> Total execution time: 0.0538
INFO - 2025-09-06 09:48:33 --> Config Class Initialized
INFO - 2025-09-06 09:48:33 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:48:33 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:48:33 --> Utf8 Class Initialized
INFO - 2025-09-06 09:48:33 --> URI Class Initialized
INFO - 2025-09-06 09:48:33 --> Router Class Initialized
INFO - 2025-09-06 09:48:33 --> Output Class Initialized
INFO - 2025-09-06 09:48:33 --> Security Class Initialized
DEBUG - 2025-09-06 09:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:48:33 --> Input Class Initialized
INFO - 2025-09-06 09:48:33 --> Language Class Initialized
INFO - 2025-09-06 09:48:33 --> Loader Class Initialized
INFO - 2025-09-06 09:48:33 --> Helper loaded: url_helper
INFO - 2025-09-06 09:48:33 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:48:33 --> Helper loaded: form_helper
INFO - 2025-09-06 09:48:33 --> Form Validation Class Initialized
INFO - 2025-09-06 09:48:33 --> Controller Class Initialized
INFO - 2025-09-06 09:48:33 --> Model "Center_model" initialized
INFO - 2025-09-06 09:48:33 --> Final output sent to browser
DEBUG - 2025-09-06 09:48:33 --> Total execution time: 0.0563
INFO - 2025-09-06 09:49:35 --> Config Class Initialized
INFO - 2025-09-06 09:49:35 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:49:35 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:49:35 --> Utf8 Class Initialized
INFO - 2025-09-06 09:49:35 --> URI Class Initialized
INFO - 2025-09-06 09:49:35 --> Router Class Initialized
INFO - 2025-09-06 09:49:35 --> Output Class Initialized
INFO - 2025-09-06 09:49:35 --> Security Class Initialized
DEBUG - 2025-09-06 09:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:49:35 --> Input Class Initialized
INFO - 2025-09-06 09:49:35 --> Language Class Initialized
INFO - 2025-09-06 09:49:35 --> Loader Class Initialized
INFO - 2025-09-06 09:49:35 --> Helper loaded: url_helper
INFO - 2025-09-06 09:49:35 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:49:35 --> Helper loaded: form_helper
INFO - 2025-09-06 09:49:35 --> Form Validation Class Initialized
INFO - 2025-09-06 09:49:35 --> Controller Class Initialized
INFO - 2025-09-06 09:49:35 --> Model "Center_model" initialized
INFO - 2025-09-06 09:49:35 --> Final output sent to browser
DEBUG - 2025-09-06 09:49:35 --> Total execution time: 0.0544
INFO - 2025-09-06 09:50:09 --> Config Class Initialized
INFO - 2025-09-06 09:50:09 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:50:09 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:50:09 --> Utf8 Class Initialized
INFO - 2025-09-06 09:50:09 --> URI Class Initialized
INFO - 2025-09-06 09:50:09 --> Router Class Initialized
INFO - 2025-09-06 09:50:09 --> Output Class Initialized
INFO - 2025-09-06 09:50:09 --> Security Class Initialized
DEBUG - 2025-09-06 09:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:50:09 --> Input Class Initialized
INFO - 2025-09-06 09:50:09 --> Language Class Initialized
INFO - 2025-09-06 09:50:09 --> Loader Class Initialized
INFO - 2025-09-06 09:50:09 --> Helper loaded: url_helper
INFO - 2025-09-06 09:50:09 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:50:09 --> Helper loaded: form_helper
INFO - 2025-09-06 09:50:09 --> Form Validation Class Initialized
INFO - 2025-09-06 09:50:09 --> Controller Class Initialized
INFO - 2025-09-06 09:50:09 --> Model "Center_model" initialized
INFO - 2025-09-06 09:50:09 --> Final output sent to browser
DEBUG - 2025-09-06 09:50:09 --> Total execution time: 0.0568
INFO - 2025-09-06 09:52:43 --> Config Class Initialized
INFO - 2025-09-06 09:52:43 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:52:43 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:52:43 --> Utf8 Class Initialized
INFO - 2025-09-06 09:52:43 --> URI Class Initialized
INFO - 2025-09-06 09:52:43 --> Router Class Initialized
INFO - 2025-09-06 09:52:43 --> Output Class Initialized
INFO - 2025-09-06 09:52:43 --> Security Class Initialized
DEBUG - 2025-09-06 09:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:52:43 --> Input Class Initialized
INFO - 2025-09-06 09:52:43 --> Language Class Initialized
INFO - 2025-09-06 09:52:43 --> Loader Class Initialized
INFO - 2025-09-06 09:52:43 --> Helper loaded: url_helper
INFO - 2025-09-06 09:52:43 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:52:43 --> Helper loaded: form_helper
INFO - 2025-09-06 09:52:43 --> Form Validation Class Initialized
INFO - 2025-09-06 09:52:43 --> Controller Class Initialized
INFO - 2025-09-06 09:52:43 --> Model "Center_model" initialized
INFO - 2025-09-06 09:52:43 --> Final output sent to browser
DEBUG - 2025-09-06 09:52:43 --> Total execution time: 0.0540
INFO - 2025-09-06 09:52:54 --> Config Class Initialized
INFO - 2025-09-06 09:52:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 09:52:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 09:52:54 --> Utf8 Class Initialized
INFO - 2025-09-06 09:52:54 --> URI Class Initialized
INFO - 2025-09-06 09:52:54 --> Router Class Initialized
INFO - 2025-09-06 09:52:54 --> Output Class Initialized
INFO - 2025-09-06 09:52:54 --> Security Class Initialized
DEBUG - 2025-09-06 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 09:52:54 --> Input Class Initialized
INFO - 2025-09-06 09:52:54 --> Language Class Initialized
INFO - 2025-09-06 09:52:54 --> Loader Class Initialized
INFO - 2025-09-06 09:52:54 --> Helper loaded: url_helper
INFO - 2025-09-06 09:52:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 09:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 09:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 09:52:54 --> Helper loaded: form_helper
INFO - 2025-09-06 09:52:54 --> Form Validation Class Initialized
INFO - 2025-09-06 09:52:54 --> Controller Class Initialized
INFO - 2025-09-06 09:52:54 --> Model "Center_model" initialized
INFO - 2025-09-06 09:52:54 --> Final output sent to browser
DEBUG - 2025-09-06 09:52:54 --> Total execution time: 0.0522
INFO - 2025-09-06 10:02:42 --> Config Class Initialized
INFO - 2025-09-06 10:02:42 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:02:42 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:02:42 --> Utf8 Class Initialized
INFO - 2025-09-06 10:02:42 --> URI Class Initialized
INFO - 2025-09-06 10:02:42 --> Router Class Initialized
INFO - 2025-09-06 10:02:42 --> Output Class Initialized
INFO - 2025-09-06 10:02:42 --> Security Class Initialized
DEBUG - 2025-09-06 10:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:02:42 --> Input Class Initialized
INFO - 2025-09-06 10:02:42 --> Language Class Initialized
INFO - 2025-09-06 10:02:42 --> Loader Class Initialized
INFO - 2025-09-06 10:02:42 --> Helper loaded: url_helper
INFO - 2025-09-06 10:02:42 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:02:42 --> Helper loaded: form_helper
INFO - 2025-09-06 10:02:42 --> Form Validation Class Initialized
INFO - 2025-09-06 10:02:42 --> Controller Class Initialized
INFO - 2025-09-06 10:02:42 --> Model "Center_model" initialized
INFO - 2025-09-06 10:02:42 --> Final output sent to browser
DEBUG - 2025-09-06 10:02:42 --> Total execution time: 0.1085
INFO - 2025-09-06 10:02:50 --> Config Class Initialized
INFO - 2025-09-06 10:02:50 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:02:50 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:02:50 --> Utf8 Class Initialized
INFO - 2025-09-06 10:02:50 --> URI Class Initialized
INFO - 2025-09-06 10:02:50 --> Router Class Initialized
INFO - 2025-09-06 10:02:50 --> Output Class Initialized
INFO - 2025-09-06 10:02:50 --> Security Class Initialized
DEBUG - 2025-09-06 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:02:50 --> Input Class Initialized
INFO - 2025-09-06 10:02:50 --> Language Class Initialized
INFO - 2025-09-06 10:02:50 --> Loader Class Initialized
INFO - 2025-09-06 10:02:50 --> Helper loaded: url_helper
INFO - 2025-09-06 10:02:50 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:02:50 --> Helper loaded: form_helper
INFO - 2025-09-06 10:02:50 --> Form Validation Class Initialized
INFO - 2025-09-06 10:02:50 --> Controller Class Initialized
INFO - 2025-09-06 10:02:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:02:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:02:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:02:50 --> Final output sent to browser
DEBUG - 2025-09-06 10:02:50 --> Total execution time: 0.1281
INFO - 2025-09-06 10:02:50 --> Config Class Initialized
INFO - 2025-09-06 10:02:50 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:02:50 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:02:50 --> Utf8 Class Initialized
INFO - 2025-09-06 10:02:50 --> URI Class Initialized
INFO - 2025-09-06 10:02:50 --> Router Class Initialized
INFO - 2025-09-06 10:02:50 --> Output Class Initialized
INFO - 2025-09-06 10:02:50 --> Security Class Initialized
DEBUG - 2025-09-06 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:02:50 --> Input Class Initialized
INFO - 2025-09-06 10:02:50 --> Language Class Initialized
INFO - 2025-09-06 10:02:50 --> Loader Class Initialized
INFO - 2025-09-06 10:02:50 --> Helper loaded: url_helper
INFO - 2025-09-06 10:02:50 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:02:50 --> Helper loaded: form_helper
INFO - 2025-09-06 10:02:50 --> Form Validation Class Initialized
INFO - 2025-09-06 10:02:50 --> Controller Class Initialized
INFO - 2025-09-06 10:02:50 --> Model "Center_model" initialized
INFO - 2025-09-06 10:02:50 --> Final output sent to browser
DEBUG - 2025-09-06 10:02:50 --> Total execution time: 0.1387
INFO - 2025-09-06 10:02:53 --> Config Class Initialized
INFO - 2025-09-06 10:02:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:02:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:02:53 --> Utf8 Class Initialized
INFO - 2025-09-06 10:02:53 --> URI Class Initialized
INFO - 2025-09-06 10:02:53 --> Router Class Initialized
INFO - 2025-09-06 10:02:53 --> Output Class Initialized
INFO - 2025-09-06 10:02:53 --> Security Class Initialized
DEBUG - 2025-09-06 10:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:02:53 --> Input Class Initialized
INFO - 2025-09-06 10:02:53 --> Language Class Initialized
INFO - 2025-09-06 10:02:53 --> Loader Class Initialized
INFO - 2025-09-06 10:02:53 --> Helper loaded: url_helper
INFO - 2025-09-06 10:02:53 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:02:53 --> Helper loaded: form_helper
INFO - 2025-09-06 10:02:53 --> Form Validation Class Initialized
INFO - 2025-09-06 10:02:53 --> Controller Class Initialized
INFO - 2025-09-06 10:02:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:02:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:02:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 10:02:53 --> Final output sent to browser
DEBUG - 2025-09-06 10:02:53 --> Total execution time: 0.1406
INFO - 2025-09-06 10:02:54 --> Config Class Initialized
INFO - 2025-09-06 10:02:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:02:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:02:54 --> Utf8 Class Initialized
INFO - 2025-09-06 10:02:54 --> URI Class Initialized
INFO - 2025-09-06 10:02:54 --> Router Class Initialized
INFO - 2025-09-06 10:02:54 --> Output Class Initialized
INFO - 2025-09-06 10:02:54 --> Security Class Initialized
DEBUG - 2025-09-06 10:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:02:54 --> Input Class Initialized
INFO - 2025-09-06 10:02:54 --> Language Class Initialized
INFO - 2025-09-06 10:02:54 --> Loader Class Initialized
INFO - 2025-09-06 10:02:54 --> Helper loaded: url_helper
INFO - 2025-09-06 10:02:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:02:54 --> Helper loaded: form_helper
INFO - 2025-09-06 10:02:54 --> Form Validation Class Initialized
INFO - 2025-09-06 10:02:54 --> Controller Class Initialized
INFO - 2025-09-06 10:02:54 --> Model "Center_model" initialized
INFO - 2025-09-06 10:02:54 --> Final output sent to browser
DEBUG - 2025-09-06 10:02:54 --> Total execution time: 0.1178
INFO - 2025-09-06 10:03:38 --> Config Class Initialized
INFO - 2025-09-06 10:03:38 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:03:38 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:03:38 --> Utf8 Class Initialized
INFO - 2025-09-06 10:03:38 --> URI Class Initialized
INFO - 2025-09-06 10:03:38 --> Router Class Initialized
INFO - 2025-09-06 10:03:38 --> Output Class Initialized
INFO - 2025-09-06 10:03:38 --> Security Class Initialized
DEBUG - 2025-09-06 10:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:03:38 --> Input Class Initialized
INFO - 2025-09-06 10:03:38 --> Language Class Initialized
INFO - 2025-09-06 10:03:38 --> Loader Class Initialized
INFO - 2025-09-06 10:03:38 --> Helper loaded: url_helper
INFO - 2025-09-06 10:03:38 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:03:38 --> Helper loaded: form_helper
INFO - 2025-09-06 10:03:38 --> Form Validation Class Initialized
INFO - 2025-09-06 10:03:38 --> Controller Class Initialized
INFO - 2025-09-06 10:03:38 --> Model "Center_model" initialized
INFO - 2025-09-06 10:03:38 --> Final output sent to browser
DEBUG - 2025-09-06 10:03:38 --> Total execution time: 0.2310
INFO - 2025-09-06 10:04:23 --> Config Class Initialized
INFO - 2025-09-06 10:04:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:23 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:23 --> URI Class Initialized
INFO - 2025-09-06 10:04:23 --> Router Class Initialized
INFO - 2025-09-06 10:04:23 --> Output Class Initialized
INFO - 2025-09-06 10:04:23 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:23 --> Input Class Initialized
INFO - 2025-09-06 10:04:23 --> Language Class Initialized
INFO - 2025-09-06 10:04:23 --> Loader Class Initialized
INFO - 2025-09-06 10:04:23 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:23 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:23 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:23 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:23 --> Controller Class Initialized
INFO - 2025-09-06 10:04:23 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:04:23 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:04:23 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:04:23 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:23 --> Total execution time: 0.1162
INFO - 2025-09-06 10:04:23 --> Config Class Initialized
INFO - 2025-09-06 10:04:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:23 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:23 --> URI Class Initialized
INFO - 2025-09-06 10:04:23 --> Router Class Initialized
INFO - 2025-09-06 10:04:23 --> Output Class Initialized
INFO - 2025-09-06 10:04:23 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:23 --> Input Class Initialized
INFO - 2025-09-06 10:04:23 --> Language Class Initialized
INFO - 2025-09-06 10:04:23 --> Loader Class Initialized
INFO - 2025-09-06 10:04:23 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:23 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:23 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:23 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:23 --> Controller Class Initialized
INFO - 2025-09-06 10:04:23 --> Model "Center_model" initialized
INFO - 2025-09-06 10:04:23 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:23 --> Total execution time: 0.1315
INFO - 2025-09-06 10:04:29 --> Config Class Initialized
INFO - 2025-09-06 10:04:29 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:29 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:29 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:29 --> URI Class Initialized
INFO - 2025-09-06 10:04:29 --> Router Class Initialized
INFO - 2025-09-06 10:04:29 --> Output Class Initialized
INFO - 2025-09-06 10:04:29 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:29 --> Input Class Initialized
INFO - 2025-09-06 10:04:29 --> Language Class Initialized
INFO - 2025-09-06 10:04:29 --> Loader Class Initialized
INFO - 2025-09-06 10:04:29 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:29 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:29 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:29 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:29 --> Controller Class Initialized
INFO - 2025-09-06 10:04:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:04:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:04:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:04:29 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:29 --> Total execution time: 0.1343
INFO - 2025-09-06 10:04:29 --> Config Class Initialized
INFO - 2025-09-06 10:04:29 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:29 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:29 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:29 --> URI Class Initialized
INFO - 2025-09-06 10:04:29 --> Router Class Initialized
INFO - 2025-09-06 10:04:29 --> Output Class Initialized
INFO - 2025-09-06 10:04:29 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:29 --> Input Class Initialized
INFO - 2025-09-06 10:04:29 --> Language Class Initialized
INFO - 2025-09-06 10:04:29 --> Loader Class Initialized
INFO - 2025-09-06 10:04:29 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:29 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:29 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:29 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:29 --> Controller Class Initialized
INFO - 2025-09-06 10:04:29 --> Model "Center_model" initialized
INFO - 2025-09-06 10:04:29 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:29 --> Total execution time: 0.1039
INFO - 2025-09-06 10:04:29 --> Config Class Initialized
INFO - 2025-09-06 10:04:29 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:29 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:29 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:29 --> URI Class Initialized
INFO - 2025-09-06 10:04:29 --> Router Class Initialized
INFO - 2025-09-06 10:04:30 --> Output Class Initialized
INFO - 2025-09-06 10:04:30 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:30 --> Input Class Initialized
INFO - 2025-09-06 10:04:30 --> Language Class Initialized
INFO - 2025-09-06 10:04:30 --> Loader Class Initialized
INFO - 2025-09-06 10:04:30 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:30 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:30 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:30 --> Controller Class Initialized
INFO - 2025-09-06 10:04:30 --> Model "Center_model" initialized
INFO - 2025-09-06 10:04:30 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:30 --> Total execution time: 0.0875
INFO - 2025-09-06 10:04:32 --> Config Class Initialized
INFO - 2025-09-06 10:04:32 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:32 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:32 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:32 --> URI Class Initialized
INFO - 2025-09-06 10:04:32 --> Router Class Initialized
INFO - 2025-09-06 10:04:32 --> Output Class Initialized
INFO - 2025-09-06 10:04:32 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:32 --> Input Class Initialized
INFO - 2025-09-06 10:04:32 --> Language Class Initialized
INFO - 2025-09-06 10:04:32 --> Loader Class Initialized
INFO - 2025-09-06 10:04:32 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:32 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:32 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:32 --> Controller Class Initialized
INFO - 2025-09-06 10:04:32 --> Model "Center_model" initialized
INFO - 2025-09-06 10:04:32 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:32 --> Total execution time: 0.1384
INFO - 2025-09-06 10:04:33 --> Config Class Initialized
INFO - 2025-09-06 10:04:33 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:33 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:33 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:33 --> URI Class Initialized
INFO - 2025-09-06 10:04:33 --> Router Class Initialized
INFO - 2025-09-06 10:04:33 --> Output Class Initialized
INFO - 2025-09-06 10:04:33 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:33 --> Input Class Initialized
INFO - 2025-09-06 10:04:33 --> Language Class Initialized
INFO - 2025-09-06 10:04:33 --> Loader Class Initialized
INFO - 2025-09-06 10:04:33 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:33 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:33 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:33 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:33 --> Controller Class Initialized
INFO - 2025-09-06 10:04:33 --> Model "Center_model" initialized
INFO - 2025-09-06 10:04:33 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:33 --> Total execution time: 0.1085
INFO - 2025-09-06 10:04:41 --> Config Class Initialized
INFO - 2025-09-06 10:04:41 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:41 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:41 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:41 --> URI Class Initialized
INFO - 2025-09-06 10:04:41 --> Router Class Initialized
INFO - 2025-09-06 10:04:41 --> Output Class Initialized
INFO - 2025-09-06 10:04:41 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:41 --> Input Class Initialized
INFO - 2025-09-06 10:04:41 --> Language Class Initialized
INFO - 2025-09-06 10:04:41 --> Loader Class Initialized
INFO - 2025-09-06 10:04:41 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:41 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:41 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:41 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:41 --> Controller Class Initialized
INFO - 2025-09-06 10:04:41 --> Model "Center_model" initialized
INFO - 2025-09-06 10:04:41 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:41 --> Total execution time: 0.1404
INFO - 2025-09-06 10:04:52 --> Config Class Initialized
INFO - 2025-09-06 10:04:52 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:52 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:52 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:52 --> URI Class Initialized
INFO - 2025-09-06 10:04:52 --> Router Class Initialized
INFO - 2025-09-06 10:04:52 --> Output Class Initialized
INFO - 2025-09-06 10:04:52 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:52 --> Input Class Initialized
INFO - 2025-09-06 10:04:52 --> Language Class Initialized
INFO - 2025-09-06 10:04:52 --> Loader Class Initialized
INFO - 2025-09-06 10:04:52 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:52 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:52 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:52 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:52 --> Controller Class Initialized
INFO - 2025-09-06 10:04:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:04:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:04:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:04:52 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:52 --> Total execution time: 0.1066
INFO - 2025-09-06 10:04:52 --> Config Class Initialized
INFO - 2025-09-06 10:04:52 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:52 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:52 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:52 --> URI Class Initialized
INFO - 2025-09-06 10:04:52 --> Router Class Initialized
INFO - 2025-09-06 10:04:52 --> Output Class Initialized
INFO - 2025-09-06 10:04:52 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:52 --> Input Class Initialized
INFO - 2025-09-06 10:04:52 --> Language Class Initialized
INFO - 2025-09-06 10:04:52 --> Loader Class Initialized
INFO - 2025-09-06 10:04:52 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:52 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:52 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:52 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:52 --> Controller Class Initialized
INFO - 2025-09-06 10:04:52 --> Model "Center_model" initialized
INFO - 2025-09-06 10:04:52 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:52 --> Total execution time: 0.1611
INFO - 2025-09-06 10:04:55 --> Config Class Initialized
INFO - 2025-09-06 10:04:55 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:55 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:55 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:55 --> URI Class Initialized
INFO - 2025-09-06 10:04:55 --> Router Class Initialized
INFO - 2025-09-06 10:04:55 --> Output Class Initialized
INFO - 2025-09-06 10:04:55 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:55 --> Input Class Initialized
INFO - 2025-09-06 10:04:55 --> Language Class Initialized
INFO - 2025-09-06 10:04:55 --> Loader Class Initialized
INFO - 2025-09-06 10:04:55 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:55 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:55 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:55 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:55 --> Controller Class Initialized
INFO - 2025-09-06 10:04:55 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:04:55 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:04:55 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 10:04:55 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:55 --> Total execution time: 0.1344
INFO - 2025-09-06 10:04:55 --> Config Class Initialized
INFO - 2025-09-06 10:04:55 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:04:55 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:04:55 --> Utf8 Class Initialized
INFO - 2025-09-06 10:04:55 --> URI Class Initialized
INFO - 2025-09-06 10:04:55 --> Router Class Initialized
INFO - 2025-09-06 10:04:55 --> Output Class Initialized
INFO - 2025-09-06 10:04:55 --> Security Class Initialized
DEBUG - 2025-09-06 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:04:55 --> Input Class Initialized
INFO - 2025-09-06 10:04:55 --> Language Class Initialized
INFO - 2025-09-06 10:04:55 --> Loader Class Initialized
INFO - 2025-09-06 10:04:55 --> Helper loaded: url_helper
INFO - 2025-09-06 10:04:55 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:04:55 --> Helper loaded: form_helper
INFO - 2025-09-06 10:04:55 --> Form Validation Class Initialized
INFO - 2025-09-06 10:04:55 --> Controller Class Initialized
INFO - 2025-09-06 10:04:55 --> Model "Center_model" initialized
INFO - 2025-09-06 10:04:55 --> Final output sent to browser
DEBUG - 2025-09-06 10:04:55 --> Total execution time: 0.1115
INFO - 2025-09-06 10:06:34 --> Config Class Initialized
INFO - 2025-09-06 10:06:34 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:06:34 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:06:34 --> Utf8 Class Initialized
INFO - 2025-09-06 10:06:34 --> URI Class Initialized
INFO - 2025-09-06 10:06:34 --> Router Class Initialized
INFO - 2025-09-06 10:06:34 --> Output Class Initialized
INFO - 2025-09-06 10:06:34 --> Security Class Initialized
DEBUG - 2025-09-06 10:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:06:34 --> Input Class Initialized
INFO - 2025-09-06 10:06:34 --> Language Class Initialized
INFO - 2025-09-06 10:06:34 --> Loader Class Initialized
INFO - 2025-09-06 10:06:34 --> Helper loaded: url_helper
INFO - 2025-09-06 10:06:34 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:06:34 --> Helper loaded: form_helper
INFO - 2025-09-06 10:06:34 --> Form Validation Class Initialized
INFO - 2025-09-06 10:06:34 --> Controller Class Initialized
INFO - 2025-09-06 10:06:34 --> Model "Center_model" initialized
INFO - 2025-09-06 10:06:34 --> Final output sent to browser
DEBUG - 2025-09-06 10:06:34 --> Total execution time: 0.2081
INFO - 2025-09-06 10:06:46 --> Config Class Initialized
INFO - 2025-09-06 10:06:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:06:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:06:46 --> Utf8 Class Initialized
INFO - 2025-09-06 10:06:46 --> URI Class Initialized
INFO - 2025-09-06 10:06:46 --> Router Class Initialized
INFO - 2025-09-06 10:06:46 --> Output Class Initialized
INFO - 2025-09-06 10:06:46 --> Security Class Initialized
DEBUG - 2025-09-06 10:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:06:46 --> Input Class Initialized
INFO - 2025-09-06 10:06:46 --> Language Class Initialized
INFO - 2025-09-06 10:06:46 --> Loader Class Initialized
INFO - 2025-09-06 10:06:46 --> Helper loaded: url_helper
INFO - 2025-09-06 10:06:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:06:46 --> Helper loaded: form_helper
INFO - 2025-09-06 10:06:46 --> Form Validation Class Initialized
INFO - 2025-09-06 10:06:46 --> Controller Class Initialized
INFO - 2025-09-06 10:06:46 --> Model "Center_model" initialized
INFO - 2025-09-06 10:06:46 --> Final output sent to browser
DEBUG - 2025-09-06 10:06:46 --> Total execution time: 0.1449
INFO - 2025-09-06 10:07:25 --> Config Class Initialized
INFO - 2025-09-06 10:07:25 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:07:25 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:07:25 --> Utf8 Class Initialized
INFO - 2025-09-06 10:07:25 --> URI Class Initialized
INFO - 2025-09-06 10:07:25 --> Router Class Initialized
INFO - 2025-09-06 10:07:25 --> Output Class Initialized
INFO - 2025-09-06 10:07:25 --> Security Class Initialized
DEBUG - 2025-09-06 10:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:07:25 --> Input Class Initialized
INFO - 2025-09-06 10:07:25 --> Language Class Initialized
INFO - 2025-09-06 10:07:25 --> Loader Class Initialized
INFO - 2025-09-06 10:07:25 --> Helper loaded: url_helper
INFO - 2025-09-06 10:07:25 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:07:25 --> Helper loaded: form_helper
INFO - 2025-09-06 10:07:25 --> Form Validation Class Initialized
INFO - 2025-09-06 10:07:25 --> Controller Class Initialized
INFO - 2025-09-06 10:07:25 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:07:25 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:07:25 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:07:25 --> Final output sent to browser
DEBUG - 2025-09-06 10:07:25 --> Total execution time: 0.1308
INFO - 2025-09-06 10:07:26 --> Config Class Initialized
INFO - 2025-09-06 10:07:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:07:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:07:26 --> Utf8 Class Initialized
INFO - 2025-09-06 10:07:26 --> URI Class Initialized
INFO - 2025-09-06 10:07:26 --> Router Class Initialized
INFO - 2025-09-06 10:07:26 --> Output Class Initialized
INFO - 2025-09-06 10:07:26 --> Security Class Initialized
DEBUG - 2025-09-06 10:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:07:26 --> Input Class Initialized
INFO - 2025-09-06 10:07:26 --> Language Class Initialized
INFO - 2025-09-06 10:07:26 --> Loader Class Initialized
INFO - 2025-09-06 10:07:26 --> Helper loaded: url_helper
INFO - 2025-09-06 10:07:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:07:26 --> Helper loaded: form_helper
INFO - 2025-09-06 10:07:26 --> Form Validation Class Initialized
INFO - 2025-09-06 10:07:26 --> Controller Class Initialized
INFO - 2025-09-06 10:07:26 --> Model "Center_model" initialized
INFO - 2025-09-06 10:07:26 --> Final output sent to browser
DEBUG - 2025-09-06 10:07:26 --> Total execution time: 0.1466
INFO - 2025-09-06 10:08:47 --> Config Class Initialized
INFO - 2025-09-06 10:08:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:47 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:47 --> URI Class Initialized
INFO - 2025-09-06 10:08:47 --> Router Class Initialized
INFO - 2025-09-06 10:08:47 --> Output Class Initialized
INFO - 2025-09-06 10:08:47 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:47 --> Input Class Initialized
INFO - 2025-09-06 10:08:47 --> Language Class Initialized
INFO - 2025-09-06 10:08:47 --> Loader Class Initialized
INFO - 2025-09-06 10:08:47 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:47 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:47 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:47 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:47 --> Controller Class Initialized
INFO - 2025-09-06 10:08:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:08:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:08:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:08:47 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:47 --> Total execution time: 0.1422
INFO - 2025-09-06 10:08:48 --> Config Class Initialized
INFO - 2025-09-06 10:08:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:48 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:48 --> URI Class Initialized
INFO - 2025-09-06 10:08:48 --> Router Class Initialized
INFO - 2025-09-06 10:08:48 --> Output Class Initialized
INFO - 2025-09-06 10:08:48 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:48 --> Input Class Initialized
INFO - 2025-09-06 10:08:48 --> Language Class Initialized
INFO - 2025-09-06 10:08:48 --> Loader Class Initialized
INFO - 2025-09-06 10:08:48 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:48 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:48 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:48 --> Controller Class Initialized
INFO - 2025-09-06 10:08:48 --> Model "Center_model" initialized
INFO - 2025-09-06 10:08:48 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:48 --> Total execution time: 0.1139
INFO - 2025-09-06 10:08:48 --> Config Class Initialized
INFO - 2025-09-06 10:08:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:48 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:48 --> URI Class Initialized
INFO - 2025-09-06 10:08:48 --> Router Class Initialized
INFO - 2025-09-06 10:08:48 --> Output Class Initialized
INFO - 2025-09-06 10:08:48 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:48 --> Input Class Initialized
INFO - 2025-09-06 10:08:48 --> Language Class Initialized
INFO - 2025-09-06 10:08:48 --> Loader Class Initialized
INFO - 2025-09-06 10:08:48 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:48 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:48 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:48 --> Controller Class Initialized
INFO - 2025-09-06 10:08:48 --> Model "Center_model" initialized
INFO - 2025-09-06 10:08:48 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:48 --> Total execution time: 0.0858
INFO - 2025-09-06 10:08:51 --> Config Class Initialized
INFO - 2025-09-06 10:08:51 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:51 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:51 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:51 --> URI Class Initialized
INFO - 2025-09-06 10:08:51 --> Router Class Initialized
INFO - 2025-09-06 10:08:51 --> Output Class Initialized
INFO - 2025-09-06 10:08:51 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:51 --> Input Class Initialized
INFO - 2025-09-06 10:08:51 --> Language Class Initialized
INFO - 2025-09-06 10:08:51 --> Loader Class Initialized
INFO - 2025-09-06 10:08:51 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:51 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:51 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:51 --> Controller Class Initialized
INFO - 2025-09-06 10:08:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:08:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:08:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:08:51 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:51 --> Total execution time: 0.1036
INFO - 2025-09-06 10:08:51 --> Config Class Initialized
INFO - 2025-09-06 10:08:51 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:51 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:51 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:51 --> URI Class Initialized
INFO - 2025-09-06 10:08:51 --> Router Class Initialized
INFO - 2025-09-06 10:08:51 --> Output Class Initialized
INFO - 2025-09-06 10:08:51 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:51 --> Input Class Initialized
INFO - 2025-09-06 10:08:51 --> Language Class Initialized
INFO - 2025-09-06 10:08:51 --> Loader Class Initialized
INFO - 2025-09-06 10:08:51 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:51 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:51 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:51 --> Controller Class Initialized
INFO - 2025-09-06 10:08:51 --> Model "Center_model" initialized
INFO - 2025-09-06 10:08:51 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:51 --> Total execution time: 0.1322
INFO - 2025-09-06 10:08:53 --> Config Class Initialized
INFO - 2025-09-06 10:08:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:53 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:53 --> URI Class Initialized
INFO - 2025-09-06 10:08:53 --> Router Class Initialized
INFO - 2025-09-06 10:08:53 --> Output Class Initialized
INFO - 2025-09-06 10:08:53 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:53 --> Input Class Initialized
INFO - 2025-09-06 10:08:53 --> Language Class Initialized
INFO - 2025-09-06 10:08:53 --> Loader Class Initialized
INFO - 2025-09-06 10:08:53 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:54 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:54 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:54 --> Controller Class Initialized
INFO - 2025-09-06 10:08:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:08:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:08:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:08:54 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:54 --> Total execution time: 0.1258
INFO - 2025-09-06 10:08:54 --> Config Class Initialized
INFO - 2025-09-06 10:08:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:54 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:54 --> URI Class Initialized
INFO - 2025-09-06 10:08:54 --> Router Class Initialized
INFO - 2025-09-06 10:08:54 --> Output Class Initialized
INFO - 2025-09-06 10:08:54 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:54 --> Input Class Initialized
INFO - 2025-09-06 10:08:54 --> Language Class Initialized
INFO - 2025-09-06 10:08:54 --> Loader Class Initialized
INFO - 2025-09-06 10:08:54 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:54 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:54 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:54 --> Controller Class Initialized
INFO - 2025-09-06 10:08:54 --> Model "Center_model" initialized
INFO - 2025-09-06 10:08:54 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:54 --> Total execution time: 0.0983
INFO - 2025-09-06 10:08:54 --> Config Class Initialized
INFO - 2025-09-06 10:08:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:54 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:54 --> URI Class Initialized
INFO - 2025-09-06 10:08:54 --> Router Class Initialized
INFO - 2025-09-06 10:08:54 --> Output Class Initialized
INFO - 2025-09-06 10:08:54 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:54 --> Input Class Initialized
INFO - 2025-09-06 10:08:54 --> Language Class Initialized
INFO - 2025-09-06 10:08:54 --> Loader Class Initialized
INFO - 2025-09-06 10:08:54 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:54 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:54 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:54 --> Controller Class Initialized
INFO - 2025-09-06 10:08:54 --> Model "Center_model" initialized
INFO - 2025-09-06 10:08:54 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:54 --> Total execution time: 0.0901
INFO - 2025-09-06 10:08:59 --> Config Class Initialized
INFO - 2025-09-06 10:08:59 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:08:59 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:08:59 --> Utf8 Class Initialized
INFO - 2025-09-06 10:08:59 --> URI Class Initialized
INFO - 2025-09-06 10:08:59 --> Router Class Initialized
INFO - 2025-09-06 10:08:59 --> Output Class Initialized
INFO - 2025-09-06 10:08:59 --> Security Class Initialized
DEBUG - 2025-09-06 10:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:08:59 --> Input Class Initialized
INFO - 2025-09-06 10:08:59 --> Language Class Initialized
INFO - 2025-09-06 10:08:59 --> Loader Class Initialized
INFO - 2025-09-06 10:08:59 --> Helper loaded: url_helper
INFO - 2025-09-06 10:08:59 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:08:59 --> Helper loaded: form_helper
INFO - 2025-09-06 10:08:59 --> Form Validation Class Initialized
INFO - 2025-09-06 10:08:59 --> Controller Class Initialized
INFO - 2025-09-06 10:08:59 --> Model "Center_model" initialized
INFO - 2025-09-06 10:08:59 --> Final output sent to browser
DEBUG - 2025-09-06 10:08:59 --> Total execution time: 0.1492
INFO - 2025-09-06 10:09:07 --> Config Class Initialized
INFO - 2025-09-06 10:09:07 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:09:07 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:09:07 --> Utf8 Class Initialized
INFO - 2025-09-06 10:09:07 --> URI Class Initialized
INFO - 2025-09-06 10:09:07 --> Router Class Initialized
INFO - 2025-09-06 10:09:07 --> Output Class Initialized
INFO - 2025-09-06 10:09:07 --> Security Class Initialized
DEBUG - 2025-09-06 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:09:07 --> Input Class Initialized
INFO - 2025-09-06 10:09:07 --> Language Class Initialized
INFO - 2025-09-06 10:09:07 --> Loader Class Initialized
INFO - 2025-09-06 10:09:07 --> Helper loaded: url_helper
INFO - 2025-09-06 10:09:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:09:07 --> Helper loaded: form_helper
INFO - 2025-09-06 10:09:07 --> Form Validation Class Initialized
INFO - 2025-09-06 10:09:07 --> Controller Class Initialized
INFO - 2025-09-06 10:09:07 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:09:07 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:09:07 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:09:07 --> Final output sent to browser
DEBUG - 2025-09-06 10:09:07 --> Total execution time: 0.1058
INFO - 2025-09-06 10:09:07 --> Config Class Initialized
INFO - 2025-09-06 10:09:07 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:09:07 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:09:07 --> Utf8 Class Initialized
INFO - 2025-09-06 10:09:07 --> URI Class Initialized
INFO - 2025-09-06 10:09:07 --> Router Class Initialized
INFO - 2025-09-06 10:09:07 --> Output Class Initialized
INFO - 2025-09-06 10:09:07 --> Security Class Initialized
DEBUG - 2025-09-06 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:09:07 --> Input Class Initialized
INFO - 2025-09-06 10:09:07 --> Language Class Initialized
INFO - 2025-09-06 10:09:07 --> Loader Class Initialized
INFO - 2025-09-06 10:09:07 --> Helper loaded: url_helper
INFO - 2025-09-06 10:09:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:09:07 --> Helper loaded: form_helper
INFO - 2025-09-06 10:09:07 --> Form Validation Class Initialized
INFO - 2025-09-06 10:09:07 --> Controller Class Initialized
INFO - 2025-09-06 10:09:07 --> Model "Center_model" initialized
INFO - 2025-09-06 10:09:07 --> Final output sent to browser
DEBUG - 2025-09-06 10:09:07 --> Total execution time: 0.1235
INFO - 2025-09-06 10:09:11 --> Config Class Initialized
INFO - 2025-09-06 10:09:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:09:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:09:11 --> Utf8 Class Initialized
INFO - 2025-09-06 10:09:11 --> URI Class Initialized
INFO - 2025-09-06 10:09:11 --> Router Class Initialized
INFO - 2025-09-06 10:09:11 --> Output Class Initialized
INFO - 2025-09-06 10:09:11 --> Security Class Initialized
DEBUG - 2025-09-06 10:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:09:11 --> Input Class Initialized
INFO - 2025-09-06 10:09:11 --> Language Class Initialized
INFO - 2025-09-06 10:09:11 --> Loader Class Initialized
INFO - 2025-09-06 10:09:11 --> Helper loaded: url_helper
INFO - 2025-09-06 10:09:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:09:11 --> Helper loaded: form_helper
INFO - 2025-09-06 10:09:11 --> Form Validation Class Initialized
INFO - 2025-09-06 10:09:11 --> Controller Class Initialized
INFO - 2025-09-06 10:09:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:09:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:09:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:09:11 --> Final output sent to browser
DEBUG - 2025-09-06 10:09:11 --> Total execution time: 0.1262
INFO - 2025-09-06 10:09:11 --> Config Class Initialized
INFO - 2025-09-06 10:09:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:09:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:09:11 --> Utf8 Class Initialized
INFO - 2025-09-06 10:09:11 --> URI Class Initialized
INFO - 2025-09-06 10:09:11 --> Router Class Initialized
INFO - 2025-09-06 10:09:11 --> Output Class Initialized
INFO - 2025-09-06 10:09:11 --> Security Class Initialized
DEBUG - 2025-09-06 10:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:09:11 --> Input Class Initialized
INFO - 2025-09-06 10:09:11 --> Language Class Initialized
INFO - 2025-09-06 10:09:11 --> Loader Class Initialized
INFO - 2025-09-06 10:09:11 --> Helper loaded: url_helper
INFO - 2025-09-06 10:09:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:09:11 --> Helper loaded: form_helper
INFO - 2025-09-06 10:09:11 --> Form Validation Class Initialized
INFO - 2025-09-06 10:09:11 --> Controller Class Initialized
INFO - 2025-09-06 10:09:11 --> Model "Center_model" initialized
INFO - 2025-09-06 10:09:11 --> Final output sent to browser
DEBUG - 2025-09-06 10:09:11 --> Total execution time: 0.1093
INFO - 2025-09-06 10:09:11 --> Config Class Initialized
INFO - 2025-09-06 10:09:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:09:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:09:11 --> Utf8 Class Initialized
INFO - 2025-09-06 10:09:11 --> URI Class Initialized
INFO - 2025-09-06 10:09:11 --> Router Class Initialized
INFO - 2025-09-06 10:09:11 --> Output Class Initialized
INFO - 2025-09-06 10:09:11 --> Security Class Initialized
DEBUG - 2025-09-06 10:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:09:11 --> Input Class Initialized
INFO - 2025-09-06 10:09:11 --> Language Class Initialized
INFO - 2025-09-06 10:09:11 --> Loader Class Initialized
INFO - 2025-09-06 10:09:11 --> Helper loaded: url_helper
INFO - 2025-09-06 10:09:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:09:11 --> Helper loaded: form_helper
INFO - 2025-09-06 10:09:11 --> Form Validation Class Initialized
INFO - 2025-09-06 10:09:11 --> Controller Class Initialized
INFO - 2025-09-06 10:09:11 --> Model "Center_model" initialized
INFO - 2025-09-06 10:09:11 --> Final output sent to browser
DEBUG - 2025-09-06 10:09:11 --> Total execution time: 0.0895
INFO - 2025-09-06 10:09:14 --> Config Class Initialized
INFO - 2025-09-06 10:09:14 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:09:14 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:09:14 --> Utf8 Class Initialized
INFO - 2025-09-06 10:09:14 --> URI Class Initialized
INFO - 2025-09-06 10:09:14 --> Router Class Initialized
INFO - 2025-09-06 10:09:14 --> Output Class Initialized
INFO - 2025-09-06 10:09:14 --> Security Class Initialized
DEBUG - 2025-09-06 10:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:09:14 --> Input Class Initialized
INFO - 2025-09-06 10:09:14 --> Language Class Initialized
INFO - 2025-09-06 10:09:14 --> Loader Class Initialized
INFO - 2025-09-06 10:09:14 --> Helper loaded: url_helper
INFO - 2025-09-06 10:09:14 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:09:14 --> Helper loaded: form_helper
INFO - 2025-09-06 10:09:14 --> Form Validation Class Initialized
INFO - 2025-09-06 10:09:14 --> Controller Class Initialized
INFO - 2025-09-06 10:09:14 --> Model "Center_model" initialized
INFO - 2025-09-06 10:09:14 --> Final output sent to browser
DEBUG - 2025-09-06 10:09:14 --> Total execution time: 0.1201
INFO - 2025-09-06 10:09:15 --> Config Class Initialized
INFO - 2025-09-06 10:09:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:09:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:09:15 --> Utf8 Class Initialized
INFO - 2025-09-06 10:09:15 --> URI Class Initialized
INFO - 2025-09-06 10:09:15 --> Router Class Initialized
INFO - 2025-09-06 10:09:15 --> Output Class Initialized
INFO - 2025-09-06 10:09:15 --> Security Class Initialized
DEBUG - 2025-09-06 10:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:09:15 --> Input Class Initialized
INFO - 2025-09-06 10:09:15 --> Language Class Initialized
INFO - 2025-09-06 10:09:15 --> Loader Class Initialized
INFO - 2025-09-06 10:09:15 --> Helper loaded: url_helper
INFO - 2025-09-06 10:09:16 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:09:16 --> Helper loaded: form_helper
INFO - 2025-09-06 10:09:16 --> Form Validation Class Initialized
INFO - 2025-09-06 10:09:16 --> Controller Class Initialized
INFO - 2025-09-06 10:09:16 --> Model "Center_model" initialized
INFO - 2025-09-06 10:09:16 --> Final output sent to browser
DEBUG - 2025-09-06 10:09:16 --> Total execution time: 0.1166
INFO - 2025-09-06 10:10:15 --> Config Class Initialized
INFO - 2025-09-06 10:10:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:10:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:10:15 --> Utf8 Class Initialized
INFO - 2025-09-06 10:10:15 --> URI Class Initialized
INFO - 2025-09-06 10:10:15 --> Router Class Initialized
INFO - 2025-09-06 10:10:15 --> Output Class Initialized
INFO - 2025-09-06 10:10:15 --> Security Class Initialized
DEBUG - 2025-09-06 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:10:15 --> Input Class Initialized
INFO - 2025-09-06 10:10:15 --> Language Class Initialized
INFO - 2025-09-06 10:10:15 --> Loader Class Initialized
INFO - 2025-09-06 10:10:15 --> Helper loaded: url_helper
INFO - 2025-09-06 10:10:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:10:15 --> Helper loaded: form_helper
INFO - 2025-09-06 10:10:15 --> Form Validation Class Initialized
INFO - 2025-09-06 10:10:15 --> Controller Class Initialized
INFO - 2025-09-06 10:10:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:10:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:10:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:10:15 --> Final output sent to browser
DEBUG - 2025-09-06 10:10:15 --> Total execution time: 0.1329
INFO - 2025-09-06 10:10:15 --> Config Class Initialized
INFO - 2025-09-06 10:10:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:10:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:10:15 --> Utf8 Class Initialized
INFO - 2025-09-06 10:10:15 --> URI Class Initialized
INFO - 2025-09-06 10:10:15 --> Router Class Initialized
INFO - 2025-09-06 10:10:15 --> Output Class Initialized
INFO - 2025-09-06 10:10:15 --> Security Class Initialized
DEBUG - 2025-09-06 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:10:15 --> Input Class Initialized
INFO - 2025-09-06 10:10:15 --> Language Class Initialized
INFO - 2025-09-06 10:10:15 --> Loader Class Initialized
INFO - 2025-09-06 10:10:15 --> Helper loaded: url_helper
INFO - 2025-09-06 10:10:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:10:15 --> Helper loaded: form_helper
INFO - 2025-09-06 10:10:15 --> Form Validation Class Initialized
INFO - 2025-09-06 10:10:15 --> Controller Class Initialized
INFO - 2025-09-06 10:10:15 --> Model "Center_model" initialized
INFO - 2025-09-06 10:10:15 --> Final output sent to browser
DEBUG - 2025-09-06 10:10:15 --> Total execution time: 0.1260
INFO - 2025-09-06 10:10:27 --> Config Class Initialized
INFO - 2025-09-06 10:10:27 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:10:27 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:10:27 --> Utf8 Class Initialized
INFO - 2025-09-06 10:10:27 --> URI Class Initialized
INFO - 2025-09-06 10:10:27 --> Router Class Initialized
INFO - 2025-09-06 10:10:27 --> Output Class Initialized
INFO - 2025-09-06 10:10:27 --> Security Class Initialized
DEBUG - 2025-09-06 10:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:10:27 --> Input Class Initialized
INFO - 2025-09-06 10:10:27 --> Language Class Initialized
INFO - 2025-09-06 10:10:27 --> Loader Class Initialized
INFO - 2025-09-06 10:10:27 --> Helper loaded: url_helper
INFO - 2025-09-06 10:10:27 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:10:27 --> Helper loaded: form_helper
INFO - 2025-09-06 10:10:27 --> Form Validation Class Initialized
INFO - 2025-09-06 10:10:27 --> Controller Class Initialized
INFO - 2025-09-06 10:10:27 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:10:27 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:10:27 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:10:27 --> Final output sent to browser
DEBUG - 2025-09-06 10:10:27 --> Total execution time: 0.1359
INFO - 2025-09-06 10:10:27 --> Config Class Initialized
INFO - 2025-09-06 10:10:27 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:10:27 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:10:27 --> Utf8 Class Initialized
INFO - 2025-09-06 10:10:27 --> URI Class Initialized
INFO - 2025-09-06 10:10:27 --> Router Class Initialized
INFO - 2025-09-06 10:10:27 --> Output Class Initialized
INFO - 2025-09-06 10:10:27 --> Security Class Initialized
DEBUG - 2025-09-06 10:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:10:27 --> Input Class Initialized
INFO - 2025-09-06 10:10:27 --> Language Class Initialized
INFO - 2025-09-06 10:10:27 --> Loader Class Initialized
INFO - 2025-09-06 10:10:27 --> Helper loaded: url_helper
INFO - 2025-09-06 10:10:27 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:10:27 --> Helper loaded: form_helper
INFO - 2025-09-06 10:10:27 --> Form Validation Class Initialized
INFO - 2025-09-06 10:10:27 --> Controller Class Initialized
INFO - 2025-09-06 10:10:27 --> Model "Center_model" initialized
INFO - 2025-09-06 10:10:27 --> Final output sent to browser
DEBUG - 2025-09-06 10:10:27 --> Total execution time: 0.1116
INFO - 2025-09-06 10:10:27 --> Config Class Initialized
INFO - 2025-09-06 10:10:27 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:10:27 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:10:27 --> Utf8 Class Initialized
INFO - 2025-09-06 10:10:27 --> URI Class Initialized
INFO - 2025-09-06 10:10:27 --> Router Class Initialized
INFO - 2025-09-06 10:10:27 --> Output Class Initialized
INFO - 2025-09-06 10:10:27 --> Security Class Initialized
DEBUG - 2025-09-06 10:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:10:27 --> Input Class Initialized
INFO - 2025-09-06 10:10:27 --> Language Class Initialized
INFO - 2025-09-06 10:10:27 --> Loader Class Initialized
INFO - 2025-09-06 10:10:27 --> Helper loaded: url_helper
INFO - 2025-09-06 10:10:27 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:10:27 --> Helper loaded: form_helper
INFO - 2025-09-06 10:10:27 --> Form Validation Class Initialized
INFO - 2025-09-06 10:10:27 --> Controller Class Initialized
INFO - 2025-09-06 10:10:27 --> Model "Center_model" initialized
INFO - 2025-09-06 10:10:27 --> Final output sent to browser
DEBUG - 2025-09-06 10:10:27 --> Total execution time: 0.0938
INFO - 2025-09-06 10:10:30 --> Config Class Initialized
INFO - 2025-09-06 10:10:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:10:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:10:30 --> Utf8 Class Initialized
INFO - 2025-09-06 10:10:30 --> URI Class Initialized
INFO - 2025-09-06 10:10:30 --> Router Class Initialized
INFO - 2025-09-06 10:10:30 --> Output Class Initialized
INFO - 2025-09-06 10:10:30 --> Security Class Initialized
DEBUG - 2025-09-06 10:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:10:30 --> Input Class Initialized
INFO - 2025-09-06 10:10:30 --> Language Class Initialized
INFO - 2025-09-06 10:10:30 --> Loader Class Initialized
INFO - 2025-09-06 10:10:30 --> Helper loaded: url_helper
INFO - 2025-09-06 10:10:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:10:30 --> Helper loaded: form_helper
INFO - 2025-09-06 10:10:30 --> Form Validation Class Initialized
INFO - 2025-09-06 10:10:30 --> Controller Class Initialized
INFO - 2025-09-06 10:10:30 --> Model "Center_model" initialized
INFO - 2025-09-06 10:10:30 --> Final output sent to browser
DEBUG - 2025-09-06 10:10:30 --> Total execution time: 0.1138
INFO - 2025-09-06 10:11:11 --> Config Class Initialized
INFO - 2025-09-06 10:11:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:11:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:11:11 --> Utf8 Class Initialized
INFO - 2025-09-06 10:11:11 --> URI Class Initialized
INFO - 2025-09-06 10:11:11 --> Router Class Initialized
INFO - 2025-09-06 10:11:11 --> Output Class Initialized
INFO - 2025-09-06 10:11:11 --> Security Class Initialized
DEBUG - 2025-09-06 10:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:11:11 --> Input Class Initialized
INFO - 2025-09-06 10:11:11 --> Language Class Initialized
ERROR - 2025-09-06 10:11:11 --> 404 Page Not Found: Batch/addBatch
INFO - 2025-09-06 10:11:21 --> Config Class Initialized
INFO - 2025-09-06 10:11:21 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:11:21 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:11:21 --> Utf8 Class Initialized
INFO - 2025-09-06 10:11:21 --> URI Class Initialized
INFO - 2025-09-06 10:11:21 --> Router Class Initialized
INFO - 2025-09-06 10:11:21 --> Output Class Initialized
INFO - 2025-09-06 10:11:21 --> Security Class Initialized
DEBUG - 2025-09-06 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:11:21 --> Input Class Initialized
INFO - 2025-09-06 10:11:21 --> Language Class Initialized
ERROR - 2025-09-06 10:11:21 --> 404 Page Not Found: Batch/addBatch
INFO - 2025-09-06 10:12:03 --> Config Class Initialized
INFO - 2025-09-06 10:12:03 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:12:03 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:12:03 --> Utf8 Class Initialized
INFO - 2025-09-06 10:12:03 --> URI Class Initialized
INFO - 2025-09-06 10:12:03 --> Router Class Initialized
INFO - 2025-09-06 10:12:03 --> Output Class Initialized
INFO - 2025-09-06 10:12:03 --> Security Class Initialized
DEBUG - 2025-09-06 10:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:12:03 --> Input Class Initialized
INFO - 2025-09-06 10:12:03 --> Language Class Initialized
INFO - 2025-09-06 10:12:03 --> Loader Class Initialized
INFO - 2025-09-06 10:12:03 --> Helper loaded: url_helper
INFO - 2025-09-06 10:12:03 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:12:03 --> Helper loaded: form_helper
INFO - 2025-09-06 10:12:03 --> Form Validation Class Initialized
INFO - 2025-09-06 10:12:03 --> Controller Class Initialized
INFO - 2025-09-06 10:12:03 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:12:03 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:12:03 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:12:03 --> Final output sent to browser
DEBUG - 2025-09-06 10:12:03 --> Total execution time: 0.1116
INFO - 2025-09-06 10:12:03 --> Config Class Initialized
INFO - 2025-09-06 10:12:03 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:12:03 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:12:03 --> Utf8 Class Initialized
INFO - 2025-09-06 10:12:03 --> URI Class Initialized
INFO - 2025-09-06 10:12:03 --> Router Class Initialized
INFO - 2025-09-06 10:12:03 --> Output Class Initialized
INFO - 2025-09-06 10:12:03 --> Security Class Initialized
DEBUG - 2025-09-06 10:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:12:03 --> Input Class Initialized
INFO - 2025-09-06 10:12:03 --> Language Class Initialized
INFO - 2025-09-06 10:12:03 --> Loader Class Initialized
INFO - 2025-09-06 10:12:03 --> Helper loaded: url_helper
INFO - 2025-09-06 10:12:03 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:12:03 --> Helper loaded: form_helper
INFO - 2025-09-06 10:12:03 --> Form Validation Class Initialized
INFO - 2025-09-06 10:12:03 --> Controller Class Initialized
INFO - 2025-09-06 10:12:03 --> Model "Center_model" initialized
INFO - 2025-09-06 10:12:03 --> Final output sent to browser
DEBUG - 2025-09-06 10:12:03 --> Total execution time: 0.1238
INFO - 2025-09-06 10:12:09 --> Config Class Initialized
INFO - 2025-09-06 10:12:09 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:12:09 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:12:09 --> Utf8 Class Initialized
INFO - 2025-09-06 10:12:09 --> URI Class Initialized
INFO - 2025-09-06 10:12:09 --> Router Class Initialized
INFO - 2025-09-06 10:12:09 --> Output Class Initialized
INFO - 2025-09-06 10:12:09 --> Security Class Initialized
DEBUG - 2025-09-06 10:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:12:09 --> Input Class Initialized
INFO - 2025-09-06 10:12:09 --> Language Class Initialized
INFO - 2025-09-06 10:12:09 --> Loader Class Initialized
INFO - 2025-09-06 10:12:09 --> Helper loaded: url_helper
INFO - 2025-09-06 10:12:09 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:12:09 --> Helper loaded: form_helper
INFO - 2025-09-06 10:12:09 --> Form Validation Class Initialized
INFO - 2025-09-06 10:12:09 --> Controller Class Initialized
INFO - 2025-09-06 10:12:09 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:12:09 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:12:09 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:12:09 --> Final output sent to browser
DEBUG - 2025-09-06 10:12:09 --> Total execution time: 0.1087
INFO - 2025-09-06 10:12:09 --> Config Class Initialized
INFO - 2025-09-06 10:12:09 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:12:09 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:12:09 --> Utf8 Class Initialized
INFO - 2025-09-06 10:12:09 --> URI Class Initialized
INFO - 2025-09-06 10:12:09 --> Router Class Initialized
INFO - 2025-09-06 10:12:09 --> Output Class Initialized
INFO - 2025-09-06 10:12:09 --> Security Class Initialized
DEBUG - 2025-09-06 10:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:12:09 --> Input Class Initialized
INFO - 2025-09-06 10:12:09 --> Language Class Initialized
INFO - 2025-09-06 10:12:09 --> Loader Class Initialized
INFO - 2025-09-06 10:12:09 --> Helper loaded: url_helper
INFO - 2025-09-06 10:12:09 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:12:09 --> Helper loaded: form_helper
INFO - 2025-09-06 10:12:09 --> Form Validation Class Initialized
INFO - 2025-09-06 10:12:09 --> Controller Class Initialized
INFO - 2025-09-06 10:12:09 --> Model "Center_model" initialized
INFO - 2025-09-06 10:12:09 --> Final output sent to browser
DEBUG - 2025-09-06 10:12:09 --> Total execution time: 0.1218
INFO - 2025-09-06 10:12:12 --> Config Class Initialized
INFO - 2025-09-06 10:12:12 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:12:12 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:12:12 --> Utf8 Class Initialized
INFO - 2025-09-06 10:12:12 --> URI Class Initialized
INFO - 2025-09-06 10:12:12 --> Router Class Initialized
INFO - 2025-09-06 10:12:12 --> Output Class Initialized
INFO - 2025-09-06 10:12:12 --> Security Class Initialized
DEBUG - 2025-09-06 10:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:12:12 --> Input Class Initialized
INFO - 2025-09-06 10:12:12 --> Language Class Initialized
INFO - 2025-09-06 10:12:12 --> Loader Class Initialized
INFO - 2025-09-06 10:12:12 --> Helper loaded: url_helper
INFO - 2025-09-06 10:12:12 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:12:12 --> Helper loaded: form_helper
INFO - 2025-09-06 10:12:12 --> Form Validation Class Initialized
INFO - 2025-09-06 10:12:12 --> Controller Class Initialized
INFO - 2025-09-06 10:12:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:12:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:12:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 10:12:12 --> Final output sent to browser
DEBUG - 2025-09-06 10:12:12 --> Total execution time: 0.1244
INFO - 2025-09-06 10:12:12 --> Config Class Initialized
INFO - 2025-09-06 10:12:12 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:12:12 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:12:12 --> Utf8 Class Initialized
INFO - 2025-09-06 10:12:12 --> URI Class Initialized
INFO - 2025-09-06 10:12:12 --> Router Class Initialized
INFO - 2025-09-06 10:12:12 --> Output Class Initialized
INFO - 2025-09-06 10:12:12 --> Security Class Initialized
DEBUG - 2025-09-06 10:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:12:12 --> Input Class Initialized
INFO - 2025-09-06 10:12:12 --> Language Class Initialized
INFO - 2025-09-06 10:12:12 --> Loader Class Initialized
INFO - 2025-09-06 10:12:12 --> Helper loaded: url_helper
INFO - 2025-09-06 10:12:12 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:12:12 --> Helper loaded: form_helper
INFO - 2025-09-06 10:12:12 --> Form Validation Class Initialized
INFO - 2025-09-06 10:12:12 --> Controller Class Initialized
INFO - 2025-09-06 10:12:12 --> Model "Center_model" initialized
INFO - 2025-09-06 10:12:12 --> Final output sent to browser
DEBUG - 2025-09-06 10:12:12 --> Total execution time: 0.1033
INFO - 2025-09-06 10:13:01 --> Config Class Initialized
INFO - 2025-09-06 10:13:01 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:13:01 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:13:01 --> Utf8 Class Initialized
INFO - 2025-09-06 10:13:01 --> URI Class Initialized
INFO - 2025-09-06 10:13:01 --> Router Class Initialized
INFO - 2025-09-06 10:13:01 --> Output Class Initialized
INFO - 2025-09-06 10:13:01 --> Security Class Initialized
DEBUG - 2025-09-06 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:13:01 --> Input Class Initialized
INFO - 2025-09-06 10:13:01 --> Language Class Initialized
INFO - 2025-09-06 10:13:01 --> Loader Class Initialized
INFO - 2025-09-06 10:13:01 --> Helper loaded: url_helper
INFO - 2025-09-06 10:13:01 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:13:01 --> Helper loaded: form_helper
INFO - 2025-09-06 10:13:01 --> Form Validation Class Initialized
INFO - 2025-09-06 10:13:01 --> Controller Class Initialized
INFO - 2025-09-06 10:13:01 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:13:01 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:13:01 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:13:01 --> Final output sent to browser
DEBUG - 2025-09-06 10:13:01 --> Total execution time: 0.1083
INFO - 2025-09-06 10:13:01 --> Config Class Initialized
INFO - 2025-09-06 10:13:01 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:13:01 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:13:01 --> Utf8 Class Initialized
INFO - 2025-09-06 10:13:01 --> URI Class Initialized
INFO - 2025-09-06 10:13:01 --> Router Class Initialized
INFO - 2025-09-06 10:13:01 --> Output Class Initialized
INFO - 2025-09-06 10:13:01 --> Security Class Initialized
DEBUG - 2025-09-06 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:13:01 --> Input Class Initialized
INFO - 2025-09-06 10:13:01 --> Language Class Initialized
INFO - 2025-09-06 10:13:01 --> Loader Class Initialized
INFO - 2025-09-06 10:13:01 --> Helper loaded: url_helper
INFO - 2025-09-06 10:13:01 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:13:01 --> Helper loaded: form_helper
INFO - 2025-09-06 10:13:01 --> Form Validation Class Initialized
INFO - 2025-09-06 10:13:01 --> Controller Class Initialized
INFO - 2025-09-06 10:13:01 --> Model "Center_model" initialized
INFO - 2025-09-06 10:13:01 --> Final output sent to browser
DEBUG - 2025-09-06 10:13:01 --> Total execution time: 0.1313
INFO - 2025-09-06 10:13:05 --> Config Class Initialized
INFO - 2025-09-06 10:13:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:13:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:13:05 --> Utf8 Class Initialized
INFO - 2025-09-06 10:13:05 --> URI Class Initialized
INFO - 2025-09-06 10:13:05 --> Router Class Initialized
INFO - 2025-09-06 10:13:05 --> Output Class Initialized
INFO - 2025-09-06 10:13:05 --> Security Class Initialized
DEBUG - 2025-09-06 10:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:13:05 --> Input Class Initialized
INFO - 2025-09-06 10:13:05 --> Language Class Initialized
INFO - 2025-09-06 10:13:05 --> Loader Class Initialized
INFO - 2025-09-06 10:13:05 --> Helper loaded: url_helper
INFO - 2025-09-06 10:13:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:13:05 --> Helper loaded: form_helper
INFO - 2025-09-06 10:13:05 --> Form Validation Class Initialized
INFO - 2025-09-06 10:13:05 --> Controller Class Initialized
INFO - 2025-09-06 10:13:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:13:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:13:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:13:05 --> Final output sent to browser
DEBUG - 2025-09-06 10:13:05 --> Total execution time: 0.1419
INFO - 2025-09-06 10:13:05 --> Config Class Initialized
INFO - 2025-09-06 10:13:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:13:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:13:05 --> Utf8 Class Initialized
INFO - 2025-09-06 10:13:05 --> URI Class Initialized
INFO - 2025-09-06 10:13:05 --> Router Class Initialized
INFO - 2025-09-06 10:13:05 --> Output Class Initialized
INFO - 2025-09-06 10:13:05 --> Security Class Initialized
DEBUG - 2025-09-06 10:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:13:05 --> Input Class Initialized
INFO - 2025-09-06 10:13:05 --> Language Class Initialized
INFO - 2025-09-06 10:13:05 --> Loader Class Initialized
INFO - 2025-09-06 10:13:05 --> Helper loaded: url_helper
INFO - 2025-09-06 10:13:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:13:05 --> Helper loaded: form_helper
INFO - 2025-09-06 10:13:05 --> Form Validation Class Initialized
INFO - 2025-09-06 10:13:05 --> Controller Class Initialized
INFO - 2025-09-06 10:13:05 --> Model "Center_model" initialized
INFO - 2025-09-06 10:13:05 --> Final output sent to browser
DEBUG - 2025-09-06 10:13:05 --> Total execution time: 0.1139
INFO - 2025-09-06 10:13:05 --> Config Class Initialized
INFO - 2025-09-06 10:13:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:13:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:13:05 --> Utf8 Class Initialized
INFO - 2025-09-06 10:13:05 --> URI Class Initialized
INFO - 2025-09-06 10:13:05 --> Router Class Initialized
INFO - 2025-09-06 10:13:05 --> Output Class Initialized
INFO - 2025-09-06 10:13:05 --> Security Class Initialized
DEBUG - 2025-09-06 10:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:13:05 --> Input Class Initialized
INFO - 2025-09-06 10:13:05 --> Language Class Initialized
INFO - 2025-09-06 10:13:05 --> Loader Class Initialized
INFO - 2025-09-06 10:13:05 --> Helper loaded: url_helper
INFO - 2025-09-06 10:13:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:13:05 --> Helper loaded: form_helper
INFO - 2025-09-06 10:13:05 --> Form Validation Class Initialized
INFO - 2025-09-06 10:13:05 --> Controller Class Initialized
INFO - 2025-09-06 10:13:05 --> Model "Center_model" initialized
INFO - 2025-09-06 10:13:05 --> Final output sent to browser
DEBUG - 2025-09-06 10:13:05 --> Total execution time: 0.0944
INFO - 2025-09-06 10:13:09 --> Config Class Initialized
INFO - 2025-09-06 10:13:09 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:13:09 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:13:09 --> Utf8 Class Initialized
INFO - 2025-09-06 10:13:09 --> URI Class Initialized
INFO - 2025-09-06 10:13:09 --> Router Class Initialized
INFO - 2025-09-06 10:13:09 --> Output Class Initialized
INFO - 2025-09-06 10:13:09 --> Security Class Initialized
DEBUG - 2025-09-06 10:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:13:09 --> Input Class Initialized
INFO - 2025-09-06 10:13:09 --> Language Class Initialized
INFO - 2025-09-06 10:13:09 --> Loader Class Initialized
INFO - 2025-09-06 10:13:09 --> Helper loaded: url_helper
INFO - 2025-09-06 10:13:09 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:13:09 --> Helper loaded: form_helper
INFO - 2025-09-06 10:13:09 --> Form Validation Class Initialized
INFO - 2025-09-06 10:13:09 --> Controller Class Initialized
INFO - 2025-09-06 10:13:09 --> Model "Center_model" initialized
INFO - 2025-09-06 10:13:09 --> Final output sent to browser
DEBUG - 2025-09-06 10:13:09 --> Total execution time: 0.1421
INFO - 2025-09-06 10:15:05 --> Config Class Initialized
INFO - 2025-09-06 10:15:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:15:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:15:05 --> Utf8 Class Initialized
INFO - 2025-09-06 10:15:05 --> URI Class Initialized
INFO - 2025-09-06 10:15:05 --> Router Class Initialized
INFO - 2025-09-06 10:15:05 --> Output Class Initialized
INFO - 2025-09-06 10:15:05 --> Security Class Initialized
DEBUG - 2025-09-06 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:15:05 --> Input Class Initialized
INFO - 2025-09-06 10:15:05 --> Language Class Initialized
INFO - 2025-09-06 10:15:05 --> Loader Class Initialized
INFO - 2025-09-06 10:15:05 --> Helper loaded: url_helper
INFO - 2025-09-06 10:15:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:15:05 --> Helper loaded: form_helper
INFO - 2025-09-06 10:15:05 --> Form Validation Class Initialized
INFO - 2025-09-06 10:15:05 --> Controller Class Initialized
INFO - 2025-09-06 10:15:05 --> Model "Center_model" initialized
INFO - 2025-09-06 10:15:05 --> Final output sent to browser
DEBUG - 2025-09-06 10:15:05 --> Total execution time: 0.0956
INFO - 2025-09-06 10:17:24 --> Config Class Initialized
INFO - 2025-09-06 10:17:24 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:24 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:24 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:24 --> URI Class Initialized
INFO - 2025-09-06 10:17:24 --> Router Class Initialized
INFO - 2025-09-06 10:17:24 --> Output Class Initialized
INFO - 2025-09-06 10:17:24 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:24 --> Input Class Initialized
INFO - 2025-09-06 10:17:24 --> Language Class Initialized
INFO - 2025-09-06 10:17:24 --> Loader Class Initialized
INFO - 2025-09-06 10:17:24 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:24 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:24 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:24 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:24 --> Controller Class Initialized
INFO - 2025-09-06 10:17:24 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:24 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:24 --> Total execution time: 0.1368
INFO - 2025-09-06 10:17:25 --> Config Class Initialized
INFO - 2025-09-06 10:17:25 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:25 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:25 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:25 --> URI Class Initialized
INFO - 2025-09-06 10:17:25 --> Router Class Initialized
INFO - 2025-09-06 10:17:25 --> Output Class Initialized
INFO - 2025-09-06 10:17:25 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:25 --> Input Class Initialized
INFO - 2025-09-06 10:17:25 --> Language Class Initialized
INFO - 2025-09-06 10:17:25 --> Loader Class Initialized
INFO - 2025-09-06 10:17:25 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:25 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:25 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:25 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:25 --> Controller Class Initialized
INFO - 2025-09-06 10:17:25 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:25 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:25 --> Total execution time: 0.1044
INFO - 2025-09-06 10:17:26 --> Config Class Initialized
INFO - 2025-09-06 10:17:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:26 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:26 --> URI Class Initialized
INFO - 2025-09-06 10:17:26 --> Router Class Initialized
INFO - 2025-09-06 10:17:26 --> Output Class Initialized
INFO - 2025-09-06 10:17:26 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:26 --> Input Class Initialized
INFO - 2025-09-06 10:17:26 --> Language Class Initialized
INFO - 2025-09-06 10:17:26 --> Loader Class Initialized
INFO - 2025-09-06 10:17:26 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:26 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:26 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:26 --> Controller Class Initialized
INFO - 2025-09-06 10:17:26 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:26 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:26 --> Total execution time: 0.0799
INFO - 2025-09-06 10:17:28 --> Config Class Initialized
INFO - 2025-09-06 10:17:28 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:28 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:28 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:28 --> URI Class Initialized
INFO - 2025-09-06 10:17:28 --> Router Class Initialized
INFO - 2025-09-06 10:17:28 --> Output Class Initialized
INFO - 2025-09-06 10:17:28 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:28 --> Input Class Initialized
INFO - 2025-09-06 10:17:28 --> Language Class Initialized
INFO - 2025-09-06 10:17:28 --> Loader Class Initialized
INFO - 2025-09-06 10:17:28 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:28 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:28 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:28 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:28 --> Controller Class Initialized
INFO - 2025-09-06 10:17:28 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:28 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:28 --> Total execution time: 0.0773
INFO - 2025-09-06 10:17:31 --> Config Class Initialized
INFO - 2025-09-06 10:17:31 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:31 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:31 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:31 --> URI Class Initialized
INFO - 2025-09-06 10:17:31 --> Router Class Initialized
INFO - 2025-09-06 10:17:31 --> Output Class Initialized
INFO - 2025-09-06 10:17:31 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:31 --> Input Class Initialized
INFO - 2025-09-06 10:17:31 --> Language Class Initialized
INFO - 2025-09-06 10:17:31 --> Loader Class Initialized
INFO - 2025-09-06 10:17:31 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:31 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:31 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:31 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:31 --> Controller Class Initialized
INFO - 2025-09-06 10:17:31 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:31 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:31 --> Total execution time: 0.1065
INFO - 2025-09-06 10:17:31 --> Config Class Initialized
INFO - 2025-09-06 10:17:31 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:31 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:31 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:31 --> URI Class Initialized
INFO - 2025-09-06 10:17:31 --> Router Class Initialized
INFO - 2025-09-06 10:17:31 --> Output Class Initialized
INFO - 2025-09-06 10:17:31 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:31 --> Input Class Initialized
INFO - 2025-09-06 10:17:31 --> Language Class Initialized
INFO - 2025-09-06 10:17:31 --> Loader Class Initialized
INFO - 2025-09-06 10:17:31 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:31 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:31 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:31 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:31 --> Controller Class Initialized
INFO - 2025-09-06 10:17:31 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:31 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:31 --> Total execution time: 0.0831
INFO - 2025-09-06 10:17:31 --> Config Class Initialized
INFO - 2025-09-06 10:17:31 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:31 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:31 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:31 --> URI Class Initialized
INFO - 2025-09-06 10:17:31 --> Router Class Initialized
INFO - 2025-09-06 10:17:31 --> Output Class Initialized
INFO - 2025-09-06 10:17:31 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:31 --> Input Class Initialized
INFO - 2025-09-06 10:17:31 --> Language Class Initialized
INFO - 2025-09-06 10:17:31 --> Loader Class Initialized
INFO - 2025-09-06 10:17:31 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:31 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:31 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:31 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:31 --> Controller Class Initialized
INFO - 2025-09-06 10:17:31 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:31 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:31 --> Total execution time: 0.1030
INFO - 2025-09-06 10:17:31 --> Config Class Initialized
INFO - 2025-09-06 10:17:31 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:31 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:31 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:31 --> URI Class Initialized
INFO - 2025-09-06 10:17:32 --> Router Class Initialized
INFO - 2025-09-06 10:17:32 --> Output Class Initialized
INFO - 2025-09-06 10:17:32 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:32 --> Input Class Initialized
INFO - 2025-09-06 10:17:32 --> Language Class Initialized
INFO - 2025-09-06 10:17:32 --> Loader Class Initialized
INFO - 2025-09-06 10:17:32 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:32 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:32 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:32 --> Controller Class Initialized
INFO - 2025-09-06 10:17:32 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:32 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:32 --> Total execution time: 0.1352
INFO - 2025-09-06 10:17:33 --> Config Class Initialized
INFO - 2025-09-06 10:17:33 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:17:33 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:17:33 --> Utf8 Class Initialized
INFO - 2025-09-06 10:17:33 --> URI Class Initialized
INFO - 2025-09-06 10:17:33 --> Router Class Initialized
INFO - 2025-09-06 10:17:33 --> Output Class Initialized
INFO - 2025-09-06 10:17:33 --> Security Class Initialized
DEBUG - 2025-09-06 10:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:17:33 --> Input Class Initialized
INFO - 2025-09-06 10:17:33 --> Language Class Initialized
INFO - 2025-09-06 10:17:33 --> Loader Class Initialized
INFO - 2025-09-06 10:17:33 --> Helper loaded: url_helper
INFO - 2025-09-06 10:17:33 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:17:33 --> Helper loaded: form_helper
INFO - 2025-09-06 10:17:33 --> Form Validation Class Initialized
INFO - 2025-09-06 10:17:33 --> Controller Class Initialized
INFO - 2025-09-06 10:17:33 --> Model "Center_model" initialized
INFO - 2025-09-06 10:17:33 --> Final output sent to browser
DEBUG - 2025-09-06 10:17:33 --> Total execution time: 0.2126
INFO - 2025-09-06 10:18:00 --> Config Class Initialized
INFO - 2025-09-06 10:18:00 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:00 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:00 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:00 --> URI Class Initialized
INFO - 2025-09-06 10:18:00 --> Router Class Initialized
INFO - 2025-09-06 10:18:00 --> Output Class Initialized
INFO - 2025-09-06 10:18:00 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:00 --> Input Class Initialized
INFO - 2025-09-06 10:18:00 --> Language Class Initialized
INFO - 2025-09-06 10:18:00 --> Loader Class Initialized
INFO - 2025-09-06 10:18:00 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:00 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:00 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:00 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:00 --> Controller Class Initialized
INFO - 2025-09-06 10:18:00 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:00 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:00 --> Total execution time: 0.2206
INFO - 2025-09-06 10:18:00 --> Config Class Initialized
INFO - 2025-09-06 10:18:00 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:00 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:00 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:00 --> URI Class Initialized
INFO - 2025-09-06 10:18:00 --> Router Class Initialized
INFO - 2025-09-06 10:18:00 --> Output Class Initialized
INFO - 2025-09-06 10:18:00 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:00 --> Input Class Initialized
INFO - 2025-09-06 10:18:00 --> Language Class Initialized
INFO - 2025-09-06 10:18:00 --> Loader Class Initialized
INFO - 2025-09-06 10:18:00 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:00 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:00 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:00 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:00 --> Controller Class Initialized
INFO - 2025-09-06 10:18:00 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:00 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:00 --> Total execution time: 0.5328
INFO - 2025-09-06 10:18:00 --> Config Class Initialized
INFO - 2025-09-06 10:18:00 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:00 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:00 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:00 --> URI Class Initialized
INFO - 2025-09-06 10:18:00 --> Router Class Initialized
INFO - 2025-09-06 10:18:00 --> Output Class Initialized
INFO - 2025-09-06 10:18:00 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:01 --> Input Class Initialized
INFO - 2025-09-06 10:18:01 --> Language Class Initialized
INFO - 2025-09-06 10:18:01 --> Loader Class Initialized
INFO - 2025-09-06 10:18:01 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:01 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:01 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:01 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:01 --> Controller Class Initialized
INFO - 2025-09-06 10:18:01 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:01 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:01 --> Total execution time: 0.3266
INFO - 2025-09-06 10:18:03 --> Config Class Initialized
INFO - 2025-09-06 10:18:03 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:03 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:03 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:03 --> URI Class Initialized
INFO - 2025-09-06 10:18:03 --> Router Class Initialized
INFO - 2025-09-06 10:18:03 --> Output Class Initialized
INFO - 2025-09-06 10:18:03 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:03 --> Input Class Initialized
INFO - 2025-09-06 10:18:03 --> Language Class Initialized
INFO - 2025-09-06 10:18:03 --> Loader Class Initialized
INFO - 2025-09-06 10:18:03 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:03 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:03 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:03 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:03 --> Controller Class Initialized
INFO - 2025-09-06 10:18:03 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:03 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:03 --> Total execution time: 0.1027
INFO - 2025-09-06 10:18:03 --> Config Class Initialized
INFO - 2025-09-06 10:18:03 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:03 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:03 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:03 --> URI Class Initialized
INFO - 2025-09-06 10:18:03 --> Router Class Initialized
INFO - 2025-09-06 10:18:03 --> Output Class Initialized
INFO - 2025-09-06 10:18:03 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:03 --> Input Class Initialized
INFO - 2025-09-06 10:18:03 --> Language Class Initialized
INFO - 2025-09-06 10:18:03 --> Loader Class Initialized
INFO - 2025-09-06 10:18:03 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:03 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:03 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:03 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:03 --> Controller Class Initialized
INFO - 2025-09-06 10:18:03 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:03 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:03 --> Total execution time: 0.1085
INFO - 2025-09-06 10:18:03 --> Config Class Initialized
INFO - 2025-09-06 10:18:03 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:03 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:03 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:03 --> URI Class Initialized
INFO - 2025-09-06 10:18:03 --> Router Class Initialized
INFO - 2025-09-06 10:18:03 --> Output Class Initialized
INFO - 2025-09-06 10:18:03 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:03 --> Input Class Initialized
INFO - 2025-09-06 10:18:03 --> Language Class Initialized
INFO - 2025-09-06 10:18:03 --> Loader Class Initialized
INFO - 2025-09-06 10:18:03 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:03 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:04 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:04 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:04 --> Controller Class Initialized
INFO - 2025-09-06 10:18:04 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:04 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:04 --> Total execution time: 0.0932
INFO - 2025-09-06 10:18:04 --> Config Class Initialized
INFO - 2025-09-06 10:18:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:04 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:04 --> URI Class Initialized
INFO - 2025-09-06 10:18:04 --> Router Class Initialized
INFO - 2025-09-06 10:18:04 --> Output Class Initialized
INFO - 2025-09-06 10:18:04 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:04 --> Input Class Initialized
INFO - 2025-09-06 10:18:04 --> Language Class Initialized
INFO - 2025-09-06 10:18:04 --> Loader Class Initialized
INFO - 2025-09-06 10:18:04 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:04 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:04 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:04 --> Controller Class Initialized
INFO - 2025-09-06 10:18:04 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:04 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:04 --> Total execution time: 0.1045
INFO - 2025-09-06 10:18:36 --> Config Class Initialized
INFO - 2025-09-06 10:18:36 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:36 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:36 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:36 --> URI Class Initialized
INFO - 2025-09-06 10:18:36 --> Router Class Initialized
INFO - 2025-09-06 10:18:36 --> Output Class Initialized
INFO - 2025-09-06 10:18:36 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:36 --> Input Class Initialized
INFO - 2025-09-06 10:18:36 --> Language Class Initialized
INFO - 2025-09-06 10:18:36 --> Loader Class Initialized
INFO - 2025-09-06 10:18:36 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:36 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:36 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:36 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:36 --> Controller Class Initialized
INFO - 2025-09-06 10:18:36 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:18:36 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:18:36 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:18:36 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:36 --> Total execution time: 0.1331
INFO - 2025-09-06 10:18:36 --> Config Class Initialized
INFO - 2025-09-06 10:18:36 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:36 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:36 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:36 --> URI Class Initialized
INFO - 2025-09-06 10:18:36 --> Router Class Initialized
INFO - 2025-09-06 10:18:36 --> Output Class Initialized
INFO - 2025-09-06 10:18:36 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:36 --> Input Class Initialized
INFO - 2025-09-06 10:18:36 --> Language Class Initialized
INFO - 2025-09-06 10:18:36 --> Loader Class Initialized
INFO - 2025-09-06 10:18:36 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:36 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:36 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:36 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:36 --> Controller Class Initialized
INFO - 2025-09-06 10:18:36 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:36 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:36 --> Total execution time: 0.1214
INFO - 2025-09-06 10:18:36 --> Config Class Initialized
INFO - 2025-09-06 10:18:36 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:36 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:36 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:36 --> URI Class Initialized
INFO - 2025-09-06 10:18:36 --> Router Class Initialized
INFO - 2025-09-06 10:18:36 --> Output Class Initialized
INFO - 2025-09-06 10:18:36 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:36 --> Input Class Initialized
INFO - 2025-09-06 10:18:36 --> Language Class Initialized
INFO - 2025-09-06 10:18:36 --> Loader Class Initialized
INFO - 2025-09-06 10:18:36 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:36 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:36 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:36 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:36 --> Controller Class Initialized
INFO - 2025-09-06 10:18:36 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:36 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:36 --> Total execution time: 0.1187
INFO - 2025-09-06 10:18:40 --> Config Class Initialized
INFO - 2025-09-06 10:18:40 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:40 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:40 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:40 --> URI Class Initialized
INFO - 2025-09-06 10:18:40 --> Router Class Initialized
INFO - 2025-09-06 10:18:40 --> Output Class Initialized
INFO - 2025-09-06 10:18:40 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:40 --> Input Class Initialized
INFO - 2025-09-06 10:18:40 --> Language Class Initialized
INFO - 2025-09-06 10:18:40 --> Loader Class Initialized
INFO - 2025-09-06 10:18:40 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:40 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:40 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:40 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:40 --> Controller Class Initialized
INFO - 2025-09-06 10:18:40 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:40 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:40 --> Total execution time: 0.1537
INFO - 2025-09-06 10:18:42 --> Config Class Initialized
INFO - 2025-09-06 10:18:42 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:18:42 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:18:42 --> Utf8 Class Initialized
INFO - 2025-09-06 10:18:42 --> URI Class Initialized
INFO - 2025-09-06 10:18:42 --> Router Class Initialized
INFO - 2025-09-06 10:18:42 --> Output Class Initialized
INFO - 2025-09-06 10:18:42 --> Security Class Initialized
DEBUG - 2025-09-06 10:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:18:42 --> Input Class Initialized
INFO - 2025-09-06 10:18:42 --> Language Class Initialized
INFO - 2025-09-06 10:18:42 --> Loader Class Initialized
INFO - 2025-09-06 10:18:42 --> Helper loaded: url_helper
INFO - 2025-09-06 10:18:42 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:18:42 --> Helper loaded: form_helper
INFO - 2025-09-06 10:18:42 --> Form Validation Class Initialized
INFO - 2025-09-06 10:18:42 --> Controller Class Initialized
INFO - 2025-09-06 10:18:42 --> Model "Center_model" initialized
INFO - 2025-09-06 10:18:42 --> Final output sent to browser
DEBUG - 2025-09-06 10:18:42 --> Total execution time: 0.1368
INFO - 2025-09-06 10:28:04 --> Config Class Initialized
INFO - 2025-09-06 10:28:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:28:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:28:04 --> Utf8 Class Initialized
INFO - 2025-09-06 10:28:04 --> URI Class Initialized
INFO - 2025-09-06 10:28:04 --> Router Class Initialized
INFO - 2025-09-06 10:28:04 --> Output Class Initialized
INFO - 2025-09-06 10:28:04 --> Security Class Initialized
DEBUG - 2025-09-06 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:28:04 --> Input Class Initialized
INFO - 2025-09-06 10:28:04 --> Language Class Initialized
INFO - 2025-09-06 10:28:04 --> Loader Class Initialized
INFO - 2025-09-06 10:28:04 --> Helper loaded: url_helper
INFO - 2025-09-06 10:28:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:28:04 --> Helper loaded: form_helper
INFO - 2025-09-06 10:28:04 --> Form Validation Class Initialized
INFO - 2025-09-06 10:28:04 --> Controller Class Initialized
INFO - 2025-09-06 10:28:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:28:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:28:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:28:04 --> Final output sent to browser
DEBUG - 2025-09-06 10:28:04 --> Total execution time: 0.1355
INFO - 2025-09-06 10:28:04 --> Config Class Initialized
INFO - 2025-09-06 10:28:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:28:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:28:04 --> Utf8 Class Initialized
INFO - 2025-09-06 10:28:04 --> URI Class Initialized
INFO - 2025-09-06 10:28:04 --> Router Class Initialized
INFO - 2025-09-06 10:28:04 --> Output Class Initialized
INFO - 2025-09-06 10:28:04 --> Security Class Initialized
DEBUG - 2025-09-06 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:28:04 --> Input Class Initialized
INFO - 2025-09-06 10:28:04 --> Language Class Initialized
INFO - 2025-09-06 10:28:04 --> Loader Class Initialized
INFO - 2025-09-06 10:28:04 --> Helper loaded: url_helper
INFO - 2025-09-06 10:28:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:28:04 --> Helper loaded: form_helper
INFO - 2025-09-06 10:28:04 --> Form Validation Class Initialized
INFO - 2025-09-06 10:28:04 --> Controller Class Initialized
INFO - 2025-09-06 10:28:04 --> Model "Center_model" initialized
INFO - 2025-09-06 10:28:04 --> Final output sent to browser
DEBUG - 2025-09-06 10:28:04 --> Total execution time: 0.1237
INFO - 2025-09-06 10:28:04 --> Config Class Initialized
INFO - 2025-09-06 10:28:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:28:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:28:04 --> Utf8 Class Initialized
INFO - 2025-09-06 10:28:04 --> URI Class Initialized
INFO - 2025-09-06 10:28:04 --> Router Class Initialized
INFO - 2025-09-06 10:28:04 --> Output Class Initialized
INFO - 2025-09-06 10:28:04 --> Security Class Initialized
DEBUG - 2025-09-06 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:28:04 --> Input Class Initialized
INFO - 2025-09-06 10:28:04 --> Language Class Initialized
INFO - 2025-09-06 10:28:04 --> Loader Class Initialized
INFO - 2025-09-06 10:28:04 --> Helper loaded: url_helper
INFO - 2025-09-06 10:28:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:28:05 --> Helper loaded: form_helper
INFO - 2025-09-06 10:28:05 --> Form Validation Class Initialized
INFO - 2025-09-06 10:28:05 --> Controller Class Initialized
INFO - 2025-09-06 10:28:05 --> Model "Center_model" initialized
INFO - 2025-09-06 10:28:05 --> Final output sent to browser
DEBUG - 2025-09-06 10:28:05 --> Total execution time: 0.1409
INFO - 2025-09-06 10:28:06 --> Config Class Initialized
INFO - 2025-09-06 10:28:06 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:28:06 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:28:06 --> Utf8 Class Initialized
INFO - 2025-09-06 10:28:06 --> URI Class Initialized
INFO - 2025-09-06 10:28:06 --> Router Class Initialized
INFO - 2025-09-06 10:28:06 --> Output Class Initialized
INFO - 2025-09-06 10:28:06 --> Security Class Initialized
DEBUG - 2025-09-06 10:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:28:06 --> Input Class Initialized
INFO - 2025-09-06 10:28:06 --> Language Class Initialized
INFO - 2025-09-06 10:28:06 --> Loader Class Initialized
INFO - 2025-09-06 10:28:06 --> Helper loaded: url_helper
INFO - 2025-09-06 10:28:06 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:28:06 --> Helper loaded: form_helper
INFO - 2025-09-06 10:28:06 --> Form Validation Class Initialized
INFO - 2025-09-06 10:28:06 --> Controller Class Initialized
INFO - 2025-09-06 10:28:06 --> Model "Center_model" initialized
INFO - 2025-09-06 10:28:06 --> Final output sent to browser
DEBUG - 2025-09-06 10:28:06 --> Total execution time: 0.1586
INFO - 2025-09-06 10:28:13 --> Config Class Initialized
INFO - 2025-09-06 10:28:13 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:28:13 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:28:13 --> Utf8 Class Initialized
INFO - 2025-09-06 10:28:13 --> URI Class Initialized
INFO - 2025-09-06 10:28:13 --> Config Class Initialized
INFO - 2025-09-06 10:28:13 --> Router Class Initialized
INFO - 2025-09-06 10:28:13 --> Hooks Class Initialized
INFO - 2025-09-06 10:28:13 --> Output Class Initialized
INFO - 2025-09-06 10:28:13 --> Security Class Initialized
DEBUG - 2025-09-06 10:28:13 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:28:13 --> Utf8 Class Initialized
DEBUG - 2025-09-06 10:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:28:13 --> Input Class Initialized
INFO - 2025-09-06 10:28:13 --> URI Class Initialized
INFO - 2025-09-06 10:28:13 --> Language Class Initialized
INFO - 2025-09-06 10:28:13 --> Router Class Initialized
INFO - 2025-09-06 10:28:13 --> Loader Class Initialized
INFO - 2025-09-06 10:28:13 --> Output Class Initialized
INFO - 2025-09-06 10:28:13 --> Helper loaded: url_helper
INFO - 2025-09-06 10:28:13 --> Security Class Initialized
DEBUG - 2025-09-06 10:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:28:13 --> Input Class Initialized
INFO - 2025-09-06 10:28:13 --> Language Class Initialized
INFO - 2025-09-06 10:28:13 --> Database Driver Class Initialized
INFO - 2025-09-06 10:28:13 --> Loader Class Initialized
INFO - 2025-09-06 10:28:13 --> Helper loaded: url_helper
DEBUG - 2025-09-06 10:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:28:13 --> Database Driver Class Initialized
INFO - 2025-09-06 10:28:13 --> Helper loaded: form_helper
INFO - 2025-09-06 10:28:13 --> Form Validation Class Initialized
INFO - 2025-09-06 10:28:13 --> Controller Class Initialized
INFO - 2025-09-06 10:28:13 --> Model "Center_model" initialized
DEBUG - 2025-09-06 10:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:28:13 --> Final output sent to browser
DEBUG - 2025-09-06 10:28:13 --> Total execution time: 0.1801
INFO - 2025-09-06 10:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:28:13 --> Helper loaded: form_helper
INFO - 2025-09-06 10:28:13 --> Form Validation Class Initialized
INFO - 2025-09-06 10:28:13 --> Controller Class Initialized
INFO - 2025-09-06 10:28:13 --> Model "Center_model" initialized
INFO - 2025-09-06 10:28:13 --> Final output sent to browser
DEBUG - 2025-09-06 10:28:13 --> Total execution time: 0.1774
INFO - 2025-09-06 10:28:15 --> Config Class Initialized
INFO - 2025-09-06 10:28:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:28:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:28:15 --> Utf8 Class Initialized
INFO - 2025-09-06 10:28:15 --> URI Class Initialized
INFO - 2025-09-06 10:28:15 --> Router Class Initialized
INFO - 2025-09-06 10:28:15 --> Output Class Initialized
INFO - 2025-09-06 10:28:15 --> Security Class Initialized
DEBUG - 2025-09-06 10:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:28:15 --> Input Class Initialized
INFO - 2025-09-06 10:28:15 --> Language Class Initialized
INFO - 2025-09-06 10:28:15 --> Loader Class Initialized
INFO - 2025-09-06 10:28:15 --> Helper loaded: url_helper
INFO - 2025-09-06 10:28:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:28:15 --> Helper loaded: form_helper
INFO - 2025-09-06 10:28:15 --> Form Validation Class Initialized
INFO - 2025-09-06 10:28:15 --> Controller Class Initialized
INFO - 2025-09-06 10:28:15 --> Model "Center_model" initialized
INFO - 2025-09-06 10:28:15 --> Final output sent to browser
DEBUG - 2025-09-06 10:28:15 --> Total execution time: 0.1532
INFO - 2025-09-06 10:28:21 --> Config Class Initialized
INFO - 2025-09-06 10:28:21 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:28:21 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:28:21 --> Utf8 Class Initialized
INFO - 2025-09-06 10:28:21 --> URI Class Initialized
INFO - 2025-09-06 10:28:21 --> Router Class Initialized
INFO - 2025-09-06 10:28:21 --> Output Class Initialized
INFO - 2025-09-06 10:28:21 --> Security Class Initialized
DEBUG - 2025-09-06 10:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:28:21 --> Input Class Initialized
INFO - 2025-09-06 10:28:21 --> Language Class Initialized
INFO - 2025-09-06 10:28:21 --> Loader Class Initialized
INFO - 2025-09-06 10:28:21 --> Helper loaded: url_helper
INFO - 2025-09-06 10:28:21 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:28:21 --> Helper loaded: form_helper
INFO - 2025-09-06 10:28:21 --> Form Validation Class Initialized
INFO - 2025-09-06 10:28:21 --> Controller Class Initialized
INFO - 2025-09-06 10:28:21 --> Model "Center_model" initialized
INFO - 2025-09-06 10:28:21 --> Final output sent to browser
DEBUG - 2025-09-06 10:28:21 --> Total execution time: 0.1001
INFO - 2025-09-06 10:29:10 --> Config Class Initialized
INFO - 2025-09-06 10:29:10 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:10 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:10 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:10 --> URI Class Initialized
INFO - 2025-09-06 10:29:10 --> Router Class Initialized
INFO - 2025-09-06 10:29:10 --> Output Class Initialized
INFO - 2025-09-06 10:29:10 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:10 --> Input Class Initialized
INFO - 2025-09-06 10:29:10 --> Language Class Initialized
INFO - 2025-09-06 10:29:10 --> Loader Class Initialized
INFO - 2025-09-06 10:29:10 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:10 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:10 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:10 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:10 --> Controller Class Initialized
INFO - 2025-09-06 10:29:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:29:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:29:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:29:10 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:10 --> Total execution time: 0.1137
INFO - 2025-09-06 10:29:11 --> Config Class Initialized
INFO - 2025-09-06 10:29:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:11 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:11 --> URI Class Initialized
INFO - 2025-09-06 10:29:11 --> Router Class Initialized
INFO - 2025-09-06 10:29:11 --> Output Class Initialized
INFO - 2025-09-06 10:29:11 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:11 --> Input Class Initialized
INFO - 2025-09-06 10:29:11 --> Language Class Initialized
INFO - 2025-09-06 10:29:11 --> Loader Class Initialized
INFO - 2025-09-06 10:29:11 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:11 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:11 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:11 --> Controller Class Initialized
INFO - 2025-09-06 10:29:11 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:11 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:11 --> Total execution time: 0.1070
INFO - 2025-09-06 10:29:11 --> Config Class Initialized
INFO - 2025-09-06 10:29:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:11 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:11 --> URI Class Initialized
INFO - 2025-09-06 10:29:11 --> Router Class Initialized
INFO - 2025-09-06 10:29:11 --> Output Class Initialized
INFO - 2025-09-06 10:29:11 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:11 --> Input Class Initialized
INFO - 2025-09-06 10:29:11 --> Language Class Initialized
INFO - 2025-09-06 10:29:11 --> Loader Class Initialized
INFO - 2025-09-06 10:29:11 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:11 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:11 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:11 --> Controller Class Initialized
INFO - 2025-09-06 10:29:11 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:11 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:11 --> Total execution time: 0.0990
INFO - 2025-09-06 10:29:13 --> Config Class Initialized
INFO - 2025-09-06 10:29:13 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:13 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:13 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:13 --> URI Class Initialized
INFO - 2025-09-06 10:29:13 --> Router Class Initialized
INFO - 2025-09-06 10:29:13 --> Output Class Initialized
INFO - 2025-09-06 10:29:13 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:13 --> Input Class Initialized
INFO - 2025-09-06 10:29:13 --> Language Class Initialized
INFO - 2025-09-06 10:29:13 --> Loader Class Initialized
INFO - 2025-09-06 10:29:13 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:13 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:13 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:13 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:13 --> Controller Class Initialized
INFO - 2025-09-06 10:29:13 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:13 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:13 --> Total execution time: 0.1060
INFO - 2025-09-06 10:29:15 --> Config Class Initialized
INFO - 2025-09-06 10:29:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:15 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:15 --> URI Class Initialized
INFO - 2025-09-06 10:29:15 --> Router Class Initialized
INFO - 2025-09-06 10:29:15 --> Output Class Initialized
INFO - 2025-09-06 10:29:15 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:15 --> Input Class Initialized
INFO - 2025-09-06 10:29:15 --> Language Class Initialized
INFO - 2025-09-06 10:29:15 --> Loader Class Initialized
INFO - 2025-09-06 10:29:15 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:15 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:15 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:15 --> Controller Class Initialized
INFO - 2025-09-06 10:29:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:29:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:29:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:29:15 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:15 --> Total execution time: 0.1013
INFO - 2025-09-06 10:29:15 --> Config Class Initialized
INFO - 2025-09-06 10:29:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:15 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:15 --> URI Class Initialized
INFO - 2025-09-06 10:29:15 --> Router Class Initialized
INFO - 2025-09-06 10:29:15 --> Output Class Initialized
INFO - 2025-09-06 10:29:15 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:15 --> Input Class Initialized
INFO - 2025-09-06 10:29:15 --> Language Class Initialized
INFO - 2025-09-06 10:29:15 --> Loader Class Initialized
INFO - 2025-09-06 10:29:15 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:15 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:15 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:15 --> Controller Class Initialized
INFO - 2025-09-06 10:29:15 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:15 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:15 --> Total execution time: 0.1249
INFO - 2025-09-06 10:29:19 --> Config Class Initialized
INFO - 2025-09-06 10:29:19 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:19 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:19 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:19 --> URI Class Initialized
INFO - 2025-09-06 10:29:19 --> Router Class Initialized
INFO - 2025-09-06 10:29:19 --> Output Class Initialized
INFO - 2025-09-06 10:29:19 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:19 --> Input Class Initialized
INFO - 2025-09-06 10:29:19 --> Language Class Initialized
INFO - 2025-09-06 10:29:19 --> Loader Class Initialized
INFO - 2025-09-06 10:29:19 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:19 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:20 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:20 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:20 --> Controller Class Initialized
INFO - 2025-09-06 10:29:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:29:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:29:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:29:20 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:20 --> Total execution time: 0.1377
INFO - 2025-09-06 10:29:20 --> Config Class Initialized
INFO - 2025-09-06 10:29:20 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:20 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:20 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:20 --> URI Class Initialized
INFO - 2025-09-06 10:29:20 --> Router Class Initialized
INFO - 2025-09-06 10:29:20 --> Output Class Initialized
INFO - 2025-09-06 10:29:20 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:20 --> Input Class Initialized
INFO - 2025-09-06 10:29:20 --> Language Class Initialized
INFO - 2025-09-06 10:29:20 --> Loader Class Initialized
INFO - 2025-09-06 10:29:20 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:20 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:20 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:20 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:20 --> Controller Class Initialized
INFO - 2025-09-06 10:29:20 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:20 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:20 --> Total execution time: 0.1259
INFO - 2025-09-06 10:29:20 --> Config Class Initialized
INFO - 2025-09-06 10:29:20 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:20 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:20 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:20 --> URI Class Initialized
INFO - 2025-09-06 10:29:20 --> Router Class Initialized
INFO - 2025-09-06 10:29:20 --> Output Class Initialized
INFO - 2025-09-06 10:29:20 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:20 --> Input Class Initialized
INFO - 2025-09-06 10:29:20 --> Language Class Initialized
INFO - 2025-09-06 10:29:20 --> Loader Class Initialized
INFO - 2025-09-06 10:29:20 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:20 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:20 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:20 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:20 --> Controller Class Initialized
INFO - 2025-09-06 10:29:20 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:20 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:20 --> Total execution time: 0.0953
INFO - 2025-09-06 10:29:22 --> Config Class Initialized
INFO - 2025-09-06 10:29:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:22 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:22 --> URI Class Initialized
INFO - 2025-09-06 10:29:22 --> Router Class Initialized
INFO - 2025-09-06 10:29:22 --> Output Class Initialized
INFO - 2025-09-06 10:29:22 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:22 --> Input Class Initialized
INFO - 2025-09-06 10:29:22 --> Language Class Initialized
INFO - 2025-09-06 10:29:22 --> Loader Class Initialized
INFO - 2025-09-06 10:29:22 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:22 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:22 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:22 --> Controller Class Initialized
INFO - 2025-09-06 10:29:22 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:22 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:22 --> Total execution time: 0.1064
INFO - 2025-09-06 10:29:24 --> Config Class Initialized
INFO - 2025-09-06 10:29:24 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:24 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:24 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:24 --> URI Class Initialized
INFO - 2025-09-06 10:29:24 --> Router Class Initialized
INFO - 2025-09-06 10:29:24 --> Output Class Initialized
INFO - 2025-09-06 10:29:24 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:24 --> Input Class Initialized
INFO - 2025-09-06 10:29:24 --> Language Class Initialized
INFO - 2025-09-06 10:29:24 --> Loader Class Initialized
INFO - 2025-09-06 10:29:24 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:24 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:24 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:24 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:24 --> Controller Class Initialized
INFO - 2025-09-06 10:29:24 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:29:24 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:29:24 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:29:24 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:24 --> Total execution time: 0.1179
INFO - 2025-09-06 10:29:24 --> Config Class Initialized
INFO - 2025-09-06 10:29:24 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:24 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:24 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:24 --> URI Class Initialized
INFO - 2025-09-06 10:29:24 --> Router Class Initialized
INFO - 2025-09-06 10:29:24 --> Output Class Initialized
INFO - 2025-09-06 10:29:24 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:24 --> Input Class Initialized
INFO - 2025-09-06 10:29:24 --> Language Class Initialized
INFO - 2025-09-06 10:29:24 --> Loader Class Initialized
INFO - 2025-09-06 10:29:24 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:24 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:24 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:24 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:24 --> Controller Class Initialized
INFO - 2025-09-06 10:29:24 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:24 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:24 --> Total execution time: 0.1497
INFO - 2025-09-06 10:29:26 --> Config Class Initialized
INFO - 2025-09-06 10:29:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:26 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:26 --> URI Class Initialized
INFO - 2025-09-06 10:29:26 --> Router Class Initialized
INFO - 2025-09-06 10:29:26 --> Output Class Initialized
INFO - 2025-09-06 10:29:26 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:26 --> Input Class Initialized
INFO - 2025-09-06 10:29:26 --> Language Class Initialized
INFO - 2025-09-06 10:29:26 --> Loader Class Initialized
INFO - 2025-09-06 10:29:26 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:26 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:26 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:26 --> Controller Class Initialized
INFO - 2025-09-06 10:29:26 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:29:26 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:29:26 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:29:26 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:26 --> Total execution time: 0.1293
INFO - 2025-09-06 10:29:26 --> Config Class Initialized
INFO - 2025-09-06 10:29:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:26 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:26 --> URI Class Initialized
INFO - 2025-09-06 10:29:26 --> Router Class Initialized
INFO - 2025-09-06 10:29:26 --> Output Class Initialized
INFO - 2025-09-06 10:29:26 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:26 --> Input Class Initialized
INFO - 2025-09-06 10:29:26 --> Language Class Initialized
INFO - 2025-09-06 10:29:26 --> Loader Class Initialized
INFO - 2025-09-06 10:29:26 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:26 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:26 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:26 --> Controller Class Initialized
INFO - 2025-09-06 10:29:26 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:26 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:26 --> Total execution time: 0.1543
INFO - 2025-09-06 10:29:26 --> Config Class Initialized
INFO - 2025-09-06 10:29:26 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:26 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:26 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:26 --> URI Class Initialized
INFO - 2025-09-06 10:29:26 --> Router Class Initialized
INFO - 2025-09-06 10:29:26 --> Output Class Initialized
INFO - 2025-09-06 10:29:26 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:26 --> Input Class Initialized
INFO - 2025-09-06 10:29:26 --> Language Class Initialized
INFO - 2025-09-06 10:29:26 --> Loader Class Initialized
INFO - 2025-09-06 10:29:26 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:26 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:26 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:26 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:26 --> Controller Class Initialized
INFO - 2025-09-06 10:29:26 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:26 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:26 --> Total execution time: 0.1082
INFO - 2025-09-06 10:29:28 --> Config Class Initialized
INFO - 2025-09-06 10:29:28 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:28 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:28 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:28 --> URI Class Initialized
INFO - 2025-09-06 10:29:28 --> Router Class Initialized
INFO - 2025-09-06 10:29:28 --> Output Class Initialized
INFO - 2025-09-06 10:29:28 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:28 --> Input Class Initialized
INFO - 2025-09-06 10:29:28 --> Language Class Initialized
INFO - 2025-09-06 10:29:28 --> Loader Class Initialized
INFO - 2025-09-06 10:29:28 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:28 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:28 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:28 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:28 --> Controller Class Initialized
INFO - 2025-09-06 10:29:28 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:28 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:28 --> Total execution time: 0.1074
INFO - 2025-09-06 10:29:42 --> Config Class Initialized
INFO - 2025-09-06 10:29:42 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:42 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:42 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:42 --> Config Class Initialized
INFO - 2025-09-06 10:29:42 --> URI Class Initialized
INFO - 2025-09-06 10:29:42 --> Hooks Class Initialized
INFO - 2025-09-06 10:29:42 --> Router Class Initialized
DEBUG - 2025-09-06 10:29:42 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:42 --> Output Class Initialized
INFO - 2025-09-06 10:29:42 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:42 --> Security Class Initialized
INFO - 2025-09-06 10:29:42 --> URI Class Initialized
INFO - 2025-09-06 10:29:42 --> Router Class Initialized
DEBUG - 2025-09-06 10:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:42 --> Input Class Initialized
INFO - 2025-09-06 10:29:42 --> Output Class Initialized
INFO - 2025-09-06 10:29:42 --> Language Class Initialized
INFO - 2025-09-06 10:29:42 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:42 --> Input Class Initialized
INFO - 2025-09-06 10:29:42 --> Loader Class Initialized
INFO - 2025-09-06 10:29:42 --> Language Class Initialized
INFO - 2025-09-06 10:29:42 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:42 --> Loader Class Initialized
INFO - 2025-09-06 10:29:42 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:42 --> Database Driver Class Initialized
INFO - 2025-09-06 10:29:42 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-06 10:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:42 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:42 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:42 --> Controller Class Initialized
INFO - 2025-09-06 10:29:42 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:42 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:42 --> Total execution time: 0.1926
INFO - 2025-09-06 10:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:42 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:42 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:42 --> Controller Class Initialized
INFO - 2025-09-06 10:29:42 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:42 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:42 --> Total execution time: 0.1848
INFO - 2025-09-06 10:29:43 --> Config Class Initialized
INFO - 2025-09-06 10:29:43 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:29:43 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:29:43 --> Utf8 Class Initialized
INFO - 2025-09-06 10:29:43 --> URI Class Initialized
INFO - 2025-09-06 10:29:43 --> Router Class Initialized
INFO - 2025-09-06 10:29:43 --> Output Class Initialized
INFO - 2025-09-06 10:29:43 --> Security Class Initialized
DEBUG - 2025-09-06 10:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:29:43 --> Input Class Initialized
INFO - 2025-09-06 10:29:43 --> Language Class Initialized
INFO - 2025-09-06 10:29:43 --> Loader Class Initialized
INFO - 2025-09-06 10:29:43 --> Helper loaded: url_helper
INFO - 2025-09-06 10:29:43 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:29:43 --> Helper loaded: form_helper
INFO - 2025-09-06 10:29:43 --> Form Validation Class Initialized
INFO - 2025-09-06 10:29:43 --> Controller Class Initialized
INFO - 2025-09-06 10:29:43 --> Model "Center_model" initialized
INFO - 2025-09-06 10:29:43 --> Final output sent to browser
DEBUG - 2025-09-06 10:29:43 --> Total execution time: 0.1462
INFO - 2025-09-06 10:30:18 --> Config Class Initialized
INFO - 2025-09-06 10:30:18 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:18 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:18 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:18 --> URI Class Initialized
INFO - 2025-09-06 10:30:18 --> Router Class Initialized
INFO - 2025-09-06 10:30:18 --> Output Class Initialized
INFO - 2025-09-06 10:30:18 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:18 --> Input Class Initialized
INFO - 2025-09-06 10:30:18 --> Language Class Initialized
INFO - 2025-09-06 10:30:18 --> Loader Class Initialized
INFO - 2025-09-06 10:30:18 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:18 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:18 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:18 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:18 --> Controller Class Initialized
INFO - 2025-09-06 10:30:18 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:30:18 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:30:18 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:30:18 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:18 --> Total execution time: 0.1242
INFO - 2025-09-06 10:30:18 --> Config Class Initialized
INFO - 2025-09-06 10:30:18 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:18 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:18 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:18 --> URI Class Initialized
INFO - 2025-09-06 10:30:18 --> Router Class Initialized
INFO - 2025-09-06 10:30:18 --> Output Class Initialized
INFO - 2025-09-06 10:30:18 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:18 --> Input Class Initialized
INFO - 2025-09-06 10:30:18 --> Language Class Initialized
INFO - 2025-09-06 10:30:18 --> Loader Class Initialized
INFO - 2025-09-06 10:30:18 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:18 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:18 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:18 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:18 --> Controller Class Initialized
INFO - 2025-09-06 10:30:18 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:18 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:18 --> Total execution time: 0.1480
INFO - 2025-09-06 10:30:41 --> Config Class Initialized
INFO - 2025-09-06 10:30:41 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:41 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:41 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:41 --> URI Class Initialized
INFO - 2025-09-06 10:30:41 --> Router Class Initialized
INFO - 2025-09-06 10:30:41 --> Output Class Initialized
INFO - 2025-09-06 10:30:41 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:41 --> Input Class Initialized
INFO - 2025-09-06 10:30:41 --> Language Class Initialized
INFO - 2025-09-06 10:30:41 --> Loader Class Initialized
INFO - 2025-09-06 10:30:41 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:41 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:41 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:41 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:41 --> Controller Class Initialized
INFO - 2025-09-06 10:30:41 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:30:41 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:30:41 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:30:41 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:41 --> Total execution time: 0.1234
INFO - 2025-09-06 10:30:41 --> Config Class Initialized
INFO - 2025-09-06 10:30:41 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:41 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:41 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:41 --> URI Class Initialized
INFO - 2025-09-06 10:30:41 --> Router Class Initialized
INFO - 2025-09-06 10:30:41 --> Output Class Initialized
INFO - 2025-09-06 10:30:41 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:41 --> Input Class Initialized
INFO - 2025-09-06 10:30:41 --> Language Class Initialized
INFO - 2025-09-06 10:30:41 --> Loader Class Initialized
INFO - 2025-09-06 10:30:41 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:41 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:41 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:41 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:41 --> Controller Class Initialized
INFO - 2025-09-06 10:30:41 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:41 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:41 --> Total execution time: 0.1098
INFO - 2025-09-06 10:30:41 --> Config Class Initialized
INFO - 2025-09-06 10:30:41 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:41 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:41 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:41 --> URI Class Initialized
INFO - 2025-09-06 10:30:41 --> Router Class Initialized
INFO - 2025-09-06 10:30:41 --> Output Class Initialized
INFO - 2025-09-06 10:30:41 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:41 --> Input Class Initialized
INFO - 2025-09-06 10:30:41 --> Language Class Initialized
INFO - 2025-09-06 10:30:41 --> Loader Class Initialized
INFO - 2025-09-06 10:30:41 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:41 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:41 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:41 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:41 --> Controller Class Initialized
INFO - 2025-09-06 10:30:41 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:41 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:41 --> Total execution time: 0.0878
INFO - 2025-09-06 10:30:43 --> Config Class Initialized
INFO - 2025-09-06 10:30:43 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:43 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:43 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:43 --> URI Class Initialized
INFO - 2025-09-06 10:30:43 --> Router Class Initialized
INFO - 2025-09-06 10:30:43 --> Output Class Initialized
INFO - 2025-09-06 10:30:43 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:43 --> Input Class Initialized
INFO - 2025-09-06 10:30:43 --> Language Class Initialized
INFO - 2025-09-06 10:30:43 --> Loader Class Initialized
INFO - 2025-09-06 10:30:43 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:43 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:43 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:43 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:43 --> Controller Class Initialized
INFO - 2025-09-06 10:30:43 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:43 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:43 --> Total execution time: 0.1469
INFO - 2025-09-06 10:30:45 --> Config Class Initialized
INFO - 2025-09-06 10:30:45 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:45 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:45 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:45 --> URI Class Initialized
INFO - 2025-09-06 10:30:45 --> Router Class Initialized
INFO - 2025-09-06 10:30:45 --> Output Class Initialized
INFO - 2025-09-06 10:30:45 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:45 --> Input Class Initialized
INFO - 2025-09-06 10:30:45 --> Language Class Initialized
INFO - 2025-09-06 10:30:45 --> Loader Class Initialized
INFO - 2025-09-06 10:30:45 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:45 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:45 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:45 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:45 --> Controller Class Initialized
INFO - 2025-09-06 10:30:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:30:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:30:45 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:30:45 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:45 --> Total execution time: 0.1255
INFO - 2025-09-06 10:30:45 --> Config Class Initialized
INFO - 2025-09-06 10:30:45 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:45 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:45 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:45 --> URI Class Initialized
INFO - 2025-09-06 10:30:45 --> Router Class Initialized
INFO - 2025-09-06 10:30:45 --> Output Class Initialized
INFO - 2025-09-06 10:30:45 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:45 --> Input Class Initialized
INFO - 2025-09-06 10:30:45 --> Language Class Initialized
INFO - 2025-09-06 10:30:45 --> Loader Class Initialized
INFO - 2025-09-06 10:30:45 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:45 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:45 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:45 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:45 --> Controller Class Initialized
INFO - 2025-09-06 10:30:45 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:45 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:45 --> Total execution time: 0.1396
INFO - 2025-09-06 10:30:47 --> Config Class Initialized
INFO - 2025-09-06 10:30:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:47 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:47 --> URI Class Initialized
INFO - 2025-09-06 10:30:47 --> Router Class Initialized
INFO - 2025-09-06 10:30:47 --> Output Class Initialized
INFO - 2025-09-06 10:30:47 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:47 --> Input Class Initialized
INFO - 2025-09-06 10:30:47 --> Language Class Initialized
INFO - 2025-09-06 10:30:47 --> Loader Class Initialized
INFO - 2025-09-06 10:30:47 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:47 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:47 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:47 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:47 --> Controller Class Initialized
INFO - 2025-09-06 10:30:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:30:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:30:47 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:30:47 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:47 --> Total execution time: 0.1186
INFO - 2025-09-06 10:30:48 --> Config Class Initialized
INFO - 2025-09-06 10:30:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:48 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:48 --> URI Class Initialized
INFO - 2025-09-06 10:30:48 --> Router Class Initialized
INFO - 2025-09-06 10:30:48 --> Output Class Initialized
INFO - 2025-09-06 10:30:48 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:48 --> Input Class Initialized
INFO - 2025-09-06 10:30:48 --> Language Class Initialized
INFO - 2025-09-06 10:30:48 --> Loader Class Initialized
INFO - 2025-09-06 10:30:48 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:48 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:48 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:48 --> Controller Class Initialized
INFO - 2025-09-06 10:30:48 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:48 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:48 --> Total execution time: 0.1023
INFO - 2025-09-06 10:30:48 --> Config Class Initialized
INFO - 2025-09-06 10:30:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:48 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:48 --> URI Class Initialized
INFO - 2025-09-06 10:30:48 --> Router Class Initialized
INFO - 2025-09-06 10:30:48 --> Output Class Initialized
INFO - 2025-09-06 10:30:48 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:48 --> Input Class Initialized
INFO - 2025-09-06 10:30:48 --> Language Class Initialized
INFO - 2025-09-06 10:30:48 --> Loader Class Initialized
INFO - 2025-09-06 10:30:48 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:48 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:48 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:48 --> Controller Class Initialized
INFO - 2025-09-06 10:30:48 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:48 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:48 --> Total execution time: 0.0899
INFO - 2025-09-06 10:30:49 --> Config Class Initialized
INFO - 2025-09-06 10:30:49 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:49 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:49 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:49 --> URI Class Initialized
INFO - 2025-09-06 10:30:49 --> Router Class Initialized
INFO - 2025-09-06 10:30:49 --> Output Class Initialized
INFO - 2025-09-06 10:30:49 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:49 --> Input Class Initialized
INFO - 2025-09-06 10:30:49 --> Language Class Initialized
INFO - 2025-09-06 10:30:49 --> Loader Class Initialized
INFO - 2025-09-06 10:30:49 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:49 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:49 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:49 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:49 --> Controller Class Initialized
INFO - 2025-09-06 10:30:49 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:49 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:49 --> Total execution time: 0.1433
INFO - 2025-09-06 10:30:51 --> Config Class Initialized
INFO - 2025-09-06 10:30:51 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:51 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:51 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:51 --> URI Class Initialized
INFO - 2025-09-06 10:30:51 --> Router Class Initialized
INFO - 2025-09-06 10:30:51 --> Output Class Initialized
INFO - 2025-09-06 10:30:51 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:51 --> Input Class Initialized
INFO - 2025-09-06 10:30:51 --> Language Class Initialized
INFO - 2025-09-06 10:30:51 --> Loader Class Initialized
INFO - 2025-09-06 10:30:51 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:51 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:51 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:51 --> Controller Class Initialized
INFO - 2025-09-06 10:30:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:30:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:30:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:30:51 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:51 --> Total execution time: 0.1327
INFO - 2025-09-06 10:30:51 --> Config Class Initialized
INFO - 2025-09-06 10:30:51 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:51 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:51 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:51 --> URI Class Initialized
INFO - 2025-09-06 10:30:51 --> Router Class Initialized
INFO - 2025-09-06 10:30:51 --> Output Class Initialized
INFO - 2025-09-06 10:30:51 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:51 --> Input Class Initialized
INFO - 2025-09-06 10:30:51 --> Language Class Initialized
INFO - 2025-09-06 10:30:51 --> Loader Class Initialized
INFO - 2025-09-06 10:30:51 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:51 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:51 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:51 --> Controller Class Initialized
INFO - 2025-09-06 10:30:51 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:51 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:51 --> Total execution time: 0.1365
INFO - 2025-09-06 10:30:53 --> Config Class Initialized
INFO - 2025-09-06 10:30:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:53 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:53 --> URI Class Initialized
INFO - 2025-09-06 10:30:53 --> Router Class Initialized
INFO - 2025-09-06 10:30:53 --> Output Class Initialized
INFO - 2025-09-06 10:30:53 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:53 --> Input Class Initialized
INFO - 2025-09-06 10:30:53 --> Language Class Initialized
INFO - 2025-09-06 10:30:53 --> Loader Class Initialized
INFO - 2025-09-06 10:30:53 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:53 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:53 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:53 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:53 --> Controller Class Initialized
INFO - 2025-09-06 10:30:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:30:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:30:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 10:30:53 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:53 --> Total execution time: 0.1117
INFO - 2025-09-06 10:30:53 --> Config Class Initialized
INFO - 2025-09-06 10:30:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:53 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:53 --> URI Class Initialized
INFO - 2025-09-06 10:30:53 --> Router Class Initialized
INFO - 2025-09-06 10:30:53 --> Output Class Initialized
INFO - 2025-09-06 10:30:53 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:53 --> Input Class Initialized
INFO - 2025-09-06 10:30:53 --> Language Class Initialized
INFO - 2025-09-06 10:30:53 --> Loader Class Initialized
INFO - 2025-09-06 10:30:53 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:53 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:53 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:53 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:53 --> Controller Class Initialized
INFO - 2025-09-06 10:30:53 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:53 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:53 --> Total execution time: 0.1089
INFO - 2025-09-06 10:30:53 --> Config Class Initialized
INFO - 2025-09-06 10:30:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:53 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:53 --> URI Class Initialized
INFO - 2025-09-06 10:30:53 --> Router Class Initialized
INFO - 2025-09-06 10:30:53 --> Output Class Initialized
INFO - 2025-09-06 10:30:53 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:53 --> Input Class Initialized
INFO - 2025-09-06 10:30:53 --> Language Class Initialized
INFO - 2025-09-06 10:30:53 --> Loader Class Initialized
INFO - 2025-09-06 10:30:53 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:53 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:53 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:53 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:53 --> Controller Class Initialized
INFO - 2025-09-06 10:30:53 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:53 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:53 --> Total execution time: 0.0874
INFO - 2025-09-06 10:30:55 --> Config Class Initialized
INFO - 2025-09-06 10:30:55 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:30:55 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:30:55 --> Utf8 Class Initialized
INFO - 2025-09-06 10:30:55 --> URI Class Initialized
INFO - 2025-09-06 10:30:55 --> Router Class Initialized
INFO - 2025-09-06 10:30:55 --> Output Class Initialized
INFO - 2025-09-06 10:30:55 --> Security Class Initialized
DEBUG - 2025-09-06 10:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:30:55 --> Input Class Initialized
INFO - 2025-09-06 10:30:55 --> Language Class Initialized
INFO - 2025-09-06 10:30:55 --> Loader Class Initialized
INFO - 2025-09-06 10:30:55 --> Helper loaded: url_helper
INFO - 2025-09-06 10:30:55 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:30:55 --> Helper loaded: form_helper
INFO - 2025-09-06 10:30:55 --> Form Validation Class Initialized
INFO - 2025-09-06 10:30:55 --> Controller Class Initialized
INFO - 2025-09-06 10:30:55 --> Model "Center_model" initialized
INFO - 2025-09-06 10:30:55 --> Final output sent to browser
DEBUG - 2025-09-06 10:30:55 --> Total execution time: 0.1328
INFO - 2025-09-06 10:31:10 --> Config Class Initialized
INFO - 2025-09-06 10:31:10 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:31:10 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:31:10 --> Utf8 Class Initialized
INFO - 2025-09-06 10:31:10 --> URI Class Initialized
INFO - 2025-09-06 10:31:10 --> Router Class Initialized
INFO - 2025-09-06 10:31:10 --> Output Class Initialized
INFO - 2025-09-06 10:31:10 --> Security Class Initialized
DEBUG - 2025-09-06 10:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:31:10 --> Input Class Initialized
INFO - 2025-09-06 10:31:10 --> Language Class Initialized
INFO - 2025-09-06 10:31:10 --> Loader Class Initialized
INFO - 2025-09-06 10:31:10 --> Helper loaded: url_helper
INFO - 2025-09-06 10:31:10 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:31:10 --> Helper loaded: form_helper
INFO - 2025-09-06 10:31:10 --> Form Validation Class Initialized
INFO - 2025-09-06 10:31:10 --> Controller Class Initialized
INFO - 2025-09-06 10:31:10 --> Model "Center_model" initialized
INFO - 2025-09-06 10:31:10 --> Final output sent to browser
DEBUG - 2025-09-06 10:31:10 --> Total execution time: 0.1316
INFO - 2025-09-06 10:31:23 --> Config Class Initialized
INFO - 2025-09-06 10:31:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:31:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:31:23 --> Utf8 Class Initialized
INFO - 2025-09-06 10:31:23 --> URI Class Initialized
INFO - 2025-09-06 10:31:23 --> Router Class Initialized
INFO - 2025-09-06 10:31:23 --> Output Class Initialized
INFO - 2025-09-06 10:31:23 --> Security Class Initialized
DEBUG - 2025-09-06 10:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:31:23 --> Input Class Initialized
INFO - 2025-09-06 10:31:23 --> Language Class Initialized
INFO - 2025-09-06 10:31:23 --> Loader Class Initialized
INFO - 2025-09-06 10:31:23 --> Helper loaded: url_helper
INFO - 2025-09-06 10:31:23 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:31:23 --> Helper loaded: form_helper
INFO - 2025-09-06 10:31:23 --> Form Validation Class Initialized
INFO - 2025-09-06 10:31:23 --> Controller Class Initialized
INFO - 2025-09-06 10:31:23 --> Model "Center_model" initialized
INFO - 2025-09-06 10:31:23 --> Final output sent to browser
DEBUG - 2025-09-06 10:31:23 --> Total execution time: 0.1685
INFO - 2025-09-06 10:31:35 --> Config Class Initialized
INFO - 2025-09-06 10:31:35 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:31:35 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:31:35 --> Utf8 Class Initialized
INFO - 2025-09-06 10:31:35 --> URI Class Initialized
INFO - 2025-09-06 10:31:35 --> Router Class Initialized
INFO - 2025-09-06 10:31:35 --> Output Class Initialized
INFO - 2025-09-06 10:31:35 --> Security Class Initialized
DEBUG - 2025-09-06 10:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:31:35 --> Input Class Initialized
INFO - 2025-09-06 10:31:35 --> Language Class Initialized
INFO - 2025-09-06 10:31:35 --> Loader Class Initialized
INFO - 2025-09-06 10:31:35 --> Helper loaded: url_helper
INFO - 2025-09-06 10:31:35 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:31:35 --> Helper loaded: form_helper
INFO - 2025-09-06 10:31:35 --> Form Validation Class Initialized
INFO - 2025-09-06 10:31:35 --> Controller Class Initialized
INFO - 2025-09-06 10:31:35 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:31:35 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:31:35 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:31:35 --> Final output sent to browser
DEBUG - 2025-09-06 10:31:35 --> Total execution time: 0.1303
INFO - 2025-09-06 10:31:36 --> Config Class Initialized
INFO - 2025-09-06 10:31:36 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:31:36 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:31:36 --> Utf8 Class Initialized
INFO - 2025-09-06 10:31:36 --> URI Class Initialized
INFO - 2025-09-06 10:31:36 --> Router Class Initialized
INFO - 2025-09-06 10:31:36 --> Output Class Initialized
INFO - 2025-09-06 10:31:36 --> Security Class Initialized
DEBUG - 2025-09-06 10:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:31:36 --> Input Class Initialized
INFO - 2025-09-06 10:31:36 --> Language Class Initialized
INFO - 2025-09-06 10:31:36 --> Loader Class Initialized
INFO - 2025-09-06 10:31:36 --> Helper loaded: url_helper
INFO - 2025-09-06 10:31:36 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:31:36 --> Helper loaded: form_helper
INFO - 2025-09-06 10:31:36 --> Form Validation Class Initialized
INFO - 2025-09-06 10:31:36 --> Controller Class Initialized
INFO - 2025-09-06 10:31:36 --> Model "Center_model" initialized
INFO - 2025-09-06 10:31:36 --> Final output sent to browser
DEBUG - 2025-09-06 10:31:36 --> Total execution time: 0.1926
INFO - 2025-09-06 10:32:25 --> Config Class Initialized
INFO - 2025-09-06 10:32:25 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:32:25 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:32:25 --> Utf8 Class Initialized
INFO - 2025-09-06 10:32:25 --> URI Class Initialized
INFO - 2025-09-06 10:32:25 --> Router Class Initialized
INFO - 2025-09-06 10:32:25 --> Output Class Initialized
INFO - 2025-09-06 10:32:25 --> Security Class Initialized
DEBUG - 2025-09-06 10:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:32:25 --> Input Class Initialized
INFO - 2025-09-06 10:32:25 --> Language Class Initialized
INFO - 2025-09-06 10:32:25 --> Loader Class Initialized
INFO - 2025-09-06 10:32:25 --> Helper loaded: url_helper
INFO - 2025-09-06 10:32:25 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:32:25 --> Helper loaded: form_helper
INFO - 2025-09-06 10:32:25 --> Form Validation Class Initialized
INFO - 2025-09-06 10:32:25 --> Controller Class Initialized
INFO - 2025-09-06 10:32:25 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:32:25 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:32:25 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 10:32:25 --> Final output sent to browser
DEBUG - 2025-09-06 10:32:25 --> Total execution time: 0.1421
INFO - 2025-09-06 10:32:25 --> Config Class Initialized
INFO - 2025-09-06 10:32:25 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:32:25 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:32:25 --> Utf8 Class Initialized
INFO - 2025-09-06 10:32:25 --> URI Class Initialized
INFO - 2025-09-06 10:32:25 --> Router Class Initialized
INFO - 2025-09-06 10:32:25 --> Output Class Initialized
INFO - 2025-09-06 10:32:25 --> Security Class Initialized
DEBUG - 2025-09-06 10:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:32:25 --> Input Class Initialized
INFO - 2025-09-06 10:32:25 --> Language Class Initialized
INFO - 2025-09-06 10:32:25 --> Loader Class Initialized
INFO - 2025-09-06 10:32:25 --> Helper loaded: url_helper
INFO - 2025-09-06 10:32:25 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:32:25 --> Helper loaded: form_helper
INFO - 2025-09-06 10:32:25 --> Form Validation Class Initialized
INFO - 2025-09-06 10:32:25 --> Controller Class Initialized
INFO - 2025-09-06 10:32:25 --> Model "Center_model" initialized
INFO - 2025-09-06 10:32:25 --> Final output sent to browser
DEBUG - 2025-09-06 10:32:25 --> Total execution time: 0.1210
INFO - 2025-09-06 10:32:30 --> Config Class Initialized
INFO - 2025-09-06 10:32:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:32:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:32:30 --> Utf8 Class Initialized
INFO - 2025-09-06 10:32:30 --> URI Class Initialized
INFO - 2025-09-06 10:32:30 --> Router Class Initialized
INFO - 2025-09-06 10:32:30 --> Output Class Initialized
INFO - 2025-09-06 10:32:30 --> Security Class Initialized
DEBUG - 2025-09-06 10:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:32:30 --> Input Class Initialized
INFO - 2025-09-06 10:32:30 --> Language Class Initialized
INFO - 2025-09-06 10:32:30 --> Loader Class Initialized
INFO - 2025-09-06 10:32:30 --> Helper loaded: url_helper
INFO - 2025-09-06 10:32:31 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:32:31 --> Helper loaded: form_helper
INFO - 2025-09-06 10:32:31 --> Form Validation Class Initialized
INFO - 2025-09-06 10:32:31 --> Controller Class Initialized
INFO - 2025-09-06 10:32:31 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 10:32:31 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 10:32:31 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 10:32:31 --> Final output sent to browser
DEBUG - 2025-09-06 10:32:31 --> Total execution time: 0.1411
INFO - 2025-09-06 10:32:31 --> Config Class Initialized
INFO - 2025-09-06 10:32:31 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:32:31 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:32:31 --> Utf8 Class Initialized
INFO - 2025-09-06 10:32:31 --> URI Class Initialized
INFO - 2025-09-06 10:32:31 --> Router Class Initialized
INFO - 2025-09-06 10:32:31 --> Output Class Initialized
INFO - 2025-09-06 10:32:31 --> Security Class Initialized
DEBUG - 2025-09-06 10:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:32:31 --> Input Class Initialized
INFO - 2025-09-06 10:32:31 --> Language Class Initialized
INFO - 2025-09-06 10:32:31 --> Loader Class Initialized
INFO - 2025-09-06 10:32:31 --> Helper loaded: url_helper
INFO - 2025-09-06 10:32:31 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:32:31 --> Helper loaded: form_helper
INFO - 2025-09-06 10:32:31 --> Form Validation Class Initialized
INFO - 2025-09-06 10:32:31 --> Controller Class Initialized
INFO - 2025-09-06 10:32:31 --> Model "Center_model" initialized
INFO - 2025-09-06 10:32:31 --> Final output sent to browser
DEBUG - 2025-09-06 10:32:31 --> Total execution time: 0.1140
INFO - 2025-09-06 10:33:23 --> Config Class Initialized
INFO - 2025-09-06 10:33:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 10:33:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 10:33:23 --> Utf8 Class Initialized
INFO - 2025-09-06 10:33:23 --> URI Class Initialized
INFO - 2025-09-06 10:33:23 --> Router Class Initialized
INFO - 2025-09-06 10:33:23 --> Output Class Initialized
INFO - 2025-09-06 10:33:23 --> Security Class Initialized
DEBUG - 2025-09-06 10:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 10:33:23 --> Input Class Initialized
INFO - 2025-09-06 10:33:23 --> Language Class Initialized
INFO - 2025-09-06 10:33:23 --> Loader Class Initialized
INFO - 2025-09-06 10:33:23 --> Helper loaded: url_helper
INFO - 2025-09-06 10:33:23 --> Database Driver Class Initialized
DEBUG - 2025-09-06 10:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 10:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 10:33:23 --> Helper loaded: form_helper
INFO - 2025-09-06 10:33:23 --> Form Validation Class Initialized
INFO - 2025-09-06 10:33:23 --> Controller Class Initialized
INFO - 2025-09-06 10:33:23 --> Model "Center_model" initialized
INFO - 2025-09-06 10:33:23 --> Final output sent to browser
DEBUG - 2025-09-06 10:33:23 --> Total execution time: 0.2176
INFO - 2025-09-06 11:26:12 --> Config Class Initialized
INFO - 2025-09-06 11:26:12 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:12 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:12 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:12 --> URI Class Initialized
INFO - 2025-09-06 11:26:12 --> Router Class Initialized
INFO - 2025-09-06 11:26:12 --> Output Class Initialized
INFO - 2025-09-06 11:26:12 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:12 --> Input Class Initialized
INFO - 2025-09-06 11:26:12 --> Language Class Initialized
INFO - 2025-09-06 11:26:12 --> Loader Class Initialized
INFO - 2025-09-06 11:26:12 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:12 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:12 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:12 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:12 --> Controller Class Initialized
INFO - 2025-09-06 11:26:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:26:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
ERROR - 2025-09-06 11:26:12 --> Query error: Table 'mybadmintondb.centers' doesn't exist - Invalid query: SELECT *
FROM `centers`
INFO - 2025-09-06 11:26:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 11:26:16 --> Config Class Initialized
INFO - 2025-09-06 11:26:16 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:16 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:16 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:16 --> URI Class Initialized
INFO - 2025-09-06 11:26:16 --> Router Class Initialized
INFO - 2025-09-06 11:26:16 --> Output Class Initialized
INFO - 2025-09-06 11:26:16 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:16 --> Input Class Initialized
INFO - 2025-09-06 11:26:16 --> Language Class Initialized
INFO - 2025-09-06 11:26:16 --> Loader Class Initialized
INFO - 2025-09-06 11:26:16 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:16 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:16 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:16 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:16 --> Controller Class Initialized
INFO - 2025-09-06 11:26:16 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:26:16 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:26:16 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:26:16 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:16 --> Total execution time: 0.1410
INFO - 2025-09-06 11:26:17 --> Config Class Initialized
INFO - 2025-09-06 11:26:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:17 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:17 --> URI Class Initialized
INFO - 2025-09-06 11:26:17 --> Router Class Initialized
INFO - 2025-09-06 11:26:17 --> Output Class Initialized
INFO - 2025-09-06 11:26:17 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:17 --> Input Class Initialized
INFO - 2025-09-06 11:26:17 --> Language Class Initialized
INFO - 2025-09-06 11:26:17 --> Loader Class Initialized
INFO - 2025-09-06 11:26:17 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:17 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:17 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:17 --> Controller Class Initialized
INFO - 2025-09-06 11:26:17 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:17 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:17 --> Total execution time: 0.1752
INFO - 2025-09-06 11:26:22 --> Config Class Initialized
INFO - 2025-09-06 11:26:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:22 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:22 --> URI Class Initialized
INFO - 2025-09-06 11:26:22 --> Router Class Initialized
INFO - 2025-09-06 11:26:22 --> Output Class Initialized
INFO - 2025-09-06 11:26:22 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:22 --> Input Class Initialized
INFO - 2025-09-06 11:26:22 --> Language Class Initialized
INFO - 2025-09-06 11:26:22 --> Loader Class Initialized
INFO - 2025-09-06 11:26:22 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:22 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:22 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:22 --> Controller Class Initialized
INFO - 2025-09-06 11:26:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:26:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:26:22 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:26:22 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:22 --> Total execution time: 0.1257
INFO - 2025-09-06 11:26:23 --> Config Class Initialized
INFO - 2025-09-06 11:26:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:23 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:23 --> URI Class Initialized
INFO - 2025-09-06 11:26:23 --> Router Class Initialized
INFO - 2025-09-06 11:26:23 --> Output Class Initialized
INFO - 2025-09-06 11:26:23 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:23 --> Input Class Initialized
INFO - 2025-09-06 11:26:23 --> Language Class Initialized
INFO - 2025-09-06 11:26:23 --> Loader Class Initialized
INFO - 2025-09-06 11:26:23 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:23 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:23 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:23 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:23 --> Controller Class Initialized
INFO - 2025-09-06 11:26:23 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:23 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:23 --> Total execution time: 0.1642
INFO - 2025-09-06 11:26:23 --> Config Class Initialized
INFO - 2025-09-06 11:26:23 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:23 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:23 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:23 --> URI Class Initialized
INFO - 2025-09-06 11:26:23 --> Router Class Initialized
INFO - 2025-09-06 11:26:23 --> Output Class Initialized
INFO - 2025-09-06 11:26:23 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:23 --> Input Class Initialized
INFO - 2025-09-06 11:26:23 --> Language Class Initialized
INFO - 2025-09-06 11:26:23 --> Loader Class Initialized
INFO - 2025-09-06 11:26:23 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:23 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:23 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:23 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:23 --> Controller Class Initialized
INFO - 2025-09-06 11:26:23 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:23 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:23 --> Total execution time: 0.0958
INFO - 2025-09-06 11:26:25 --> Config Class Initialized
INFO - 2025-09-06 11:26:25 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:25 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:25 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:25 --> URI Class Initialized
INFO - 2025-09-06 11:26:25 --> Router Class Initialized
INFO - 2025-09-06 11:26:25 --> Output Class Initialized
INFO - 2025-09-06 11:26:25 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:25 --> Input Class Initialized
INFO - 2025-09-06 11:26:25 --> Language Class Initialized
INFO - 2025-09-06 11:26:25 --> Loader Class Initialized
INFO - 2025-09-06 11:26:25 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:25 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:25 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:25 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:25 --> Controller Class Initialized
INFO - 2025-09-06 11:26:25 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:25 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:25 --> Total execution time: 0.1226
INFO - 2025-09-06 11:26:27 --> Config Class Initialized
INFO - 2025-09-06 11:26:27 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:27 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:27 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:27 --> URI Class Initialized
INFO - 2025-09-06 11:26:27 --> Router Class Initialized
INFO - 2025-09-06 11:26:27 --> Output Class Initialized
INFO - 2025-09-06 11:26:27 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:27 --> Input Class Initialized
INFO - 2025-09-06 11:26:27 --> Language Class Initialized
INFO - 2025-09-06 11:26:27 --> Loader Class Initialized
INFO - 2025-09-06 11:26:27 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:27 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:27 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:27 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:27 --> Controller Class Initialized
INFO - 2025-09-06 11:26:27 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:26:27 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:26:27 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:26:27 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:27 --> Total execution time: 0.1544
INFO - 2025-09-06 11:26:27 --> Config Class Initialized
INFO - 2025-09-06 11:26:27 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:27 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:27 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:27 --> URI Class Initialized
INFO - 2025-09-06 11:26:27 --> Router Class Initialized
INFO - 2025-09-06 11:26:27 --> Output Class Initialized
INFO - 2025-09-06 11:26:27 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:27 --> Input Class Initialized
INFO - 2025-09-06 11:26:27 --> Language Class Initialized
INFO - 2025-09-06 11:26:27 --> Loader Class Initialized
INFO - 2025-09-06 11:26:27 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:27 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:27 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:27 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:27 --> Controller Class Initialized
INFO - 2025-09-06 11:26:27 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:27 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:27 --> Total execution time: 0.1897
INFO - 2025-09-06 11:26:29 --> Config Class Initialized
INFO - 2025-09-06 11:26:29 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:29 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:29 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:29 --> URI Class Initialized
INFO - 2025-09-06 11:26:29 --> Router Class Initialized
INFO - 2025-09-06 11:26:29 --> Output Class Initialized
INFO - 2025-09-06 11:26:29 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:29 --> Input Class Initialized
INFO - 2025-09-06 11:26:29 --> Language Class Initialized
INFO - 2025-09-06 11:26:29 --> Loader Class Initialized
INFO - 2025-09-06 11:26:29 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:29 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:29 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:29 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:29 --> Controller Class Initialized
INFO - 2025-09-06 11:26:29 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:26:30 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:26:30 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:26:30 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:30 --> Total execution time: 0.2828
INFO - 2025-09-06 11:26:30 --> Config Class Initialized
INFO - 2025-09-06 11:26:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:30 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:30 --> URI Class Initialized
INFO - 2025-09-06 11:26:30 --> Router Class Initialized
INFO - 2025-09-06 11:26:30 --> Output Class Initialized
INFO - 2025-09-06 11:26:30 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:30 --> Input Class Initialized
INFO - 2025-09-06 11:26:30 --> Language Class Initialized
INFO - 2025-09-06 11:26:30 --> Loader Class Initialized
INFO - 2025-09-06 11:26:30 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:30 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:30 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:30 --> Controller Class Initialized
INFO - 2025-09-06 11:26:30 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:30 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:30 --> Total execution time: 0.2097
INFO - 2025-09-06 11:26:30 --> Config Class Initialized
INFO - 2025-09-06 11:26:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:30 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:30 --> URI Class Initialized
INFO - 2025-09-06 11:26:30 --> Router Class Initialized
INFO - 2025-09-06 11:26:30 --> Output Class Initialized
INFO - 2025-09-06 11:26:30 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:30 --> Input Class Initialized
INFO - 2025-09-06 11:26:30 --> Language Class Initialized
INFO - 2025-09-06 11:26:30 --> Loader Class Initialized
INFO - 2025-09-06 11:26:30 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:30 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:30 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:30 --> Controller Class Initialized
INFO - 2025-09-06 11:26:30 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:30 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:30 --> Total execution time: 0.1272
INFO - 2025-09-06 11:26:32 --> Config Class Initialized
INFO - 2025-09-06 11:26:32 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:32 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:32 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:32 --> URI Class Initialized
INFO - 2025-09-06 11:26:32 --> Router Class Initialized
INFO - 2025-09-06 11:26:32 --> Output Class Initialized
INFO - 2025-09-06 11:26:32 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:32 --> Input Class Initialized
INFO - 2025-09-06 11:26:32 --> Language Class Initialized
INFO - 2025-09-06 11:26:32 --> Loader Class Initialized
INFO - 2025-09-06 11:26:32 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:32 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:32 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:32 --> Controller Class Initialized
INFO - 2025-09-06 11:26:32 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:32 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:32 --> Total execution time: 0.1966
INFO - 2025-09-06 11:26:39 --> Config Class Initialized
INFO - 2025-09-06 11:26:39 --> Config Class Initialized
INFO - 2025-09-06 11:26:39 --> Hooks Class Initialized
INFO - 2025-09-06 11:26:39 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2025-09-06 11:26:39 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:39 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:39 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:39 --> URI Class Initialized
INFO - 2025-09-06 11:26:39 --> URI Class Initialized
INFO - 2025-09-06 11:26:39 --> Router Class Initialized
INFO - 2025-09-06 11:26:39 --> Router Class Initialized
INFO - 2025-09-06 11:26:39 --> Output Class Initialized
INFO - 2025-09-06 11:26:39 --> Output Class Initialized
INFO - 2025-09-06 11:26:39 --> Security Class Initialized
INFO - 2025-09-06 11:26:39 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-06 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:39 --> Input Class Initialized
INFO - 2025-09-06 11:26:39 --> Input Class Initialized
INFO - 2025-09-06 11:26:39 --> Language Class Initialized
INFO - 2025-09-06 11:26:39 --> Language Class Initialized
INFO - 2025-09-06 11:26:39 --> Loader Class Initialized
INFO - 2025-09-06 11:26:39 --> Loader Class Initialized
INFO - 2025-09-06 11:26:39 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:39 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:39 --> Database Driver Class Initialized
INFO - 2025-09-06 11:26:39 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-06 11:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:39 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:39 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:39 --> Controller Class Initialized
INFO - 2025-09-06 11:26:39 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:39 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:39 --> Total execution time: 0.3577
INFO - 2025-09-06 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:39 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:39 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:39 --> Controller Class Initialized
INFO - 2025-09-06 11:26:39 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:39 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:39 --> Total execution time: 0.3953
INFO - 2025-09-06 11:26:41 --> Config Class Initialized
INFO - 2025-09-06 11:26:41 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:26:41 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:26:41 --> Utf8 Class Initialized
INFO - 2025-09-06 11:26:41 --> URI Class Initialized
INFO - 2025-09-06 11:26:41 --> Router Class Initialized
INFO - 2025-09-06 11:26:41 --> Output Class Initialized
INFO - 2025-09-06 11:26:41 --> Security Class Initialized
DEBUG - 2025-09-06 11:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:26:41 --> Input Class Initialized
INFO - 2025-09-06 11:26:41 --> Language Class Initialized
INFO - 2025-09-06 11:26:41 --> Loader Class Initialized
INFO - 2025-09-06 11:26:41 --> Helper loaded: url_helper
INFO - 2025-09-06 11:26:41 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:26:41 --> Helper loaded: form_helper
INFO - 2025-09-06 11:26:41 --> Form Validation Class Initialized
INFO - 2025-09-06 11:26:41 --> Controller Class Initialized
INFO - 2025-09-06 11:26:41 --> Model "Center_model" initialized
INFO - 2025-09-06 11:26:41 --> Final output sent to browser
DEBUG - 2025-09-06 11:26:41 --> Total execution time: 0.1597
INFO - 2025-09-06 11:28:46 --> Config Class Initialized
INFO - 2025-09-06 11:28:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:28:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:28:46 --> Utf8 Class Initialized
INFO - 2025-09-06 11:28:46 --> URI Class Initialized
INFO - 2025-09-06 11:28:46 --> Router Class Initialized
INFO - 2025-09-06 11:28:46 --> Output Class Initialized
INFO - 2025-09-06 11:28:46 --> Security Class Initialized
DEBUG - 2025-09-06 11:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:28:46 --> Input Class Initialized
INFO - 2025-09-06 11:28:46 --> Language Class Initialized
INFO - 2025-09-06 11:28:46 --> Loader Class Initialized
INFO - 2025-09-06 11:28:46 --> Helper loaded: url_helper
INFO - 2025-09-06 11:28:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:28:46 --> Helper loaded: form_helper
INFO - 2025-09-06 11:28:46 --> Form Validation Class Initialized
INFO - 2025-09-06 11:28:46 --> Controller Class Initialized
INFO - 2025-09-06 11:28:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:28:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:28:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:28:46 --> Final output sent to browser
DEBUG - 2025-09-06 11:28:46 --> Total execution time: 0.1247
INFO - 2025-09-06 11:28:47 --> Config Class Initialized
INFO - 2025-09-06 11:28:47 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:28:47 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:28:47 --> Utf8 Class Initialized
INFO - 2025-09-06 11:28:47 --> URI Class Initialized
INFO - 2025-09-06 11:28:47 --> Router Class Initialized
INFO - 2025-09-06 11:28:47 --> Output Class Initialized
INFO - 2025-09-06 11:28:47 --> Security Class Initialized
DEBUG - 2025-09-06 11:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:28:47 --> Input Class Initialized
INFO - 2025-09-06 11:28:47 --> Language Class Initialized
ERROR - 2025-09-06 11:28:47 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\timersacademy-1\application\controllers\Center.php 646
INFO - 2025-09-06 11:28:51 --> Config Class Initialized
INFO - 2025-09-06 11:28:51 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:28:51 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:28:51 --> Utf8 Class Initialized
INFO - 2025-09-06 11:28:51 --> URI Class Initialized
INFO - 2025-09-06 11:28:51 --> Router Class Initialized
INFO - 2025-09-06 11:28:51 --> Output Class Initialized
INFO - 2025-09-06 11:28:51 --> Security Class Initialized
DEBUG - 2025-09-06 11:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:28:51 --> Input Class Initialized
INFO - 2025-09-06 11:28:51 --> Language Class Initialized
ERROR - 2025-09-06 11:28:51 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\timersacademy-1\application\controllers\Center.php 646
INFO - 2025-09-06 11:28:56 --> Config Class Initialized
INFO - 2025-09-06 11:28:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:28:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:28:56 --> Utf8 Class Initialized
INFO - 2025-09-06 11:28:56 --> URI Class Initialized
INFO - 2025-09-06 11:28:56 --> Router Class Initialized
INFO - 2025-09-06 11:28:56 --> Output Class Initialized
INFO - 2025-09-06 11:28:56 --> Security Class Initialized
DEBUG - 2025-09-06 11:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:28:56 --> Input Class Initialized
INFO - 2025-09-06 11:28:56 --> Language Class Initialized
INFO - 2025-09-06 11:28:56 --> Loader Class Initialized
INFO - 2025-09-06 11:28:56 --> Helper loaded: url_helper
INFO - 2025-09-06 11:28:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:28:56 --> Helper loaded: form_helper
INFO - 2025-09-06 11:28:56 --> Form Validation Class Initialized
INFO - 2025-09-06 11:28:56 --> Controller Class Initialized
INFO - 2025-09-06 11:28:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:28:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:28:56 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:28:56 --> Final output sent to browser
DEBUG - 2025-09-06 11:28:56 --> Total execution time: 0.1552
INFO - 2025-09-06 11:28:56 --> Config Class Initialized
INFO - 2025-09-06 11:28:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:28:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:28:56 --> Utf8 Class Initialized
INFO - 2025-09-06 11:28:56 --> URI Class Initialized
INFO - 2025-09-06 11:28:56 --> Router Class Initialized
INFO - 2025-09-06 11:28:56 --> Output Class Initialized
INFO - 2025-09-06 11:28:56 --> Security Class Initialized
DEBUG - 2025-09-06 11:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:28:56 --> Input Class Initialized
INFO - 2025-09-06 11:28:56 --> Language Class Initialized
ERROR - 2025-09-06 11:28:56 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\timersacademy-1\application\controllers\Center.php 646
INFO - 2025-09-06 11:29:15 --> Config Class Initialized
INFO - 2025-09-06 11:29:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:29:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:29:15 --> Utf8 Class Initialized
INFO - 2025-09-06 11:29:15 --> URI Class Initialized
INFO - 2025-09-06 11:29:15 --> Router Class Initialized
INFO - 2025-09-06 11:29:15 --> Output Class Initialized
INFO - 2025-09-06 11:29:15 --> Security Class Initialized
DEBUG - 2025-09-06 11:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:29:15 --> Input Class Initialized
INFO - 2025-09-06 11:29:15 --> Language Class Initialized
INFO - 2025-09-06 11:29:15 --> Loader Class Initialized
INFO - 2025-09-06 11:29:15 --> Helper loaded: url_helper
INFO - 2025-09-06 11:29:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:29:15 --> Helper loaded: form_helper
INFO - 2025-09-06 11:29:15 --> Form Validation Class Initialized
INFO - 2025-09-06 11:29:15 --> Controller Class Initialized
INFO - 2025-09-06 11:29:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:29:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:29:15 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:29:15 --> Final output sent to browser
DEBUG - 2025-09-06 11:29:15 --> Total execution time: 0.1429
INFO - 2025-09-06 11:29:15 --> Config Class Initialized
INFO - 2025-09-06 11:29:15 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:29:15 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:29:15 --> Utf8 Class Initialized
INFO - 2025-09-06 11:29:15 --> URI Class Initialized
INFO - 2025-09-06 11:29:15 --> Router Class Initialized
INFO - 2025-09-06 11:29:15 --> Output Class Initialized
INFO - 2025-09-06 11:29:15 --> Security Class Initialized
DEBUG - 2025-09-06 11:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:29:15 --> Input Class Initialized
INFO - 2025-09-06 11:29:15 --> Language Class Initialized
INFO - 2025-09-06 11:29:15 --> Loader Class Initialized
INFO - 2025-09-06 11:29:15 --> Helper loaded: url_helper
INFO - 2025-09-06 11:29:15 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:29:15 --> Helper loaded: form_helper
INFO - 2025-09-06 11:29:15 --> Form Validation Class Initialized
INFO - 2025-09-06 11:29:15 --> Controller Class Initialized
INFO - 2025-09-06 11:29:15 --> Model "Center_model" initialized
INFO - 2025-09-06 11:29:15 --> Final output sent to browser
DEBUG - 2025-09-06 11:29:15 --> Total execution time: 0.1375
INFO - 2025-09-06 11:29:50 --> Config Class Initialized
INFO - 2025-09-06 11:29:50 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:29:50 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:29:50 --> Utf8 Class Initialized
INFO - 2025-09-06 11:29:50 --> URI Class Initialized
INFO - 2025-09-06 11:29:50 --> Router Class Initialized
INFO - 2025-09-06 11:29:50 --> Output Class Initialized
INFO - 2025-09-06 11:29:50 --> Security Class Initialized
DEBUG - 2025-09-06 11:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:29:50 --> Input Class Initialized
INFO - 2025-09-06 11:29:50 --> Language Class Initialized
INFO - 2025-09-06 11:29:50 --> Loader Class Initialized
INFO - 2025-09-06 11:29:50 --> Helper loaded: url_helper
INFO - 2025-09-06 11:29:50 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:29:50 --> Helper loaded: form_helper
INFO - 2025-09-06 11:29:50 --> Form Validation Class Initialized
INFO - 2025-09-06 11:29:50 --> Controller Class Initialized
INFO - 2025-09-06 11:29:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:29:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:29:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:29:50 --> Final output sent to browser
DEBUG - 2025-09-06 11:29:50 --> Total execution time: 0.1177
INFO - 2025-09-06 11:29:50 --> Config Class Initialized
INFO - 2025-09-06 11:29:50 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:29:50 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:29:50 --> Utf8 Class Initialized
INFO - 2025-09-06 11:29:50 --> URI Class Initialized
INFO - 2025-09-06 11:29:50 --> Router Class Initialized
INFO - 2025-09-06 11:29:50 --> Output Class Initialized
INFO - 2025-09-06 11:29:50 --> Security Class Initialized
DEBUG - 2025-09-06 11:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:29:50 --> Input Class Initialized
INFO - 2025-09-06 11:29:50 --> Language Class Initialized
INFO - 2025-09-06 11:29:50 --> Loader Class Initialized
INFO - 2025-09-06 11:29:50 --> Helper loaded: url_helper
INFO - 2025-09-06 11:29:50 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:29:50 --> Helper loaded: form_helper
INFO - 2025-09-06 11:29:50 --> Form Validation Class Initialized
INFO - 2025-09-06 11:29:50 --> Controller Class Initialized
INFO - 2025-09-06 11:29:50 --> Model "Center_model" initialized
INFO - 2025-09-06 11:29:50 --> Final output sent to browser
DEBUG - 2025-09-06 11:29:50 --> Total execution time: 0.1055
INFO - 2025-09-06 11:30:00 --> Config Class Initialized
INFO - 2025-09-06 11:30:00 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:00 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:00 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:00 --> URI Class Initialized
INFO - 2025-09-06 11:30:00 --> Router Class Initialized
INFO - 2025-09-06 11:30:00 --> Output Class Initialized
INFO - 2025-09-06 11:30:00 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:00 --> Input Class Initialized
INFO - 2025-09-06 11:30:00 --> Language Class Initialized
INFO - 2025-09-06 11:30:00 --> Loader Class Initialized
INFO - 2025-09-06 11:30:00 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:00 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:00 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:00 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:00 --> Controller Class Initialized
INFO - 2025-09-06 11:30:00 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:30:00 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:30:00 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:30:00 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:00 --> Total execution time: 0.1644
INFO - 2025-09-06 11:30:00 --> Config Class Initialized
INFO - 2025-09-06 11:30:00 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:00 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:00 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:00 --> URI Class Initialized
INFO - 2025-09-06 11:30:00 --> Router Class Initialized
INFO - 2025-09-06 11:30:00 --> Output Class Initialized
INFO - 2025-09-06 11:30:00 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:00 --> Input Class Initialized
INFO - 2025-09-06 11:30:00 --> Language Class Initialized
INFO - 2025-09-06 11:30:00 --> Loader Class Initialized
INFO - 2025-09-06 11:30:00 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:00 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:00 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:00 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:00 --> Controller Class Initialized
INFO - 2025-09-06 11:30:00 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:00 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:00 --> Total execution time: 0.1706
INFO - 2025-09-06 11:30:00 --> Config Class Initialized
INFO - 2025-09-06 11:30:00 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:00 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:00 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:00 --> URI Class Initialized
INFO - 2025-09-06 11:30:00 --> Router Class Initialized
INFO - 2025-09-06 11:30:00 --> Output Class Initialized
INFO - 2025-09-06 11:30:00 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:00 --> Input Class Initialized
INFO - 2025-09-06 11:30:00 --> Language Class Initialized
INFO - 2025-09-06 11:30:00 --> Loader Class Initialized
INFO - 2025-09-06 11:30:00 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:00 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:00 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:00 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:00 --> Controller Class Initialized
INFO - 2025-09-06 11:30:00 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:00 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:00 --> Total execution time: 0.1405
INFO - 2025-09-06 11:30:02 --> Config Class Initialized
INFO - 2025-09-06 11:30:02 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:02 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:02 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:02 --> URI Class Initialized
INFO - 2025-09-06 11:30:02 --> Router Class Initialized
INFO - 2025-09-06 11:30:02 --> Output Class Initialized
INFO - 2025-09-06 11:30:02 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:02 --> Input Class Initialized
INFO - 2025-09-06 11:30:02 --> Language Class Initialized
INFO - 2025-09-06 11:30:02 --> Loader Class Initialized
INFO - 2025-09-06 11:30:02 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:02 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:02 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:02 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:02 --> Controller Class Initialized
INFO - 2025-09-06 11:30:02 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:02 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:02 --> Total execution time: 0.1167
INFO - 2025-09-06 11:30:04 --> Config Class Initialized
INFO - 2025-09-06 11:30:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:04 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:04 --> URI Class Initialized
INFO - 2025-09-06 11:30:04 --> Router Class Initialized
INFO - 2025-09-06 11:30:04 --> Output Class Initialized
INFO - 2025-09-06 11:30:04 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:04 --> Input Class Initialized
INFO - 2025-09-06 11:30:04 --> Language Class Initialized
INFO - 2025-09-06 11:30:04 --> Loader Class Initialized
INFO - 2025-09-06 11:30:04 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:04 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:04 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:04 --> Controller Class Initialized
INFO - 2025-09-06 11:30:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:30:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:30:04 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:30:04 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:04 --> Total execution time: 0.1320
INFO - 2025-09-06 11:30:04 --> Config Class Initialized
INFO - 2025-09-06 11:30:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:04 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:04 --> URI Class Initialized
INFO - 2025-09-06 11:30:04 --> Router Class Initialized
INFO - 2025-09-06 11:30:04 --> Output Class Initialized
INFO - 2025-09-06 11:30:04 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:04 --> Input Class Initialized
INFO - 2025-09-06 11:30:04 --> Language Class Initialized
INFO - 2025-09-06 11:30:04 --> Loader Class Initialized
INFO - 2025-09-06 11:30:04 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:05 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:05 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:05 --> Controller Class Initialized
INFO - 2025-09-06 11:30:05 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:05 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:05 --> Total execution time: 0.1408
INFO - 2025-09-06 11:30:06 --> Config Class Initialized
INFO - 2025-09-06 11:30:06 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:06 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:06 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:06 --> URI Class Initialized
INFO - 2025-09-06 11:30:06 --> Router Class Initialized
INFO - 2025-09-06 11:30:06 --> Output Class Initialized
INFO - 2025-09-06 11:30:06 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:06 --> Input Class Initialized
INFO - 2025-09-06 11:30:06 --> Language Class Initialized
INFO - 2025-09-06 11:30:06 --> Loader Class Initialized
INFO - 2025-09-06 11:30:06 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:06 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:06 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:06 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:06 --> Controller Class Initialized
INFO - 2025-09-06 11:30:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:30:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:30:06 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:30:06 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:06 --> Total execution time: 0.1373
INFO - 2025-09-06 11:30:07 --> Config Class Initialized
INFO - 2025-09-06 11:30:07 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:07 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:07 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:07 --> URI Class Initialized
INFO - 2025-09-06 11:30:07 --> Router Class Initialized
INFO - 2025-09-06 11:30:07 --> Output Class Initialized
INFO - 2025-09-06 11:30:07 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:07 --> Input Class Initialized
INFO - 2025-09-06 11:30:07 --> Language Class Initialized
INFO - 2025-09-06 11:30:07 --> Loader Class Initialized
INFO - 2025-09-06 11:30:07 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:07 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:07 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:07 --> Controller Class Initialized
INFO - 2025-09-06 11:30:07 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:07 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:07 --> Total execution time: 0.1996
INFO - 2025-09-06 11:30:07 --> Config Class Initialized
INFO - 2025-09-06 11:30:07 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:07 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:07 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:07 --> URI Class Initialized
INFO - 2025-09-06 11:30:07 --> Router Class Initialized
INFO - 2025-09-06 11:30:07 --> Output Class Initialized
INFO - 2025-09-06 11:30:07 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:07 --> Input Class Initialized
INFO - 2025-09-06 11:30:07 --> Language Class Initialized
INFO - 2025-09-06 11:30:07 --> Loader Class Initialized
INFO - 2025-09-06 11:30:07 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:07 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:07 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:07 --> Controller Class Initialized
INFO - 2025-09-06 11:30:07 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:07 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:07 --> Total execution time: 0.1600
INFO - 2025-09-06 11:30:08 --> Config Class Initialized
INFO - 2025-09-06 11:30:08 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:08 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:08 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:08 --> URI Class Initialized
INFO - 2025-09-06 11:30:08 --> Router Class Initialized
INFO - 2025-09-06 11:30:08 --> Output Class Initialized
INFO - 2025-09-06 11:30:08 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:08 --> Input Class Initialized
INFO - 2025-09-06 11:30:08 --> Language Class Initialized
INFO - 2025-09-06 11:30:08 --> Loader Class Initialized
INFO - 2025-09-06 11:30:08 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:08 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:08 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:08 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:08 --> Controller Class Initialized
INFO - 2025-09-06 11:30:08 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:08 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:08 --> Total execution time: 0.1579
INFO - 2025-09-06 11:30:10 --> Config Class Initialized
INFO - 2025-09-06 11:30:10 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:10 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:10 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:10 --> URI Class Initialized
INFO - 2025-09-06 11:30:10 --> Router Class Initialized
INFO - 2025-09-06 11:30:10 --> Output Class Initialized
INFO - 2025-09-06 11:30:10 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:10 --> Input Class Initialized
INFO - 2025-09-06 11:30:10 --> Language Class Initialized
INFO - 2025-09-06 11:30:10 --> Loader Class Initialized
INFO - 2025-09-06 11:30:10 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:10 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:10 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:10 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:10 --> Controller Class Initialized
INFO - 2025-09-06 11:30:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:30:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:30:10 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:30:10 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:10 --> Total execution time: 0.1617
INFO - 2025-09-06 11:30:10 --> Config Class Initialized
INFO - 2025-09-06 11:30:10 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:10 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:10 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:10 --> URI Class Initialized
INFO - 2025-09-06 11:30:10 --> Router Class Initialized
INFO - 2025-09-06 11:30:10 --> Output Class Initialized
INFO - 2025-09-06 11:30:10 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:10 --> Input Class Initialized
INFO - 2025-09-06 11:30:10 --> Language Class Initialized
INFO - 2025-09-06 11:30:10 --> Loader Class Initialized
INFO - 2025-09-06 11:30:10 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:10 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:10 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:10 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:10 --> Controller Class Initialized
INFO - 2025-09-06 11:30:10 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:10 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:10 --> Total execution time: 0.2025
INFO - 2025-09-06 11:30:12 --> Config Class Initialized
INFO - 2025-09-06 11:30:12 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:12 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:12 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:12 --> URI Class Initialized
INFO - 2025-09-06 11:30:12 --> Router Class Initialized
INFO - 2025-09-06 11:30:12 --> Output Class Initialized
INFO - 2025-09-06 11:30:12 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:12 --> Input Class Initialized
INFO - 2025-09-06 11:30:12 --> Language Class Initialized
INFO - 2025-09-06 11:30:12 --> Loader Class Initialized
INFO - 2025-09-06 11:30:12 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:12 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:12 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:12 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:12 --> Controller Class Initialized
INFO - 2025-09-06 11:30:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:30:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:30:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:30:12 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:12 --> Total execution time: 0.1787
INFO - 2025-09-06 11:30:13 --> Config Class Initialized
INFO - 2025-09-06 11:30:13 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:13 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:13 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:13 --> URI Class Initialized
INFO - 2025-09-06 11:30:13 --> Router Class Initialized
INFO - 2025-09-06 11:30:13 --> Output Class Initialized
INFO - 2025-09-06 11:30:13 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:13 --> Input Class Initialized
INFO - 2025-09-06 11:30:13 --> Language Class Initialized
INFO - 2025-09-06 11:30:13 --> Loader Class Initialized
INFO - 2025-09-06 11:30:13 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:13 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:13 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:13 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:13 --> Controller Class Initialized
INFO - 2025-09-06 11:30:13 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:13 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:13 --> Total execution time: 0.1723
INFO - 2025-09-06 11:30:13 --> Config Class Initialized
INFO - 2025-09-06 11:30:13 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:13 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:13 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:13 --> URI Class Initialized
INFO - 2025-09-06 11:30:13 --> Router Class Initialized
INFO - 2025-09-06 11:30:13 --> Output Class Initialized
INFO - 2025-09-06 11:30:13 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:13 --> Input Class Initialized
INFO - 2025-09-06 11:30:13 --> Language Class Initialized
INFO - 2025-09-06 11:30:13 --> Loader Class Initialized
INFO - 2025-09-06 11:30:13 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:13 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:13 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:13 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:13 --> Controller Class Initialized
INFO - 2025-09-06 11:30:13 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:13 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:13 --> Total execution time: 0.2548
INFO - 2025-09-06 11:30:14 --> Config Class Initialized
INFO - 2025-09-06 11:30:14 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:14 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:14 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:14 --> URI Class Initialized
INFO - 2025-09-06 11:30:14 --> Router Class Initialized
INFO - 2025-09-06 11:30:14 --> Output Class Initialized
INFO - 2025-09-06 11:30:14 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:14 --> Input Class Initialized
INFO - 2025-09-06 11:30:14 --> Language Class Initialized
INFO - 2025-09-06 11:30:14 --> Loader Class Initialized
INFO - 2025-09-06 11:30:14 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:14 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:14 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:14 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:14 --> Controller Class Initialized
INFO - 2025-09-06 11:30:14 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:14 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:14 --> Total execution time: 0.1807
INFO - 2025-09-06 11:30:22 --> Config Class Initialized
INFO - 2025-09-06 11:30:22 --> Config Class Initialized
INFO - 2025-09-06 11:30:22 --> Hooks Class Initialized
INFO - 2025-09-06 11:30:22 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:30:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:22 --> Utf8 Class Initialized
DEBUG - 2025-09-06 11:30:22 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:30:22 --> Utf8 Class Initialized
INFO - 2025-09-06 11:30:22 --> URI Class Initialized
INFO - 2025-09-06 11:30:22 --> URI Class Initialized
INFO - 2025-09-06 11:30:22 --> Router Class Initialized
INFO - 2025-09-06 11:30:22 --> Router Class Initialized
INFO - 2025-09-06 11:30:22 --> Output Class Initialized
INFO - 2025-09-06 11:30:22 --> Output Class Initialized
INFO - 2025-09-06 11:30:22 --> Security Class Initialized
INFO - 2025-09-06 11:30:22 --> Security Class Initialized
DEBUG - 2025-09-06 11:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-09-06 11:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:30:22 --> Input Class Initialized
INFO - 2025-09-06 11:30:22 --> Input Class Initialized
INFO - 2025-09-06 11:30:22 --> Language Class Initialized
INFO - 2025-09-06 11:30:22 --> Language Class Initialized
INFO - 2025-09-06 11:30:22 --> Loader Class Initialized
INFO - 2025-09-06 11:30:22 --> Loader Class Initialized
INFO - 2025-09-06 11:30:22 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:22 --> Helper loaded: url_helper
INFO - 2025-09-06 11:30:22 --> Database Driver Class Initialized
INFO - 2025-09-06 11:30:22 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-09-06 11:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:30:22 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:22 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:22 --> Controller Class Initialized
INFO - 2025-09-06 11:30:22 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:22 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:22 --> Total execution time: 0.1489
INFO - 2025-09-06 11:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:30:22 --> Helper loaded: form_helper
INFO - 2025-09-06 11:30:22 --> Form Validation Class Initialized
INFO - 2025-09-06 11:30:22 --> Controller Class Initialized
INFO - 2025-09-06 11:30:22 --> Model "Center_model" initialized
INFO - 2025-09-06 11:30:23 --> Final output sent to browser
DEBUG - 2025-09-06 11:30:23 --> Total execution time: 0.1896
INFO - 2025-09-06 11:35:37 --> Config Class Initialized
INFO - 2025-09-06 11:35:37 --> Hooks Class Initialized
INFO - 2025-09-06 11:35:37 --> Config Class Initialized
INFO - 2025-09-06 11:35:37 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:37 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:37 --> Utf8 Class Initialized
DEBUG - 2025-09-06 11:35:37 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:37 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:37 --> URI Class Initialized
INFO - 2025-09-06 11:35:37 --> URI Class Initialized
INFO - 2025-09-06 11:35:37 --> Router Class Initialized
INFO - 2025-09-06 11:35:37 --> Router Class Initialized
INFO - 2025-09-06 11:35:37 --> Output Class Initialized
INFO - 2025-09-06 11:35:37 --> Output Class Initialized
INFO - 2025-09-06 11:35:37 --> Security Class Initialized
INFO - 2025-09-06 11:35:37 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:37 --> Input Class Initialized
DEBUG - 2025-09-06 11:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:37 --> Input Class Initialized
INFO - 2025-09-06 11:35:37 --> Language Class Initialized
INFO - 2025-09-06 11:35:37 --> Language Class Initialized
INFO - 2025-09-06 11:35:37 --> Loader Class Initialized
INFO - 2025-09-06 11:35:37 --> Loader Class Initialized
INFO - 2025-09-06 11:35:37 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:37 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:37 --> Database Driver Class Initialized
INFO - 2025-09-06 11:35:37 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-09-06 11:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:37 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:37 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:37 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:37 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:37 --> Controller Class Initialized
INFO - 2025-09-06 11:35:37 --> Controller Class Initialized
INFO - 2025-09-06 11:35:37 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:35:37 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:37 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:35:37 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:35:37 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:37 --> Total execution time: 0.1678
INFO - 2025-09-06 11:35:37 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:37 --> Total execution time: 0.1699
INFO - 2025-09-06 11:35:38 --> Config Class Initialized
INFO - 2025-09-06 11:35:38 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:38 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:38 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:38 --> URI Class Initialized
INFO - 2025-09-06 11:35:38 --> Router Class Initialized
INFO - 2025-09-06 11:35:38 --> Output Class Initialized
INFO - 2025-09-06 11:35:38 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:38 --> Input Class Initialized
INFO - 2025-09-06 11:35:38 --> Language Class Initialized
INFO - 2025-09-06 11:35:38 --> Loader Class Initialized
INFO - 2025-09-06 11:35:38 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:38 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:38 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:38 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:38 --> Controller Class Initialized
INFO - 2025-09-06 11:35:38 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:38 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:38 --> Total execution time: 0.1205
INFO - 2025-09-06 11:35:38 --> Config Class Initialized
INFO - 2025-09-06 11:35:38 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:38 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:38 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:38 --> URI Class Initialized
INFO - 2025-09-06 11:35:38 --> Router Class Initialized
INFO - 2025-09-06 11:35:38 --> Output Class Initialized
INFO - 2025-09-06 11:35:38 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:38 --> Input Class Initialized
INFO - 2025-09-06 11:35:38 --> Language Class Initialized
INFO - 2025-09-06 11:35:38 --> Loader Class Initialized
INFO - 2025-09-06 11:35:38 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:38 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:38 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:38 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:38 --> Controller Class Initialized
INFO - 2025-09-06 11:35:38 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:38 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:38 --> Total execution time: 0.3077
INFO - 2025-09-06 11:35:41 --> Config Class Initialized
INFO - 2025-09-06 11:35:41 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:41 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:41 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:41 --> URI Class Initialized
INFO - 2025-09-06 11:35:41 --> Router Class Initialized
INFO - 2025-09-06 11:35:41 --> Output Class Initialized
INFO - 2025-09-06 11:35:41 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:41 --> Input Class Initialized
INFO - 2025-09-06 11:35:41 --> Language Class Initialized
INFO - 2025-09-06 11:35:41 --> Loader Class Initialized
INFO - 2025-09-06 11:35:41 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:41 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:41 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:41 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:41 --> Controller Class Initialized
INFO - 2025-09-06 11:35:41 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:41 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:41 --> Total execution time: 0.1230
INFO - 2025-09-06 11:35:43 --> Config Class Initialized
INFO - 2025-09-06 11:35:43 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:43 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:43 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:43 --> URI Class Initialized
INFO - 2025-09-06 11:35:43 --> Router Class Initialized
INFO - 2025-09-06 11:35:43 --> Output Class Initialized
INFO - 2025-09-06 11:35:43 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:43 --> Input Class Initialized
INFO - 2025-09-06 11:35:43 --> Language Class Initialized
INFO - 2025-09-06 11:35:43 --> Loader Class Initialized
INFO - 2025-09-06 11:35:43 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:43 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:43 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:43 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:43 --> Controller Class Initialized
INFO - 2025-09-06 11:35:43 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:35:43 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:35:43 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:35:43 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:43 --> Total execution time: 0.1028
INFO - 2025-09-06 11:35:43 --> Config Class Initialized
INFO - 2025-09-06 11:35:43 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:43 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:43 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:43 --> URI Class Initialized
INFO - 2025-09-06 11:35:43 --> Router Class Initialized
INFO - 2025-09-06 11:35:43 --> Output Class Initialized
INFO - 2025-09-06 11:35:43 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:43 --> Input Class Initialized
INFO - 2025-09-06 11:35:43 --> Language Class Initialized
INFO - 2025-09-06 11:35:43 --> Loader Class Initialized
INFO - 2025-09-06 11:35:43 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:43 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:43 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:43 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:43 --> Controller Class Initialized
INFO - 2025-09-06 11:35:43 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:43 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:43 --> Total execution time: 0.1134
INFO - 2025-09-06 11:35:46 --> Config Class Initialized
INFO - 2025-09-06 11:35:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:46 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:46 --> URI Class Initialized
INFO - 2025-09-06 11:35:46 --> Router Class Initialized
INFO - 2025-09-06 11:35:46 --> Output Class Initialized
INFO - 2025-09-06 11:35:46 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:46 --> Input Class Initialized
INFO - 2025-09-06 11:35:46 --> Language Class Initialized
INFO - 2025-09-06 11:35:46 --> Loader Class Initialized
INFO - 2025-09-06 11:35:46 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:46 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:46 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:46 --> Controller Class Initialized
INFO - 2025-09-06 11:35:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:35:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:35:46 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:35:46 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:46 --> Total execution time: 0.1165
INFO - 2025-09-06 11:35:46 --> Config Class Initialized
INFO - 2025-09-06 11:35:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:46 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:46 --> URI Class Initialized
INFO - 2025-09-06 11:35:46 --> Router Class Initialized
INFO - 2025-09-06 11:35:46 --> Output Class Initialized
INFO - 2025-09-06 11:35:46 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:46 --> Input Class Initialized
INFO - 2025-09-06 11:35:46 --> Language Class Initialized
INFO - 2025-09-06 11:35:46 --> Loader Class Initialized
INFO - 2025-09-06 11:35:46 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:46 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:46 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:46 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:46 --> Controller Class Initialized
INFO - 2025-09-06 11:35:46 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:46 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:46 --> Total execution time: 0.1275
INFO - 2025-09-06 11:35:46 --> Config Class Initialized
INFO - 2025-09-06 11:35:46 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:46 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:46 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:46 --> URI Class Initialized
INFO - 2025-09-06 11:35:47 --> Router Class Initialized
INFO - 2025-09-06 11:35:47 --> Output Class Initialized
INFO - 2025-09-06 11:35:47 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:47 --> Input Class Initialized
INFO - 2025-09-06 11:35:47 --> Language Class Initialized
INFO - 2025-09-06 11:35:47 --> Loader Class Initialized
INFO - 2025-09-06 11:35:47 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:47 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:47 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:47 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:47 --> Controller Class Initialized
INFO - 2025-09-06 11:35:47 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:47 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:47 --> Total execution time: 0.0931
INFO - 2025-09-06 11:35:49 --> Config Class Initialized
INFO - 2025-09-06 11:35:49 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:49 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:49 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:49 --> URI Class Initialized
INFO - 2025-09-06 11:35:49 --> Router Class Initialized
INFO - 2025-09-06 11:35:49 --> Output Class Initialized
INFO - 2025-09-06 11:35:49 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:49 --> Input Class Initialized
INFO - 2025-09-06 11:35:49 --> Language Class Initialized
INFO - 2025-09-06 11:35:49 --> Loader Class Initialized
INFO - 2025-09-06 11:35:49 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:49 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:49 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:49 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:49 --> Controller Class Initialized
INFO - 2025-09-06 11:35:49 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:49 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:49 --> Total execution time: 0.1112
INFO - 2025-09-06 11:35:50 --> Config Class Initialized
INFO - 2025-09-06 11:35:50 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:50 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:50 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:50 --> URI Class Initialized
INFO - 2025-09-06 11:35:50 --> Router Class Initialized
INFO - 2025-09-06 11:35:51 --> Output Class Initialized
INFO - 2025-09-06 11:35:51 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:51 --> Input Class Initialized
INFO - 2025-09-06 11:35:51 --> Language Class Initialized
INFO - 2025-09-06 11:35:51 --> Loader Class Initialized
INFO - 2025-09-06 11:35:51 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:51 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:51 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:51 --> Controller Class Initialized
INFO - 2025-09-06 11:35:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:35:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:35:51 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:35:51 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:51 --> Total execution time: 0.1020
INFO - 2025-09-06 11:35:51 --> Config Class Initialized
INFO - 2025-09-06 11:35:51 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:51 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:51 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:51 --> URI Class Initialized
INFO - 2025-09-06 11:35:51 --> Router Class Initialized
INFO - 2025-09-06 11:35:51 --> Output Class Initialized
INFO - 2025-09-06 11:35:51 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:51 --> Input Class Initialized
INFO - 2025-09-06 11:35:51 --> Language Class Initialized
INFO - 2025-09-06 11:35:51 --> Loader Class Initialized
INFO - 2025-09-06 11:35:51 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:51 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:51 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:51 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:51 --> Controller Class Initialized
INFO - 2025-09-06 11:35:51 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:51 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:51 --> Total execution time: 0.0978
INFO - 2025-09-06 11:35:54 --> Config Class Initialized
INFO - 2025-09-06 11:35:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:54 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:54 --> URI Class Initialized
INFO - 2025-09-06 11:35:54 --> Router Class Initialized
INFO - 2025-09-06 11:35:54 --> Output Class Initialized
INFO - 2025-09-06 11:35:54 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:54 --> Input Class Initialized
INFO - 2025-09-06 11:35:54 --> Language Class Initialized
INFO - 2025-09-06 11:35:54 --> Loader Class Initialized
INFO - 2025-09-06 11:35:54 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:54 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:54 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:54 --> Controller Class Initialized
INFO - 2025-09-06 11:35:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:35:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:35:54 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/view_center_details.php
INFO - 2025-09-06 11:35:54 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:54 --> Total execution time: 0.1225
INFO - 2025-09-06 11:35:54 --> Config Class Initialized
INFO - 2025-09-06 11:35:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:54 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:54 --> URI Class Initialized
INFO - 2025-09-06 11:35:54 --> Router Class Initialized
INFO - 2025-09-06 11:35:54 --> Output Class Initialized
INFO - 2025-09-06 11:35:54 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:54 --> Input Class Initialized
INFO - 2025-09-06 11:35:54 --> Language Class Initialized
INFO - 2025-09-06 11:35:54 --> Loader Class Initialized
INFO - 2025-09-06 11:35:54 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:54 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:54 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:54 --> Controller Class Initialized
INFO - 2025-09-06 11:35:54 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:54 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:54 --> Total execution time: 0.1436
INFO - 2025-09-06 11:35:54 --> Config Class Initialized
INFO - 2025-09-06 11:35:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:54 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:54 --> URI Class Initialized
INFO - 2025-09-06 11:35:54 --> Router Class Initialized
INFO - 2025-09-06 11:35:54 --> Output Class Initialized
INFO - 2025-09-06 11:35:54 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:54 --> Input Class Initialized
INFO - 2025-09-06 11:35:54 --> Language Class Initialized
INFO - 2025-09-06 11:35:54 --> Loader Class Initialized
INFO - 2025-09-06 11:35:54 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:54 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:54 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:54 --> Controller Class Initialized
INFO - 2025-09-06 11:35:54 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:54 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:54 --> Total execution time: 0.0960
INFO - 2025-09-06 11:35:55 --> Config Class Initialized
INFO - 2025-09-06 11:35:55 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:55 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:55 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:55 --> URI Class Initialized
INFO - 2025-09-06 11:35:55 --> Router Class Initialized
INFO - 2025-09-06 11:35:55 --> Output Class Initialized
INFO - 2025-09-06 11:35:55 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:55 --> Input Class Initialized
INFO - 2025-09-06 11:35:55 --> Language Class Initialized
INFO - 2025-09-06 11:35:55 --> Loader Class Initialized
INFO - 2025-09-06 11:35:55 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:55 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:55 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:55 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:55 --> Controller Class Initialized
INFO - 2025-09-06 11:35:55 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:55 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:55 --> Total execution time: 0.1248
INFO - 2025-09-06 11:35:57 --> Config Class Initialized
INFO - 2025-09-06 11:35:57 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:35:57 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:35:57 --> Utf8 Class Initialized
INFO - 2025-09-06 11:35:57 --> URI Class Initialized
INFO - 2025-09-06 11:35:57 --> Router Class Initialized
INFO - 2025-09-06 11:35:57 --> Output Class Initialized
INFO - 2025-09-06 11:35:57 --> Security Class Initialized
DEBUG - 2025-09-06 11:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:35:57 --> Input Class Initialized
INFO - 2025-09-06 11:35:57 --> Language Class Initialized
INFO - 2025-09-06 11:35:57 --> Loader Class Initialized
INFO - 2025-09-06 11:35:57 --> Helper loaded: url_helper
INFO - 2025-09-06 11:35:57 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:35:57 --> Helper loaded: form_helper
INFO - 2025-09-06 11:35:57 --> Form Validation Class Initialized
INFO - 2025-09-06 11:35:57 --> Controller Class Initialized
INFO - 2025-09-06 11:35:57 --> Model "Center_model" initialized
INFO - 2025-09-06 11:35:57 --> Final output sent to browser
DEBUG - 2025-09-06 11:35:57 --> Total execution time: 0.1226
INFO - 2025-09-06 11:48:52 --> Config Class Initialized
INFO - 2025-09-06 11:48:52 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:48:52 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:48:52 --> Utf8 Class Initialized
INFO - 2025-09-06 11:48:52 --> URI Class Initialized
INFO - 2025-09-06 11:48:52 --> Router Class Initialized
INFO - 2025-09-06 11:48:52 --> Output Class Initialized
INFO - 2025-09-06 11:48:52 --> Security Class Initialized
DEBUG - 2025-09-06 11:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:48:52 --> Input Class Initialized
INFO - 2025-09-06 11:48:52 --> Language Class Initialized
INFO - 2025-09-06 11:48:52 --> Loader Class Initialized
INFO - 2025-09-06 11:48:52 --> Helper loaded: url_helper
INFO - 2025-09-06 11:48:52 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:48:52 --> Helper loaded: form_helper
INFO - 2025-09-06 11:48:52 --> Form Validation Class Initialized
INFO - 2025-09-06 11:48:52 --> Controller Class Initialized
INFO - 2025-09-06 11:48:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:48:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:48:52 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 11:48:52 --> Final output sent to browser
DEBUG - 2025-09-06 11:48:52 --> Total execution time: 0.1301
INFO - 2025-09-06 11:48:52 --> Config Class Initialized
INFO - 2025-09-06 11:48:52 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:48:52 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:48:52 --> Utf8 Class Initialized
INFO - 2025-09-06 11:48:52 --> URI Class Initialized
INFO - 2025-09-06 11:48:52 --> Router Class Initialized
INFO - 2025-09-06 11:48:52 --> Output Class Initialized
INFO - 2025-09-06 11:48:52 --> Security Class Initialized
DEBUG - 2025-09-06 11:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:48:52 --> Input Class Initialized
INFO - 2025-09-06 11:48:52 --> Language Class Initialized
INFO - 2025-09-06 11:48:52 --> Loader Class Initialized
INFO - 2025-09-06 11:48:52 --> Helper loaded: url_helper
INFO - 2025-09-06 11:48:52 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:48:52 --> Helper loaded: form_helper
INFO - 2025-09-06 11:48:52 --> Form Validation Class Initialized
INFO - 2025-09-06 11:48:52 --> Controller Class Initialized
INFO - 2025-09-06 11:48:52 --> Model "Center_model" initialized
INFO - 2025-09-06 11:48:52 --> Final output sent to browser
DEBUG - 2025-09-06 11:48:52 --> Total execution time: 0.1110
INFO - 2025-09-06 11:48:55 --> Config Class Initialized
INFO - 2025-09-06 11:48:55 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:48:55 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:48:55 --> Utf8 Class Initialized
INFO - 2025-09-06 11:48:55 --> URI Class Initialized
INFO - 2025-09-06 11:48:55 --> Router Class Initialized
INFO - 2025-09-06 11:48:55 --> Output Class Initialized
INFO - 2025-09-06 11:48:55 --> Security Class Initialized
DEBUG - 2025-09-06 11:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:48:55 --> Input Class Initialized
INFO - 2025-09-06 11:48:55 --> Language Class Initialized
INFO - 2025-09-06 11:48:55 --> Loader Class Initialized
INFO - 2025-09-06 11:48:55 --> Helper loaded: url_helper
INFO - 2025-09-06 11:48:55 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:48:55 --> Helper loaded: form_helper
INFO - 2025-09-06 11:48:55 --> Form Validation Class Initialized
INFO - 2025-09-06 11:48:55 --> Controller Class Initialized
INFO - 2025-09-06 11:48:55 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 11:48:55 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 11:48:55 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 11:48:55 --> Final output sent to browser
DEBUG - 2025-09-06 11:48:55 --> Total execution time: 0.1188
INFO - 2025-09-06 11:48:56 --> Config Class Initialized
INFO - 2025-09-06 11:48:56 --> Hooks Class Initialized
DEBUG - 2025-09-06 11:48:56 --> UTF-8 Support Enabled
INFO - 2025-09-06 11:48:56 --> Utf8 Class Initialized
INFO - 2025-09-06 11:48:56 --> URI Class Initialized
INFO - 2025-09-06 11:48:56 --> Router Class Initialized
INFO - 2025-09-06 11:48:56 --> Output Class Initialized
INFO - 2025-09-06 11:48:56 --> Security Class Initialized
DEBUG - 2025-09-06 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 11:48:56 --> Input Class Initialized
INFO - 2025-09-06 11:48:56 --> Language Class Initialized
INFO - 2025-09-06 11:48:56 --> Loader Class Initialized
INFO - 2025-09-06 11:48:56 --> Helper loaded: url_helper
INFO - 2025-09-06 11:48:56 --> Database Driver Class Initialized
DEBUG - 2025-09-06 11:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 11:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 11:48:56 --> Helper loaded: form_helper
INFO - 2025-09-06 11:48:56 --> Form Validation Class Initialized
INFO - 2025-09-06 11:48:56 --> Controller Class Initialized
INFO - 2025-09-06 11:48:56 --> Model "Center_model" initialized
INFO - 2025-09-06 11:48:56 --> Final output sent to browser
DEBUG - 2025-09-06 11:48:56 --> Total execution time: 0.1337
INFO - 2025-09-06 15:56:49 --> Config Class Initialized
INFO - 2025-09-06 15:56:49 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:56:49 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:56:49 --> Utf8 Class Initialized
INFO - 2025-09-06 15:56:49 --> URI Class Initialized
INFO - 2025-09-06 15:56:49 --> Router Class Initialized
INFO - 2025-09-06 15:56:49 --> Output Class Initialized
INFO - 2025-09-06 15:56:50 --> Security Class Initialized
DEBUG - 2025-09-06 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:56:50 --> Input Class Initialized
INFO - 2025-09-06 15:56:50 --> Language Class Initialized
INFO - 2025-09-06 15:56:50 --> Loader Class Initialized
INFO - 2025-09-06 15:56:50 --> Helper loaded: url_helper
INFO - 2025-09-06 15:56:50 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:56:50 --> Helper loaded: form_helper
INFO - 2025-09-06 15:56:50 --> Form Validation Class Initialized
INFO - 2025-09-06 15:56:50 --> Controller Class Initialized
INFO - 2025-09-06 15:56:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:56:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:56:50 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 15:56:50 --> Final output sent to browser
DEBUG - 2025-09-06 15:56:50 --> Total execution time: 0.3841
INFO - 2025-09-06 15:56:50 --> Config Class Initialized
INFO - 2025-09-06 15:56:50 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:56:50 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:56:50 --> Utf8 Class Initialized
INFO - 2025-09-06 15:56:50 --> URI Class Initialized
INFO - 2025-09-06 15:56:50 --> Router Class Initialized
INFO - 2025-09-06 15:56:50 --> Output Class Initialized
INFO - 2025-09-06 15:56:50 --> Security Class Initialized
DEBUG - 2025-09-06 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:56:50 --> Input Class Initialized
INFO - 2025-09-06 15:56:50 --> Language Class Initialized
INFO - 2025-09-06 15:56:50 --> Loader Class Initialized
INFO - 2025-09-06 15:56:50 --> Helper loaded: url_helper
INFO - 2025-09-06 15:56:50 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:56:51 --> Helper loaded: form_helper
INFO - 2025-09-06 15:56:51 --> Form Validation Class Initialized
INFO - 2025-09-06 15:56:51 --> Controller Class Initialized
INFO - 2025-09-06 15:56:51 --> Model "Center_model" initialized
INFO - 2025-09-06 15:56:51 --> Final output sent to browser
DEBUG - 2025-09-06 15:56:51 --> Total execution time: 0.1778
INFO - 2025-09-06 15:57:20 --> Config Class Initialized
INFO - 2025-09-06 15:57:20 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:57:20 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:57:20 --> Utf8 Class Initialized
INFO - 2025-09-06 15:57:20 --> URI Class Initialized
INFO - 2025-09-06 15:57:20 --> Router Class Initialized
INFO - 2025-09-06 15:57:20 --> Output Class Initialized
INFO - 2025-09-06 15:57:20 --> Security Class Initialized
DEBUG - 2025-09-06 15:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:57:20 --> Input Class Initialized
INFO - 2025-09-06 15:57:20 --> Language Class Initialized
INFO - 2025-09-06 15:57:20 --> Loader Class Initialized
INFO - 2025-09-06 15:57:20 --> Helper loaded: url_helper
INFO - 2025-09-06 15:57:20 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:57:20 --> Helper loaded: form_helper
INFO - 2025-09-06 15:57:20 --> Form Validation Class Initialized
INFO - 2025-09-06 15:57:20 --> Controller Class Initialized
INFO - 2025-09-06 15:57:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:57:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
ERROR - 2025-09-06 15:57:20 --> Query error: Table 'mybadmintondb.centers' doesn't exist - Invalid query: SELECT *
FROM `centers`
INFO - 2025-09-06 15:57:20 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 15:57:20 --> Config Class Initialized
INFO - 2025-09-06 15:57:20 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:57:20 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:57:20 --> Utf8 Class Initialized
INFO - 2025-09-06 15:57:20 --> URI Class Initialized
INFO - 2025-09-06 15:57:20 --> Router Class Initialized
INFO - 2025-09-06 15:57:20 --> Output Class Initialized
INFO - 2025-09-06 15:57:20 --> Security Class Initialized
DEBUG - 2025-09-06 15:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:57:20 --> Input Class Initialized
INFO - 2025-09-06 15:57:20 --> Language Class Initialized
INFO - 2025-09-06 15:57:20 --> Loader Class Initialized
INFO - 2025-09-06 15:57:20 --> Helper loaded: url_helper
INFO - 2025-09-06 15:57:20 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:57:20 --> Helper loaded: form_helper
INFO - 2025-09-06 15:57:20 --> Form Validation Class Initialized
INFO - 2025-09-06 15:57:20 --> Controller Class Initialized
INFO - 2025-09-06 15:57:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:57:20 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
ERROR - 2025-09-06 15:57:20 --> Query error: Table 'mybadmintondb.centers' doesn't exist - Invalid query: SELECT *
FROM `centers`
INFO - 2025-09-06 15:57:20 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 15:57:30 --> Config Class Initialized
INFO - 2025-09-06 15:57:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:57:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:57:30 --> Utf8 Class Initialized
INFO - 2025-09-06 15:57:30 --> URI Class Initialized
INFO - 2025-09-06 15:57:30 --> Router Class Initialized
INFO - 2025-09-06 15:57:30 --> Output Class Initialized
INFO - 2025-09-06 15:57:30 --> Security Class Initialized
DEBUG - 2025-09-06 15:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:57:30 --> Input Class Initialized
INFO - 2025-09-06 15:57:30 --> Language Class Initialized
INFO - 2025-09-06 15:57:30 --> Loader Class Initialized
INFO - 2025-09-06 15:57:30 --> Helper loaded: url_helper
INFO - 2025-09-06 15:57:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:57:30 --> Helper loaded: form_helper
INFO - 2025-09-06 15:57:30 --> Form Validation Class Initialized
INFO - 2025-09-06 15:57:30 --> Controller Class Initialized
INFO - 2025-09-06 15:57:30 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:57:30 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:57:30 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 15:57:30 --> Final output sent to browser
DEBUG - 2025-09-06 15:57:30 --> Total execution time: 0.1336
INFO - 2025-09-06 15:57:30 --> Config Class Initialized
INFO - 2025-09-06 15:57:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:57:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:57:30 --> Utf8 Class Initialized
INFO - 2025-09-06 15:57:30 --> URI Class Initialized
INFO - 2025-09-06 15:57:30 --> Router Class Initialized
INFO - 2025-09-06 15:57:30 --> Output Class Initialized
INFO - 2025-09-06 15:57:30 --> Security Class Initialized
DEBUG - 2025-09-06 15:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:57:30 --> Input Class Initialized
INFO - 2025-09-06 15:57:30 --> Language Class Initialized
INFO - 2025-09-06 15:57:30 --> Loader Class Initialized
INFO - 2025-09-06 15:57:30 --> Helper loaded: url_helper
INFO - 2025-09-06 15:57:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:57:30 --> Helper loaded: form_helper
INFO - 2025-09-06 15:57:30 --> Form Validation Class Initialized
INFO - 2025-09-06 15:57:30 --> Controller Class Initialized
INFO - 2025-09-06 15:57:30 --> Model "Center_model" initialized
INFO - 2025-09-06 15:57:30 --> Final output sent to browser
DEBUG - 2025-09-06 15:57:30 --> Total execution time: 0.1407
INFO - 2025-09-06 15:57:32 --> Config Class Initialized
INFO - 2025-09-06 15:57:32 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:57:32 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:57:32 --> Utf8 Class Initialized
INFO - 2025-09-06 15:57:32 --> URI Class Initialized
INFO - 2025-09-06 15:57:32 --> Router Class Initialized
INFO - 2025-09-06 15:57:32 --> Output Class Initialized
INFO - 2025-09-06 15:57:32 --> Security Class Initialized
DEBUG - 2025-09-06 15:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:57:32 --> Input Class Initialized
INFO - 2025-09-06 15:57:32 --> Language Class Initialized
INFO - 2025-09-06 15:57:32 --> Loader Class Initialized
INFO - 2025-09-06 15:57:32 --> Helper loaded: url_helper
INFO - 2025-09-06 15:57:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:57:32 --> Helper loaded: form_helper
INFO - 2025-09-06 15:57:32 --> Form Validation Class Initialized
INFO - 2025-09-06 15:57:32 --> Controller Class Initialized
INFO - 2025-09-06 15:57:32 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:57:32 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
ERROR - 2025-09-06 15:57:32 --> Query error: Table 'mybadmintondb.centers' doesn't exist - Invalid query: SELECT *
FROM `centers`
INFO - 2025-09-06 15:57:32 --> Language file loaded: language/english/db_lang.php
INFO - 2025-09-06 15:57:40 --> Config Class Initialized
INFO - 2025-09-06 15:57:40 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:57:40 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:57:40 --> Utf8 Class Initialized
INFO - 2025-09-06 15:57:40 --> URI Class Initialized
INFO - 2025-09-06 15:57:40 --> Router Class Initialized
INFO - 2025-09-06 15:57:40 --> Output Class Initialized
INFO - 2025-09-06 15:57:40 --> Security Class Initialized
DEBUG - 2025-09-06 15:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:57:40 --> Input Class Initialized
INFO - 2025-09-06 15:57:40 --> Language Class Initialized
INFO - 2025-09-06 15:57:40 --> Loader Class Initialized
INFO - 2025-09-06 15:57:40 --> Helper loaded: url_helper
INFO - 2025-09-06 15:57:40 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:57:40 --> Helper loaded: form_helper
INFO - 2025-09-06 15:57:40 --> Form Validation Class Initialized
INFO - 2025-09-06 15:57:40 --> Controller Class Initialized
INFO - 2025-09-06 15:57:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:57:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:57:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Students.php
INFO - 2025-09-06 15:57:40 --> Final output sent to browser
DEBUG - 2025-09-06 15:57:40 --> Total execution time: 0.1282
INFO - 2025-09-06 15:57:40 --> Config Class Initialized
INFO - 2025-09-06 15:57:40 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:57:40 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:57:40 --> Utf8 Class Initialized
INFO - 2025-09-06 15:57:41 --> URI Class Initialized
INFO - 2025-09-06 15:57:41 --> Router Class Initialized
INFO - 2025-09-06 15:57:41 --> Output Class Initialized
INFO - 2025-09-06 15:57:41 --> Security Class Initialized
DEBUG - 2025-09-06 15:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:57:41 --> Input Class Initialized
INFO - 2025-09-06 15:57:41 --> Language Class Initialized
INFO - 2025-09-06 15:57:41 --> Loader Class Initialized
INFO - 2025-09-06 15:57:41 --> Helper loaded: url_helper
INFO - 2025-09-06 15:57:41 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:57:41 --> Helper loaded: form_helper
INFO - 2025-09-06 15:57:41 --> Form Validation Class Initialized
INFO - 2025-09-06 15:57:41 --> Controller Class Initialized
INFO - 2025-09-06 15:57:41 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:57:41 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:57:41 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Students.php
INFO - 2025-09-06 15:57:41 --> Final output sent to browser
DEBUG - 2025-09-06 15:57:41 --> Total execution time: 0.1188
INFO - 2025-09-06 15:58:05 --> Config Class Initialized
INFO - 2025-09-06 15:58:05 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:58:05 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:58:05 --> Utf8 Class Initialized
INFO - 2025-09-06 15:58:05 --> URI Class Initialized
INFO - 2025-09-06 15:58:05 --> Router Class Initialized
INFO - 2025-09-06 15:58:05 --> Output Class Initialized
INFO - 2025-09-06 15:58:05 --> Security Class Initialized
DEBUG - 2025-09-06 15:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:58:05 --> Input Class Initialized
INFO - 2025-09-06 15:58:05 --> Language Class Initialized
INFO - 2025-09-06 15:58:05 --> Loader Class Initialized
INFO - 2025-09-06 15:58:05 --> Helper loaded: url_helper
INFO - 2025-09-06 15:58:05 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:58:05 --> Helper loaded: form_helper
INFO - 2025-09-06 15:58:05 --> Form Validation Class Initialized
INFO - 2025-09-06 15:58:05 --> Controller Class Initialized
INFO - 2025-09-06 15:58:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:58:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:58:05 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/student_details.php
INFO - 2025-09-06 15:58:05 --> Final output sent to browser
DEBUG - 2025-09-06 15:58:05 --> Total execution time: 0.1362
INFO - 2025-09-06 15:58:37 --> Config Class Initialized
INFO - 2025-09-06 15:58:37 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:58:37 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:58:37 --> Utf8 Class Initialized
INFO - 2025-09-06 15:58:37 --> URI Class Initialized
INFO - 2025-09-06 15:58:37 --> Router Class Initialized
INFO - 2025-09-06 15:58:37 --> Output Class Initialized
INFO - 2025-09-06 15:58:37 --> Security Class Initialized
DEBUG - 2025-09-06 15:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:58:37 --> Input Class Initialized
INFO - 2025-09-06 15:58:37 --> Language Class Initialized
INFO - 2025-09-06 15:58:37 --> Loader Class Initialized
INFO - 2025-09-06 15:58:37 --> Helper loaded: url_helper
INFO - 2025-09-06 15:58:37 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:58:37 --> Helper loaded: form_helper
INFO - 2025-09-06 15:58:37 --> Form Validation Class Initialized
INFO - 2025-09-06 15:58:37 --> Controller Class Initialized
INFO - 2025-09-06 15:58:37 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:58:37 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:58:37 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Students.php
INFO - 2025-09-06 15:58:37 --> Final output sent to browser
DEBUG - 2025-09-06 15:58:37 --> Total execution time: 0.1246
INFO - 2025-09-06 15:58:40 --> Config Class Initialized
INFO - 2025-09-06 15:58:40 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:58:40 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:58:40 --> Utf8 Class Initialized
INFO - 2025-09-06 15:58:40 --> URI Class Initialized
INFO - 2025-09-06 15:58:40 --> Router Class Initialized
INFO - 2025-09-06 15:58:40 --> Output Class Initialized
INFO - 2025-09-06 15:58:40 --> Security Class Initialized
DEBUG - 2025-09-06 15:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:58:40 --> Input Class Initialized
INFO - 2025-09-06 15:58:40 --> Language Class Initialized
INFO - 2025-09-06 15:58:40 --> Loader Class Initialized
INFO - 2025-09-06 15:58:40 --> Helper loaded: url_helper
INFO - 2025-09-06 15:58:40 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:58:40 --> Helper loaded: form_helper
INFO - 2025-09-06 15:58:40 --> Form Validation Class Initialized
INFO - 2025-09-06 15:58:40 --> Controller Class Initialized
INFO - 2025-09-06 15:58:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:58:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:58:40 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/student_details.php
INFO - 2025-09-06 15:58:40 --> Final output sent to browser
DEBUG - 2025-09-06 15:58:40 --> Total execution time: 0.1283
INFO - 2025-09-06 15:59:12 --> Config Class Initialized
INFO - 2025-09-06 15:59:12 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:59:12 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:59:12 --> Utf8 Class Initialized
INFO - 2025-09-06 15:59:12 --> URI Class Initialized
INFO - 2025-09-06 15:59:12 --> Router Class Initialized
INFO - 2025-09-06 15:59:12 --> Output Class Initialized
INFO - 2025-09-06 15:59:12 --> Security Class Initialized
DEBUG - 2025-09-06 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:59:12 --> Input Class Initialized
INFO - 2025-09-06 15:59:12 --> Language Class Initialized
INFO - 2025-09-06 15:59:12 --> Loader Class Initialized
INFO - 2025-09-06 15:59:12 --> Helper loaded: url_helper
INFO - 2025-09-06 15:59:12 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:59:12 --> Helper loaded: form_helper
INFO - 2025-09-06 15:59:12 --> Form Validation Class Initialized
INFO - 2025-09-06 15:59:12 --> Controller Class Initialized
INFO - 2025-09-06 15:59:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:59:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:59:12 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 15:59:12 --> Final output sent to browser
DEBUG - 2025-09-06 15:59:12 --> Total execution time: 0.1043
INFO - 2025-09-06 15:59:12 --> Config Class Initialized
INFO - 2025-09-06 15:59:12 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:59:12 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:59:12 --> Utf8 Class Initialized
INFO - 2025-09-06 15:59:12 --> URI Class Initialized
INFO - 2025-09-06 15:59:12 --> Router Class Initialized
INFO - 2025-09-06 15:59:12 --> Output Class Initialized
INFO - 2025-09-06 15:59:12 --> Security Class Initialized
DEBUG - 2025-09-06 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:59:12 --> Input Class Initialized
INFO - 2025-09-06 15:59:12 --> Language Class Initialized
INFO - 2025-09-06 15:59:12 --> Loader Class Initialized
INFO - 2025-09-06 15:59:12 --> Helper loaded: url_helper
INFO - 2025-09-06 15:59:12 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:59:13 --> Helper loaded: form_helper
INFO - 2025-09-06 15:59:13 --> Form Validation Class Initialized
INFO - 2025-09-06 15:59:13 --> Controller Class Initialized
INFO - 2025-09-06 15:59:13 --> Model "Center_model" initialized
INFO - 2025-09-06 15:59:13 --> Final output sent to browser
DEBUG - 2025-09-06 15:59:13 --> Total execution time: 0.1705
INFO - 2025-09-06 15:59:17 --> Config Class Initialized
INFO - 2025-09-06 15:59:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:59:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:59:17 --> Utf8 Class Initialized
INFO - 2025-09-06 15:59:17 --> URI Class Initialized
INFO - 2025-09-06 15:59:17 --> Router Class Initialized
INFO - 2025-09-06 15:59:17 --> Output Class Initialized
INFO - 2025-09-06 15:59:17 --> Security Class Initialized
DEBUG - 2025-09-06 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:59:17 --> Input Class Initialized
INFO - 2025-09-06 15:59:17 --> Language Class Initialized
INFO - 2025-09-06 15:59:17 --> Loader Class Initialized
INFO - 2025-09-06 15:59:17 --> Helper loaded: url_helper
INFO - 2025-09-06 15:59:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:59:17 --> Helper loaded: form_helper
INFO - 2025-09-06 15:59:17 --> Form Validation Class Initialized
INFO - 2025-09-06 15:59:17 --> Controller Class Initialized
INFO - 2025-09-06 15:59:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 15:59:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 15:59:17 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 15:59:17 --> Final output sent to browser
DEBUG - 2025-09-06 15:59:17 --> Total execution time: 0.1325
INFO - 2025-09-06 15:59:17 --> Config Class Initialized
INFO - 2025-09-06 15:59:17 --> Hooks Class Initialized
DEBUG - 2025-09-06 15:59:17 --> UTF-8 Support Enabled
INFO - 2025-09-06 15:59:17 --> Utf8 Class Initialized
INFO - 2025-09-06 15:59:17 --> URI Class Initialized
INFO - 2025-09-06 15:59:17 --> Router Class Initialized
INFO - 2025-09-06 15:59:17 --> Output Class Initialized
INFO - 2025-09-06 15:59:17 --> Security Class Initialized
DEBUG - 2025-09-06 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 15:59:17 --> Input Class Initialized
INFO - 2025-09-06 15:59:17 --> Language Class Initialized
INFO - 2025-09-06 15:59:17 --> Loader Class Initialized
INFO - 2025-09-06 15:59:17 --> Helper loaded: url_helper
INFO - 2025-09-06 15:59:17 --> Database Driver Class Initialized
DEBUG - 2025-09-06 15:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 15:59:17 --> Helper loaded: form_helper
INFO - 2025-09-06 15:59:17 --> Form Validation Class Initialized
INFO - 2025-09-06 15:59:17 --> Controller Class Initialized
INFO - 2025-09-06 15:59:17 --> Model "Center_model" initialized
INFO - 2025-09-06 15:59:17 --> Final output sent to browser
DEBUG - 2025-09-06 15:59:17 --> Total execution time: 0.1726
INFO - 2025-09-06 16:00:32 --> Config Class Initialized
INFO - 2025-09-06 16:00:32 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:00:32 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:00:32 --> Utf8 Class Initialized
INFO - 2025-09-06 16:00:32 --> URI Class Initialized
INFO - 2025-09-06 16:00:32 --> Router Class Initialized
INFO - 2025-09-06 16:00:32 --> Output Class Initialized
INFO - 2025-09-06 16:00:32 --> Security Class Initialized
DEBUG - 2025-09-06 16:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:00:32 --> Input Class Initialized
INFO - 2025-09-06 16:00:32 --> Language Class Initialized
INFO - 2025-09-06 16:00:32 --> Loader Class Initialized
INFO - 2025-09-06 16:00:32 --> Helper loaded: url_helper
INFO - 2025-09-06 16:00:32 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:00:32 --> Helper loaded: form_helper
INFO - 2025-09-06 16:00:32 --> Form Validation Class Initialized
INFO - 2025-09-06 16:00:32 --> Controller Class Initialized
INFO - 2025-09-06 16:00:32 --> Model "Center_model" initialized
INFO - 2025-09-06 16:00:32 --> Final output sent to browser
DEBUG - 2025-09-06 16:00:32 --> Total execution time: 0.2569
INFO - 2025-09-06 16:05:03 --> Config Class Initialized
INFO - 2025-09-06 16:05:03 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:05:03 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:05:03 --> Utf8 Class Initialized
INFO - 2025-09-06 16:05:03 --> URI Class Initialized
INFO - 2025-09-06 16:05:03 --> Router Class Initialized
INFO - 2025-09-06 16:05:03 --> Output Class Initialized
INFO - 2025-09-06 16:05:03 --> Security Class Initialized
DEBUG - 2025-09-06 16:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:05:03 --> Input Class Initialized
INFO - 2025-09-06 16:05:03 --> Language Class Initialized
INFO - 2025-09-06 16:05:03 --> Loader Class Initialized
INFO - 2025-09-06 16:05:03 --> Helper loaded: url_helper
INFO - 2025-09-06 16:05:03 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:05:03 --> Helper loaded: form_helper
INFO - 2025-09-06 16:05:03 --> Form Validation Class Initialized
INFO - 2025-09-06 16:05:03 --> Controller Class Initialized
INFO - 2025-09-06 16:05:03 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 16:05:03 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 16:05:03 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 16:05:03 --> Final output sent to browser
DEBUG - 2025-09-06 16:05:03 --> Total execution time: 0.1479
INFO - 2025-09-06 16:05:04 --> Config Class Initialized
INFO - 2025-09-06 16:05:04 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:05:04 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:05:04 --> Utf8 Class Initialized
INFO - 2025-09-06 16:05:04 --> URI Class Initialized
INFO - 2025-09-06 16:05:04 --> Router Class Initialized
INFO - 2025-09-06 16:05:04 --> Output Class Initialized
INFO - 2025-09-06 16:05:04 --> Security Class Initialized
DEBUG - 2025-09-06 16:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:05:04 --> Input Class Initialized
INFO - 2025-09-06 16:05:04 --> Language Class Initialized
INFO - 2025-09-06 16:05:04 --> Loader Class Initialized
INFO - 2025-09-06 16:05:04 --> Helper loaded: url_helper
INFO - 2025-09-06 16:05:04 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:05:04 --> Helper loaded: form_helper
INFO - 2025-09-06 16:05:04 --> Form Validation Class Initialized
INFO - 2025-09-06 16:05:04 --> Controller Class Initialized
INFO - 2025-09-06 16:05:04 --> Model "Center_model" initialized
INFO - 2025-09-06 16:05:04 --> Final output sent to browser
DEBUG - 2025-09-06 16:05:04 --> Total execution time: 0.1475
INFO - 2025-09-06 16:05:07 --> Config Class Initialized
INFO - 2025-09-06 16:05:07 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:05:07 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:05:07 --> Utf8 Class Initialized
INFO - 2025-09-06 16:05:07 --> URI Class Initialized
INFO - 2025-09-06 16:05:07 --> Router Class Initialized
INFO - 2025-09-06 16:05:07 --> Output Class Initialized
INFO - 2025-09-06 16:05:07 --> Security Class Initialized
DEBUG - 2025-09-06 16:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:05:07 --> Input Class Initialized
INFO - 2025-09-06 16:05:07 --> Language Class Initialized
INFO - 2025-09-06 16:05:07 --> Loader Class Initialized
INFO - 2025-09-06 16:05:07 --> Helper loaded: url_helper
INFO - 2025-09-06 16:05:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:05:07 --> Helper loaded: form_helper
INFO - 2025-09-06 16:05:07 --> Form Validation Class Initialized
INFO - 2025-09-06 16:05:07 --> Controller Class Initialized
INFO - 2025-09-06 16:05:07 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 16:05:07 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 16:05:07 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 16:05:07 --> Final output sent to browser
DEBUG - 2025-09-06 16:05:07 --> Total execution time: 0.1305
INFO - 2025-09-06 16:05:07 --> Config Class Initialized
INFO - 2025-09-06 16:05:07 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:05:07 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:05:07 --> Utf8 Class Initialized
INFO - 2025-09-06 16:05:07 --> URI Class Initialized
INFO - 2025-09-06 16:05:07 --> Router Class Initialized
INFO - 2025-09-06 16:05:07 --> Output Class Initialized
INFO - 2025-09-06 16:05:07 --> Security Class Initialized
DEBUG - 2025-09-06 16:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:05:07 --> Input Class Initialized
INFO - 2025-09-06 16:05:07 --> Language Class Initialized
INFO - 2025-09-06 16:05:07 --> Loader Class Initialized
INFO - 2025-09-06 16:05:07 --> Helper loaded: url_helper
INFO - 2025-09-06 16:05:07 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:05:08 --> Helper loaded: form_helper
INFO - 2025-09-06 16:05:08 --> Form Validation Class Initialized
INFO - 2025-09-06 16:05:08 --> Controller Class Initialized
INFO - 2025-09-06 16:05:08 --> Model "Center_model" initialized
INFO - 2025-09-06 16:05:08 --> Final output sent to browser
DEBUG - 2025-09-06 16:05:08 --> Total execution time: 0.1154
INFO - 2025-09-06 16:05:11 --> Config Class Initialized
INFO - 2025-09-06 16:05:11 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:05:11 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:05:11 --> Utf8 Class Initialized
INFO - 2025-09-06 16:05:11 --> URI Class Initialized
INFO - 2025-09-06 16:05:11 --> Router Class Initialized
INFO - 2025-09-06 16:05:11 --> Output Class Initialized
INFO - 2025-09-06 16:05:11 --> Security Class Initialized
DEBUG - 2025-09-06 16:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:05:11 --> Input Class Initialized
INFO - 2025-09-06 16:05:11 --> Language Class Initialized
INFO - 2025-09-06 16:05:11 --> Loader Class Initialized
INFO - 2025-09-06 16:05:11 --> Helper loaded: url_helper
INFO - 2025-09-06 16:05:11 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:05:11 --> Helper loaded: form_helper
INFO - 2025-09-06 16:05:11 --> Form Validation Class Initialized
INFO - 2025-09-06 16:05:11 --> Controller Class Initialized
INFO - 2025-09-06 16:05:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 16:05:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 16:05:11 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/CenterManagement2.php
INFO - 2025-09-06 16:05:11 --> Final output sent to browser
DEBUG - 2025-09-06 16:05:11 --> Total execution time: 0.1166
INFO - 2025-09-06 16:05:12 --> Config Class Initialized
INFO - 2025-09-06 16:05:12 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:05:12 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:05:12 --> Utf8 Class Initialized
INFO - 2025-09-06 16:05:12 --> URI Class Initialized
INFO - 2025-09-06 16:05:12 --> Router Class Initialized
INFO - 2025-09-06 16:05:12 --> Output Class Initialized
INFO - 2025-09-06 16:05:12 --> Security Class Initialized
DEBUG - 2025-09-06 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:05:12 --> Input Class Initialized
INFO - 2025-09-06 16:05:12 --> Language Class Initialized
INFO - 2025-09-06 16:05:12 --> Loader Class Initialized
INFO - 2025-09-06 16:05:12 --> Helper loaded: url_helper
INFO - 2025-09-06 16:05:12 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:05:12 --> Helper loaded: form_helper
INFO - 2025-09-06 16:05:12 --> Form Validation Class Initialized
INFO - 2025-09-06 16:05:12 --> Controller Class Initialized
INFO - 2025-09-06 16:05:12 --> Model "Center_model" initialized
INFO - 2025-09-06 16:05:12 --> Final output sent to browser
DEBUG - 2025-09-06 16:05:12 --> Total execution time: 0.1527
INFO - 2025-09-06 16:32:53 --> Config Class Initialized
INFO - 2025-09-06 16:32:53 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:32:53 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:32:53 --> Utf8 Class Initialized
INFO - 2025-09-06 16:32:53 --> URI Class Initialized
INFO - 2025-09-06 16:32:53 --> Router Class Initialized
INFO - 2025-09-06 16:32:53 --> Output Class Initialized
INFO - 2025-09-06 16:32:53 --> Security Class Initialized
DEBUG - 2025-09-06 16:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:32:53 --> Input Class Initialized
INFO - 2025-09-06 16:32:53 --> Language Class Initialized
INFO - 2025-09-06 16:32:53 --> Loader Class Initialized
INFO - 2025-09-06 16:32:53 --> Helper loaded: url_helper
INFO - 2025-09-06 16:32:53 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:32:53 --> Helper loaded: form_helper
INFO - 2025-09-06 16:32:53 --> Form Validation Class Initialized
INFO - 2025-09-06 16:32:53 --> Controller Class Initialized
INFO - 2025-09-06 16:32:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 16:32:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 16:32:53 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 16:32:53 --> Final output sent to browser
DEBUG - 2025-09-06 16:32:53 --> Total execution time: 0.1436
INFO - 2025-09-06 16:32:54 --> Config Class Initialized
INFO - 2025-09-06 16:32:54 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:32:54 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:32:54 --> Utf8 Class Initialized
INFO - 2025-09-06 16:32:54 --> URI Class Initialized
INFO - 2025-09-06 16:32:54 --> Router Class Initialized
INFO - 2025-09-06 16:32:54 --> Output Class Initialized
INFO - 2025-09-06 16:32:54 --> Security Class Initialized
DEBUG - 2025-09-06 16:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:32:54 --> Input Class Initialized
INFO - 2025-09-06 16:32:54 --> Language Class Initialized
INFO - 2025-09-06 16:32:54 --> Loader Class Initialized
INFO - 2025-09-06 16:32:54 --> Helper loaded: url_helper
INFO - 2025-09-06 16:32:54 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:32:54 --> Helper loaded: form_helper
INFO - 2025-09-06 16:32:54 --> Form Validation Class Initialized
INFO - 2025-09-06 16:32:54 --> Controller Class Initialized
INFO - 2025-09-06 16:32:54 --> Model "Center_model" initialized
INFO - 2025-09-06 16:32:54 --> Final output sent to browser
DEBUG - 2025-09-06 16:32:54 --> Total execution time: 0.1317
INFO - 2025-09-06 16:36:59 --> Config Class Initialized
INFO - 2025-09-06 16:36:59 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:36:59 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:36:59 --> Utf8 Class Initialized
INFO - 2025-09-06 16:36:59 --> URI Class Initialized
INFO - 2025-09-06 16:36:59 --> Router Class Initialized
INFO - 2025-09-06 16:36:59 --> Output Class Initialized
INFO - 2025-09-06 16:36:59 --> Security Class Initialized
DEBUG - 2025-09-06 16:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:36:59 --> Input Class Initialized
INFO - 2025-09-06 16:36:59 --> Language Class Initialized
INFO - 2025-09-06 16:36:59 --> Loader Class Initialized
INFO - 2025-09-06 16:36:59 --> Helper loaded: url_helper
INFO - 2025-09-06 16:36:59 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:36:59 --> Helper loaded: form_helper
INFO - 2025-09-06 16:36:59 --> Form Validation Class Initialized
INFO - 2025-09-06 16:36:59 --> Controller Class Initialized
INFO - 2025-09-06 16:36:59 --> Model "Center_model" initialized
INFO - 2025-09-06 16:37:00 --> Final output sent to browser
DEBUG - 2025-09-06 16:37:00 --> Total execution time: 0.2258
INFO - 2025-09-06 16:42:48 --> Config Class Initialized
INFO - 2025-09-06 16:42:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:42:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:42:48 --> Utf8 Class Initialized
INFO - 2025-09-06 16:42:48 --> URI Class Initialized
INFO - 2025-09-06 16:42:48 --> Router Class Initialized
INFO - 2025-09-06 16:42:48 --> Output Class Initialized
INFO - 2025-09-06 16:42:48 --> Security Class Initialized
DEBUG - 2025-09-06 16:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:42:48 --> Input Class Initialized
INFO - 2025-09-06 16:42:48 --> Language Class Initialized
INFO - 2025-09-06 16:42:48 --> Loader Class Initialized
INFO - 2025-09-06 16:42:48 --> Helper loaded: url_helper
INFO - 2025-09-06 16:42:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:42:48 --> Helper loaded: form_helper
INFO - 2025-09-06 16:42:48 --> Form Validation Class Initialized
INFO - 2025-09-06 16:42:48 --> Controller Class Initialized
INFO - 2025-09-06 16:42:48 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Sidebar.php
INFO - 2025-09-06 16:42:48 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/Include/Navbar.php
INFO - 2025-09-06 16:42:48 --> File loaded: C:\xampp\htdocs\timersacademy-1\application\views\superadmin/add_new_center.php
INFO - 2025-09-06 16:42:48 --> Final output sent to browser
DEBUG - 2025-09-06 16:42:48 --> Total execution time: 0.1109
INFO - 2025-09-06 16:42:48 --> Config Class Initialized
INFO - 2025-09-06 16:42:48 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:42:48 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:42:48 --> Utf8 Class Initialized
INFO - 2025-09-06 16:42:48 --> URI Class Initialized
INFO - 2025-09-06 16:42:48 --> Router Class Initialized
INFO - 2025-09-06 16:42:48 --> Output Class Initialized
INFO - 2025-09-06 16:42:48 --> Security Class Initialized
DEBUG - 2025-09-06 16:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:42:48 --> Input Class Initialized
INFO - 2025-09-06 16:42:48 --> Language Class Initialized
INFO - 2025-09-06 16:42:48 --> Loader Class Initialized
INFO - 2025-09-06 16:42:48 --> Helper loaded: url_helper
INFO - 2025-09-06 16:42:48 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:42:48 --> Helper loaded: form_helper
INFO - 2025-09-06 16:42:48 --> Form Validation Class Initialized
INFO - 2025-09-06 16:42:48 --> Controller Class Initialized
INFO - 2025-09-06 16:42:48 --> Model "Center_model" initialized
INFO - 2025-09-06 16:42:48 --> Final output sent to browser
DEBUG - 2025-09-06 16:42:48 --> Total execution time: 0.1049
INFO - 2025-09-06 16:43:30 --> Config Class Initialized
INFO - 2025-09-06 16:43:30 --> Hooks Class Initialized
DEBUG - 2025-09-06 16:43:30 --> UTF-8 Support Enabled
INFO - 2025-09-06 16:43:30 --> Utf8 Class Initialized
INFO - 2025-09-06 16:43:30 --> URI Class Initialized
INFO - 2025-09-06 16:43:30 --> Router Class Initialized
INFO - 2025-09-06 16:43:30 --> Output Class Initialized
INFO - 2025-09-06 16:43:30 --> Security Class Initialized
DEBUG - 2025-09-06 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-06 16:43:30 --> Input Class Initialized
INFO - 2025-09-06 16:43:30 --> Language Class Initialized
INFO - 2025-09-06 16:43:30 --> Loader Class Initialized
INFO - 2025-09-06 16:43:30 --> Helper loaded: url_helper
INFO - 2025-09-06 16:43:30 --> Database Driver Class Initialized
DEBUG - 2025-09-06 16:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-06 16:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-06 16:43:30 --> Helper loaded: form_helper
INFO - 2025-09-06 16:43:30 --> Form Validation Class Initialized
INFO - 2025-09-06 16:43:30 --> Controller Class Initialized
INFO - 2025-09-06 16:43:30 --> Model "Center_model" initialized
INFO - 2025-09-06 16:43:30 --> Final output sent to browser
DEBUG - 2025-09-06 16:43:30 --> Total execution time: 0.2210
